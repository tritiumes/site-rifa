

$(document).ready(function () {


  const local = window.location.href;

  const urlObj = new URL(local);

  const path = urlObj.pathname;
  const campanha = path.split("/")[2]
 var page = path.split("/")[1];
  function getAllData({ patch, calback }) {
    const URL_BASE = (patch) => `${_base_url_}assets/api.php?${patch}`;

    const url = URL_BASE(patch);
    fetch(url)
      .then((response) => {
        if (!response.ok) {
          throw new Error("Erro ao buscar dados da API");
        }

        return response.json();
      })
      .then((data) => {
        console.log(data);
        calback(data);
      })
      .catch((error) => {
        console.error("Error fetching data:", error);
        return error.message;
      });
  }





  if (page == "compra") {
        

const getOrderToken = window.location.href;
const order_token = getOrderToken.split("/")[4].split("?")[0];

fetch(_base_url_ + `assets/api.php?order_token=${order_token}`)
  .then((response) => {
    if (!response.ok) {
      throw new Error("Erro ao buscar dados da API");
    }
    return response.json();
  })
  .then((res) => {


 if(res.payment_method == 'Paggue'){
                const img_qrcode =  $('#img-qrcode img');
                
                
            console.log(res.pix_qrcode)
    img_qrcode.attr('src', 'data:image/png;base64,' + res.pix_qrcode )

 }
    if(res.payment_method == 'Pagstar'){
           const img_qrcode =  $('#img-qrcode img');
    img_qrcode.attr('src', res.pix_qrcode )
    }


   
  });

        
        
        
 

  }
});
