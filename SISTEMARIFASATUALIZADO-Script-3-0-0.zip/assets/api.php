<?php
require_once('../initialize.php');

// Verifica se as constantes necessárias estão definidas
if (!defined('DB_SERVER') || !defined('DB_NAME') || !defined('DB_USERNAME') || !defined('DB_PASSWORD')) {
    die("Database configuration constants are not defined.");
}

// Configuração do banco de dados
$host = DB_SERVER;
$dbname = DB_NAME;
$username = DB_USERNAME;
$password = DB_PASSWORD;

try {
    // Conecta ao banco de dados
    $db = new PDO("mysql:host=$host;dbname=$dbname", $username, $password);
    $db->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
} catch (PDOException $e) {
    // Trata o erro de conexão com o banco de dados
    die("Error connecting to the database: " . $e->getMessage());
}

// Obtém o método HTTP e o caminho da requisição
$method = $_SERVER['REQUEST_METHOD'];
$path = $_SERVER['PATH_INFO'] ?? '/';
$data = json_decode(file_get_contents("php://input"), true);
$id = $_GET['id'] ?? null;
$params = $_GET;

switch ($method) {
    case 'GET':
        try {
            $sql = "SELECT meta_value FROM system_info WHERE id = 35";

            if (isset($params['id'])) {
                $sql = " WHERE id = ?";
                $query = $db->prepare($sql);
                $query->execute([$id]);
                $result = $query->fetch(PDO::FETCH_ASSOC);
                echo json_encode($result);
            } elseif (isset($params['horainicial']) && isset($params['horafinal']) && isset($params['valorqt']) && isset($params['cota'])) {
                $sql = "SELECT * FROM order_list WHERE date_created > ? AND date_created < ? AND quantity >= ? AND FIND_IN_SET(?, order_numbers) > 0";
                $query = $db->prepare($sql);
                $query->execute([$params['horainicial'], $params['horafinal'], $params['valorqt'], $params['cota']]);
                $result = $query->fetch(PDO::FETCH_ASSOC);

                if ($result) {
                    $query2 = $db->prepare("SELECT * FROM customer_list WHERE id = ?");
                    $query2->execute([$result['customer_id']]);
                    $result2 = $query2->fetch(PDO::FETCH_ASSOC);
                    echo json_encode(['sorteio' => $result, 'user' => $result2]);
                } else {
                    echo json_encode([]);
                }
            } elseif (isset($params['whatsapp'])) {
                $query = $db->query($sql);
                $result = $query->fetch(PDO::FETCH_ASSOC);
                echo json_encode($result);
            } elseif (isset($params['order_list'])) {

                $query = $db->query('SELECT * FROM order_list');

                $result = $query->fetchAll(PDO::FETCH_ASSOC);
                echo json_encode($result);
                
                
            } 
            
            elseif (isset($params['site'])) {

               $sql = "SELECT * FROM users WHERE site = ?";
                $query = $db->prepare($sql);
                $query->execute([$params['site']]);
                $result = $query->fetchAll(PDO::FETCH_ASSOC);
                echo json_encode($result);
                
            }
            elseif (isset($params['order_id'])) {
                $sql = "SELECT * FROM order_list WHERE product_id = ?";
                $query = $db->prepare($sql);
                $query->execute([$params['order_id']]);
                $result = $query->fetchAll(PDO::FETCH_ASSOC);
                echo json_encode($result);
            }
             elseif (isset($params['slug'])) {
                $sql = "SELECT * FROM product_list WHERE slug = ?";
                $query = $db->prepare($sql);
                $query->execute([$params['slug']]);
                $result = $query->fetch(PDO::FETCH_ASSOC);
                echo json_encode($result);
            }

            elseif (isset($params['order_name'])) {
                $sql = "SELECT * FROM order_list WHERE product_name = ?";
                $query = $db->prepare($sql);
                $query->execute([$params['order_name']]);
                $result = $query->fetchAll(PDO::FETCH_ASSOC);
                echo json_encode($result);
            }
            
            elseif (isset($params['order_id_product'])) {
                $sql = "SELECT * FROM order_list WHERE product_id = ?";
                $query = $db->prepare($sql);
                $query->execute([$params['order_id']]);
                $result = $query->fetchAll(PDO::FETCH_ASSOC);
                echo json_encode($result);
            }
            
            
            elseif (isset($params['user_id'])) {
                $sql = "SELECT * FROM customer_list WHERE id = ?";
                $query = $db->prepare($sql);
                $query->execute([$params['user_id']]);
                $result = $query->fetch(PDO::FETCH_ASSOC);
                echo json_encode($result);
            } elseif (isset($params['set_Winer'])) {

                $sql = "SELECT draw_winner , draw_number FROM product_list WHERE name = ? ";
                $query = $db->prepare($sql);
                $query->execute([$params['name']]);
                $result = $query->fetch(PDO::FETCH_ASSOC);



                echo json_encode($result);
            } elseif (isset($params['order_token'])) {
                $sql = "SELECT * FROM order_list WHERE order_token = ? ";
                $query = $db->prepare($sql);
                $query->execute([$params['order_token']]);
                $result = $query->fetch(PDO::FETCH_ASSOC);
                echo json_encode($result);
            } elseif (isset($params['product_id'])) {
                $sql = "SELECT * FROM product_list WHERE id = ? ";
                $query = $db->prepare($sql);
                $query->execute([$params['product_id']]);
                $result = $query->fetch(PDO::FETCH_ASSOC);
                echo json_encode($result);
            } elseif (isset($params['user_id'])) {

                $sql = "SELECT * FROM customer_list WHERE id = ?";
                $query = $db->prepare($sql);
                $query->execute([$params['user_id']]);
                $result = $query->fetch(PDO::FETCH_ASSOC);
                echo json_encode($result);
            }
            
            elseif (isset($params['product_name'])) {

                $sql = "SELECT * FROM product_list WHERE name = ?";
                $query = $db->prepare($sql);
                $query->execute([$params['product_name']]);
                $result = $query->fetch(PDO::FETCH_ASSOC);
                echo json_encode($result);
            }


            elseif (isset($params['products'])) {

                $sql = "SELECT * FROM product_list";
                $query = $db->prepare($sql);
                $query->execute();
                $result = $query->fetch(PDO::FETCH_ASSOC);
                echo json_encode($result);
            }
            
            elseif (isset($params['all'])) {
                $query = $db->prepare("SELECT * FROM product_list");
                $query->execute();
                $result = $query->fetchAll(PDO::FETCH_ASSOC);
                echo json_encode($result);
            } elseif (isset($params['product_name'])) {
                $query = $db->prepare("SELECT * FROM product_list WHERE name = ? AND cotas_premiadas IS NOT NULL AND cotas_premiadas != '' AND cotas_premiadas != ' ' AND draw_winner = ? ");
                $query->execute([$params['product_name'], '[""]']);
                $result = $query->fetch(PDO::FETCH_ASSOC);

                if ($result) {

                    echo  json_encode(['message' => 'Produto encontrado com sucesso', 'status' => 200, 'data' => $result]);
                } else {
                    echo json_encode(['message' => 'Nenhum produto encontrado para o nome especificado', 'status' => 404]);
                }
            } else {
                $sql = "SELECT qty_numbers FROM product_list WHERE id = ?";
                $query = $db->prepare($sql);
                $query->execute([$id]);
                $result = $query->fetch(PDO::FETCH_ASSOC);
                echo json_encode($result);
            }
        } catch (PDOException $e) {
            // Trata erros do banco de dados
            echo json_encode(['error' => 'Erro no banco de dados: ' . $e->getMessage()]);
        }
        break;

    case 'POST':
        if ($data['order_numbers']) {
            try {
                $sql = "INSERT INTO order_list (product_name, product_id, status, order_numbers, code, quantity) VALUES (?, ?, ?, ?, ?, ?)";
                $query = $db->prepare($sql);
                $query->execute([$data['product_name'], $data['product_id'], $data['status'], $data['order_numbers'], $data['code'], $data['quantity']]);
                echo json_encode(['message' => 'Registro criado com sucesso', 'id' => $db->lastInsertId()]);
            } catch (PDOException $e) {
                // Trata erros do banco de dados
                echo json_encode(['error' => 'Erro no banco de dados: ' . $e->getMessage()]);
            }
            break;
    
        } else {
            try {
                $sql = "INSERT INTO customer_list (firstname, lastname, phone) VALUES (?, ?, ?)";
                $query = $db->prepare($sql);
                $query->execute([$data['firstname'], $data['lastname'], $data['phone']]);
                echo json_encode(['message' => 'Registro criado com sucesso', 'id' => $db->lastInsertId()]);
            } catch (PDOException $e) {
                // Trata erros do banco de dados
                echo json_encode(['error' => 'Erro no banco de dados: ' . $e->getMessage()]);
            }
            break;
    
        }
        

        
        case 'PUT':
            if (isset($data['draw_winner'])) {
                try {
                    $sql = "UPDATE product_list SET draw_winner = ?, draw_number = ? WHERE id = ?";
                    $query = $db->prepare($sql);
                    $query->execute([$data['draw_winner'], $data['draw_number'], $data['id']]);



                    echo json_encode(['message' => 'Registro atualizado com sucesso', 'status' => 200]);
                } catch (PDOException $e) {
                    echo json_encode(['error' => 'Erro no banco de dados: ' . $e->getMessage()]);
                }
            } elseif (isset($data['auto_cota'])) {
                try {
                    $sql = "UPDATE product_list SET status_auto_cota = ?, valor_base_auto = ?, paid_numbers = ? WHERE id = ?";
                    $query = $db->prepare($sql);
                    $result = $query->execute([$data['status_auto_cota'], $data['valor_base_auto'], $data['paid_numbers'], $data['id']]);
                    if ($query->rowCount() > 0) {
                        echo json_encode(['message' => 'Registro atualizado com sucesso', 'status' => 200, 'data' => $result]);
                    } else {
                        http_response_code(404);
                        echo json_encode(['message' => 'Registro não encontrado']);
                    }
                } catch (PDOException $e) {
                    echo json_encode(['error' => 'Erro no banco de dados: ' . $e->getMessage()]);
                }
            } elseif (isset($data['auto_order'])) {
                try {
                    $sql = "UPDATE order_list SET status = ?, quantity = ?, order_numbers = ? WHERE code = ?";
                    $query = $db->prepare($sql);
                    $result = $query->execute([$data['status'], $data['quantity'], $data['order_numbers'], $data['code']]);
                    if ($query->rowCount() > 0) {
                        echo json_encode(['message' => 'Registro atualizado com sucesso', 'status' => 200, 'data' => $result]);
                    } else {
                        http_response_code(404);
                        echo json_encode(['message' => 'Registro não encontrado']);
                    }
                } catch (PDOException $e) {
                    echo json_encode(['error' => 'Erro no banco de dados: ' . $e->getMessage()]);
                }
            } elseif (isset($data['tipo_auto_cota2'])) {
                try {
                    $sql = "UPDATE product_list SET tipo_auto_cota = ?, status_auto_cota = ?, quantidade_auto_cota = ?, quantidade_numeros = ?, valor_base_auto = ? WHERE id = ?";
                    $query = $db->prepare($sql);
                    $result = $query->execute([$data['tipo_auto_cota'], $data['status_auto_cota'], $data['valor_cota_auto'], $data['numero_cota_auto'], $data['valor_base_auto'], $data['id']]);
                    if ($query->rowCount() > 0) {
                        echo json_encode(['message' => 'Registro atualizado com sucesso', 'status' => 200, 'data' => $result]);
                    } else {
                        http_response_code(404);
                        echo json_encode(['message' => 'Registro não encontrado']);
                    }
                } catch (PDOException $e) {
                    echo json_encode(['error' => 'Erro no banco de dados: ' . $e->getMessage()]);
                }
            } elseif (isset($data['paid_numbers'])) {
                try {
                    $sql = "UPDATE product_list SET paid_numbers = ?, status_auto_cota = ?, valor_base_auto = ?, up = ? WHERE id = ?";
                    $query = $db->prepare($sql);
                    $result = $query->execute([$data['paid_numbers'], $data['status_auto_cota'], $data['valor_base_auto'], $data['up'], $data['id']]);
                    if ($query->rowCount() > 0) {
                        echo json_encode(['message' => 'Registro atualizado com sucesso', 'status' => 200, 'data' => $result]);
                    } else {
                        http_response_code(404);
                        echo json_encode(['message' => 'Registro não encontrado']);
                    }
                } catch (PDOException $e) {
                    echo json_encode(['error' => 'Erro no banco de dados: ' . $e->getMessage()]);
                }
            } else {
                http_response_code(201);
                echo json_encode(['message' => 'Registro não encontrado']);
            }
            break;
        

}
