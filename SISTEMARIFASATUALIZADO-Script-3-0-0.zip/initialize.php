<?php
ini_set('display_errors', 0);
ini_set('display_startup_errors', 0);
error_reporting(0);
if(!defined('BASE_URL')) define('BASE_URL', 'https://familiadograurifas.com/');
if(!defined('BASE_APP')) define('BASE_APP', str_replace('\\','/',__DIR__).'/' );
if(!defined('DB_SERVER')) define('DB_SERVER', 'localhost');
if(!defined('DB_USERNAME')) define('DB_USERNAME', 'familiarifas');
if(!defined('DB_PASSWORD')) define('DB_PASSWORD', 'sFitN4Y57Z37tNE5');
if(!defined('DB_NAME')) define('DB_NAME', 'familiarifas');
?>