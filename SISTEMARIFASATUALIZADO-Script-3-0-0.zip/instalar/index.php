<!DOCTYPE html>
<html lang="en">
<head>
	<meta charset="UTF-8">
	<meta name="viewport" content="width=device-width, initial-scale=1.0">
	<meta http-equiv="X-UA-Compatible" content="ie=edge">
	<title>Thiago Rifas - Instalação do sistema de rifas</title>
	<link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@4.5.3/dist/css/bootstrap.min.css" integrity="sha384-TX8t27EcRE3e/ihU7zmQxVncDAy5uIKz4rEkgIXeMed4M0jlfIDPvg6uqKI2xXr2" crossorigin="anonymous">
	
	<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.1/css/all.min.css" integrity="sha512-+4zCK9k+qNFUR5X+cKL9EIR+ZOhtIloNl9GIKS57V1MyNsYpYcUrUeQc9vNfzsWfV28IaLL3i96P9sdNyeRssA==" crossorigin="anonymous" />
	<link rel="shortcut icon" href="assets/favicon.png" type="image/x-icon">
	<style>
	    
	    @import url("https://fonts.googleapis.com/css2?family=Poppins:wght@400;700&display=swap");
html {
    font-size: 18px;
}
body {
    color: #ddd;
    line-height: 18px;
    font-family: "Poppins", sans-serif;
    background: #071a2c;7
	font-weight:500
}
h1,h2,h3,h4,h5,h6 {
    font-weight: 700;
    margin: 0;
    line-height: 1.3;
    color: #fff;
}
h2 {
    font-size: 26px;
}
h3 {
    font-size: 18px;
}
h4 {
    font-size: 14px;
}
h5 {
    font-size: 20px;
}
h6 {
    font-size: 18px;
}
p {
    margin-top: -8px;
}
p:last-child {
    margin-bottom: -7px !important;
}
@media (min-width: 768px) {
    h2 {
        font-size: 48px;
        line-height: 50px;
    }
    h3 {
        font-size: 24px;
    }
    h4 {
        font-size: 18px;
    }
    h5 {
        font-size: 16px;
    }
    h6 {
        font-size: 14px;
    }
}
ul {
    margin: 0;
    padding: 0;
}
ul li {
    list-style: none;
}
input {
    border-radius: 5px;
    color: #fff;
}
input::placeholder {
    color: #ddd;
}
.installation-menu {
    display: flex;
    flex-wrap: wrap;
}
.padding-top {
    padding-top: 70px;
}
.padding-bottom {
    padding-bottom: 100px;
}
.section-bg {
    background: #0b2036;
}
.installation-wrapper {
    /*padding: 60px;*/
    background: #0b2036;
    border-radius: 10px;
    margin-bottom: 40px;
}
.installation-wrapper:last-child {
    margin-bottom: 0;
}
@media (max-width: 991px) {
    .installation-wrapper {
        padding: 40px 30px;
    }
}
@media (max-width: 767px) {
    .installation-wrapper {
        padding: 0;
        background: transparent;
    }
}
.installation-menu {
    justify-content: center;
    text-align: center;
    max-width: 860px;
    margin: 0 auto;
    position: relative;
    margin-bottom: 30px;
}
@media (max-width: 767px) {
    .installation-menu {
        margin: 0 -15px;
    }
}
.installation-menu .steps {
    padding: 0 15px 30px;
    width: calc(100% / 4);
    position: relative;
}
.installation-menu .steps::after, .installation-menu .steps::before {
    position: absolute;
    height: 8px;
    width: 100%;
    content: "";
    background: #0087ff;
    left: 50%;
    top: 38px;
}
.installation-menu .steps::after {
    z-index: 1;
    background: #27ae60;
    transform-origin: left;
    display: none;
}
.installation-menu .steps .thumb {
    width: 75px;
    height: 75px;
    text-align: center;
    border-radius: 50%;
    background: #0087ff;
    font-size: 30px;
    margin: 0 auto 15px;
    position: relative;
    z-index: 2;
    display: flex;
    align-items: center;
    justify-content: center;
}
.installation-menu .steps .content {
    font-weight: 400;
    font-size: 18px;
}
.installation-menu .steps.running .thumb {
    background: #27ae60;
}
.installation-menu .steps.running .thumb::before, .installation-menu .steps.running .thumb::after {
    position: absolute;
    content: "";
    width: 100%;
    height: 100%;
    left: 0;
    top: 0;
    border-radius: 74px;
    background: #27ae60;
    opacity: 0.15;
    z-index: 1;
}
.installation-menu .steps.running .thumb i {
    position: relative;
    z-index: 3;
}
.installation-menu .steps.running .thumb::before {
    -webkit-animation: inner-ripple 2000ms linear infinite;
    -moz-animation: inner-ripple 2000ms linear infinite;
    animation: inner-ripple 2000ms linear infinite;
}
.installation-menu .steps.running .thumb::after {
    -webkit-animation: outer-ripple 2000ms linear infinite;
    -moz-animation: outer-ripple 2000ms linear infinite;
    animation: outer-ripple 2000ms linear infinite;
}
.installation-menu .steps.done .thumb {
    background: #27ae60;
}
.installation-menu .steps.done::after {
    display: block;
}
.installation-menu .steps:last-child::before, .installation-menu .steps:last-child::after {
    display: none;
}
@media (max-width: 991px) {
    .installation-menu .steps .thumb {
        width: 80px;
        height: 80px;
        line-height: 80px;
    }
    .installation-menu .steps.done .thumb::before {
        width: 40px;
        height: 40px;
        line-height: 40px;
        font-size: 14px;
    }
    .installation-menu .steps::before, .installation-menu .steps::after {
        top: 36px;
    }
}
@media (max-width: 767px) {
    .installation-menu .steps {
        width: 50%;
    }
    .installation-menu .steps:nth-child(even)::before, .installation-menu .steps:nth-child(even)::after {
        display: none;
    }
}
.box-item {
    border: 1px solid rgba(255, 255, 255, 0.1);
    padding: 30px;
    border-radius: 0 0 15px 15px;
}
@media (max-width: 575px) {
    .box-item {
        padding: 30px 15px;
    }
}
.install-item .title {
    padding: 16px 0 12px 0;
    border-radius: 10px 10px 0 0;
    background: #0087ff;
    text-transform: uppercase;
	font-weight:400;
	text-transform:none;
}
.install-item .item {
    margin-bottom: 50px;
}
.install-item .item:last-child {
    margin-bottom: 0;
}
.install-item .item .subtitle {
    font-weight: 400;
    margin-bottom: 20px;
}
.install-item .item p {
    margin: 0;
    margin-bottom: 20px;
}
.install-item .item .check-list {
    margin-bottom: 25px;
}
.install-item .item .check-list:last-child {
    margin-bottom: 0 !important;
}
.install-item .item .check-list li:first-child {
    padding-top: 0;
}
.install-item .item .check-list li:last-child {
    padding-bottom: 0;
}
.install-item .item .check-list li::before {
    content: "\f00c";
    color: #27ae60;
    font-family: "Font Awesome 5 Free";
    font-weight: 600;
    font-size: 14px;
    margin-right: 5px;
}
.install-item .item .check-list li.no::before {
    color: #e84118;
    content: "\f00d";
}
.install-item .item .info {
    margin-bottom: 25px;
}
.install-item .item .info:last-child {
    margin-bottom: 0 !important;
}
.install-item .item .info img {
    width: 20px;
    margin-right: 5px;
}
.install-item .item .info a {
    margin: 0 5px;
}
@media (max-width: 575px) {
    .install-item .item {
        margin-bottom: 40px;
    }
    .install-item .item .subtitle {
        margin-bottom: 15px;
    }
    .install-item .item .info, .install-item .item .check-list, .install-item .item p {
        margin-bottom: 20px;
    }
}
.requirment-table {
    width: 100%;
}
.requirment-table tr {
    border-left: 1px solid rgba(255, 255, 255, 0.1);
    border-right: 1px solid rgba(255, 255, 255, 0.1);
}
.requirment-table tr:first-child {
    border-top: 1px solid rgba(255, 255, 255, 0.1);
}
.requirment-table tr td {
    padding: 10px;
    border-bottom: 1px solid rgba(255, 255, 255, 0.1);
}
.requirment-table tr td:last-child {
    text-align: center;
}
.requirment-table tr td i {
    color: #e84118;
}
.requirment-table tr td i[class*="check"] {
    color: #27ae60;
}
.requirment-table tr:nth-child(even) {
    background: #071a2c;
}
.table-area.item {
    margin-bottom: 30px;
}
@media (max-width: 767px) {
    .table-area {
        overflow-x: auto;
    }
    .table-area .requirment-table {
        width: 700px;
    }
}
.info-item {
    margin-bottom: 40px;
}
.info-item:last-child {
    margin-bottom: 0 !important;
}
.info-item .subtitle {
    text-transform: uppercase;
    font-weight: 400;
    font-size: 18px;
    margin-bottom: 10px;
}
@media (max-width: 575px) {
    .info-item {
        margin-bottom: 30px;
    }
}
.mb--20 {
    margin-bottom: -20px;
}
.information-form-group {
    margin-bottom: 20px;
}
.information-form-group input {
    width: 100%;
    height: 50px;
    border: 1px solid rgba(255, 255, 255, 0.2);
    background: #071a2c;
    padding: 0 15px;
}
.information-form-group input::placeholder {
    color: #ddd;
}
@media (max-width: 575px) {
    .information-form-group input {
        background: #0b2036;
    }
}
.success-area {
    padding: 30px 0;
}
.success-area .subtitle {
    text-transform: uppercase;
    margin-bottom: 70px;
}
.success-area .info {
    display: block;
    color: #27ae60;
    margin-bottom: 30px;
}
.success-area .warning {
    margin-top: 70px;
}
@media (max-width: 575px) {
    .success-area .subtitle {
        margin-bottom: 40px;
    }
    .success-area .info {
        margin-bottom: 20px;
    }
    .success-area .warning {
        margin-top: 40px;
    }
}
header .logo {
    width: 180px;
}
.theme-button {
    /* font-weight: 700; */
    border-radius: 14px;
    line-height: 28px;
    padding: 15px 30px;
    text-transform: uppercase;
    color: #ffffff;
    background: #0087ff;
    position: relative;
    z-index: 1;
}
.theme-button::before {
    position: absolute;
    content: '';
    top: 0;
    left: 0;
    width: 0;
    height: 100%;
    background-color: #27ae60;
    transition: all 0.45s;
    z-index: -1;
    border-radius: 5px;
}
.theme-button:hover::before {
    width: 100%;
}
.theme-button i:last-child {
    margin-left: 7px;
}
.theme-button i:first-child {
    margin-right: 7px;
}
.theme-button:hover {
    color: #ffffff;
    text-decoration: none;
}
.theme-button.choto {
    padding: 10px 30px;
}
button.theme-button {
    height: 60px;
    padding: 0 30px;
    border: none;
}
button.theme-button.choto {
    height: 50px;
}
/* inner outer ripple */
@keyframes outer-ripple {
    0% {
        transform: scale(1);
        opacity: 0.5;
        -webkit-transform: scale(1);
    }
    80% {
        transform: scale(1.5);
        opacity: 0;
        -webkit-transform: scale(1.5);
    }
    100% {
        transform: scale(2.5);
        opacity: 0;
        -webkit-transform: scale(2.5);
    }
}
@keyframes inner-ripple {
    0% {
        transform: scale(1);
        opacity: 0.5;
        -webkit-transform: scale(1);
    }
    30% {
        transform: scale(1);
        opacity: 0.5;
        -webkit-transform: scale(1);
    }
    100% {
        transform: scale(1.5);
        opacity: 0;
        -webkit-transform: scale(1.5);
    }
}
.installation-section {
    min-height: calc(100vh - 119px);
}
	</style>
</head>
<body>

	<div class="installation-section padding-bottom padding-top">
		<div class="container">
			<?php 
			error_reporting(0);
			function isExtensionAvailable($name){
				if (!extension_loaded($name)) {
					$response = false;
				} else {
					$response = true;
				}
				return $response;
			}
			function checkFolderPerm($name){
				$perm = substr(sprintf('%o', fileperms($name)), -4);
				if ($perm >= '0755') {
					$response = true;
				} else {
					$response = false;
				}
				return $response;
			}
			function tableRow($name, $details, $status){
				if ($status=='1') {
					$pr = '<i class="fas fa-check"></i>';
				}else{
					$pr = '<i class="fas fa-times"></i>';
				}
				echo "<tr><td>$name</td><td>$details</td><td>$pr</td></tr>";
			}
	function getWebURL(){   
				$base_url = (isset($_SERVER['HTTPS']) &&
					$_SERVER['HTTPS']!='off') ? 'https://' : 'http://';
				$tmpURL = dirname(__FILE__);
				$tmpURL = str_replace(chr(92),'/',$tmpURL);
				$tmpURL = str_replace($_SERVER['DOCUMENT_ROOT'],'',$tmpURL);
				$tmpURL = ltrim($tmpURL,'/');
				$tmpURL = rtrim($tmpURL, '/');
				$tmpURL = str_replace('instalar','',$tmpURL);
				$base_url .= $_SERVER['HTTP_HOST'].'/'.$tmpURL;
				if (substr("$base_url", -1=="/")) {
					$base_url = substr("$base_url", 0, -1);
				}
				return $base_url; 
			}

			
			

			function getStatus($arr){
				return true;
			}

			function replaceData($val,$arr){
				foreach ($arr as $key => $value) {
					$val = str_replace('{{'.$key.'}}', $value, $val);
				}
				return $val;
			}
			function setDataValue($val,$loc){
				$file = fopen($loc, 'w');
				fwrite($file, $val);
				fclose($file);
			}
			function sysInstall($sr,$pt){
				return true;
			}
			function importDatabase($pt){
					return true;

			}
			function setAdminEmail($pt){
					return true;
			}
			//------------->> Extension & Permission
			$requiredServerExtensions = [
				  'Fileinfo', 'JSON', 'Mbstring', 'OpenSSL', 'PDO','pdo_mysql',  'cURL',  'GD'
			];

			$folderPermissions = ['../admin','../classes/','../pages/','../uploads/'
			];
			//------------->> Extension & Permission

			if (isset($_GET['action'])) {
				$action = $_GET['action'];
			}else {
				$action = "";
			}

			if ($action=='complete') {
				?>
				<div class="installation-wrapper pt-md-5">
					<ul class="installation-menu">
						<li class="steps done">
							<div class="thumb">
								<i class="fas fa-server"></i>
							</div>
							<h5 class="content">Requerimentos</h5>
						</li>
						<li class="steps done">
							<div class="thumb">
								<i class="fas fa-file-signature"></i>
							</div>
							<h5 class="content">Permissões</h5>
						</li>
						<li class="steps done">
							<div class="thumb">
								<i class="fas fa-database"></i>
							</div>
							<h5 class="content">Instalação</h5>
						</li>
						<li class="steps running">
							<div class="thumb">
								<i class="fas fa-check-circle"></i>
							</div>
							<h5 class="content">Finalização</h5>
						</li>
					</ul>
				</div>
				<div class="installation-wrapper">
					<div class="install-content-area">
						<div class="install-item">
							<h3 class="bg-success title text-center">Instalação finalizada</h3>
                           
							<div class="box-item">
								<div class="success-area text-center">
                                
                                
                               <!--div class="alert alert-success alert-dismissible fade show" role="alert">
    <strong>Sucesso!</strong> A instalação foi concluída com sucesso!
    <hr>
    <p class="mb-d0"><strong>ATENÇÃO!</strong> Remova a pasta <strong>instalar</strong> do diretório do sistema.</p>
    <p class="mbd-0">Clique <a href="https://rifapro.site/admin">aqui</a> para acessar seu painel de administração.</p>
    <!--p class="mb-d0">Usuário: <strong>admin</strong> / Senha: <strong>admin</strong></p>
    <button type="button" class="close" data-dismiss="alert" aria-label="Close">
        <span aria-hidden="true">&times;</span>
    </button--
</div-->

                                
                                
									<?php
									if ($_POST) {
										
										print_r($data);
										$alldata = $_POST;
										$db_name = $_POST['db_name'];
										$db_host = $_POST['db_host'];
										$db_user = $_POST['db_user'];
										$db_pass = $_POST['db_pass'];
										$passw = md5($_POST['passw']);
										$email = $_POST['email'];
											$username = $_POST['username'];
			                            $siteurl = getWebURL();
										$app_key = base64_encode(random_bytes(32));
	
	$barra = '\\'.'\\';
	
	$envcontent = "<?php
ini_set('display_errors', 0);
ini_set('display_startup_errors', 1);
error_reporting(E_ALL);
if(!defined('BASE_URL')) define('BASE_URL', '".getWebURL()."/');
if(!defined('BASE_APP')) define('BASE_APP', str_replace('$barra','/',__DIR__).'/' );
if(!defined('DB_SERVER')) define('DB_SERVER', '".$db_host."');
if(!defined('DB_USERNAME')) define('DB_USERNAME', '".$db_user."');
if(!defined('DB_PASSWORD')) define('DB_PASSWORD', '".$db_pass."');
if(!defined('DB_NAME')) define('DB_NAME', '".$db_name."');
?>";
										$status = 'ok';
										$envpath = dirname(__DIR__, 1) . '/initialize.php';
										file_put_contents($envpath, $envcontent);
										if ($status == 'ok') {
											if(importDatabase($alldata)){							

   $conn = new PDO("mysql:host=$db_host;dbname=$db_name", $db_user, $db_pass);
   $query = file_get_contents("database.sql");
   $stmt = $conn->prepare($query);
   $stmt->execute();						

	           }
											
											if(setAdminEmail($alldata)){
														$db = new PDO("mysql:host=$db_host;dbname=$db_name", $db_user, $db_pass);
														$sql = "UPDATE users SET 
														username='".$username."',
														password='".$passw."',
														email='".$email."'
														
														WHERE id=1";
														$stmt = $db->prepare($sql);
														$stmt->execute();
													/*	echo '<p class="text-success warning">Email address of admin has been set successfully!</p>';*/
																											echo '
	<p class="text-success lead my-0">A instalação foi concluída com sucesso!</p>																											
																											<div class="warning">
													<p class="text-danger lead my-0">Delete a pasta "instalar" do servidor.</p>
												
													</div>';
													echo '
													<div class="warning">
														<a href="'.getWebURL().'" class="theme-button choto">Ir para o site</a>
													<a href="'.getWebURL().'/admin" class="theme-button choto">Ir para o painel</a>
													</div>';
													
											
									}
									}}
									?>
								</div>
							</div>
						</div>
					</div>
				</div>
				<?php
			}elseif($action=='info') {
				?>
				<div class="installation-wrapper pt-md-5">
					<ul class="installation-menu">
						<li class="steps done">
							<div class="thumb">
								<i class="fas fa-server"></i>
							</div>
							<h5 class="content">Requerimentos</h5>
						</li>
						<li class="steps done">
							<div class="thumb">
								<i class="fas fa-file-signature"></i>
							</div>
							<h5 class="content">Permissões</h5>
						</li>
						<li class="steps running">
							<div class="thumb">
								<i class="fas fa-database"></i>
							</div>
							<h5 class="content">Instalação</h5>
						</li>
						<li class="steps">
							<div class="thumb">
								<i class="fas fa-check-circle"></i>
							</div>
							<h5 class="content">Finalização</h5>
						</li>
					</ul>
				</div>
				<div class="installation-wrapper">
					<div class="install-content-area">
						<div class="install-item">
							<h3 class="bg-primary title text-center">Instalação do sistema</h3>
							<div class="box-item">
								<form action="?action=complete" method="post" class="information-form-area mb--20">
									<div class="info-item">
										<h5 class="font-weight-normal mb-2">Url do site</h5>
										<div class="row">
											<div class="information-form-group col-12">
												<input name="url" value="<?php echo getWebURL(); ?>" type="text" required>
											</div>
										</div>
									</div>
									<!--div class="info-item">
										<h5 class="font-weight-normal mb-2">Purchase Verification</h5>
										<div class="row">
											<div class="information-form-group col-sm-6">
												<input type="text" name="user" placeholder="Username" required>
											</div>
											<div class="information-form-group col-sm-6">
												<input type="text" name="code" placeholder="Purchase Code" required>
											</div>
										</div>
									</div-->
									<div class="info-item">
										<h5 class="font-weight-normal mb-2">Detalhes do banco</h5>
										<div class="row">
											<div class="information-form-group col-sm-6">
												<input type="text" name="db_name" placeholder="Nome do banco" required>
											</div>
											<div class="information-form-group col-sm-6">
												<input type="text" name="db_host" placeholder="Servidor" required>
											</div>
											<div class="information-form-group col-sm-6">
												<input type="text" name="db_user" placeholder="Usuáro do banco" required>
											</div>
											<div class="information-form-group col-sm-6">
												<input type="text" name="db_pass" placeholder="Senha do banco">
											</div>
										</div>
									</div>
									<div class="info-item">
										<h5 class="font-weight-normal mb-3">Credenciais do administrador</h5>
										<div class="row">
											<div class="information-form-group col-lg-3 col-sm-6">
												<label>Usuário</label>
												<input type="text" name='username'  required>
											</div>
											<div class="information-form-group col-lg-3 col-sm-6">
												<label>Password</label>
												<input type="text" name="passw"   required>
											</div>
											<div class="information-form-group col-lg-6">
												<label>Email</label>
												<input  name="email" placeholder="Insira seu email" type="email" required>
											</div>
										</div>
									</div>
									<div class="info-item">
										<div class="information-form-group text-right">
											<button type="submit" class="theme-button choto">Finalizar</button>
										</div>
									</div>
								</form>
							</div>
						</div>
					</div>
				</div>
				<?php
			}elseif ($action=='file') {
				?>
				<div class="installation-wrapper pt-md-5">
					<ul class="installation-menu">
						<li class="steps done">
							<div class="thumb">
								<i class="fas fa-server"></i>
							</div>
							<h5 class="content">Requerimentos</h5>
						</li>
						<li class="steps running">
							<div class="thumb">
								<i class="fas fa-file-signature"></i>
							</div>
							<h5 class="content">Permissões</h5>
						</li>
						<li class="steps">
							<div class="thumb">
								<i class="fas fa-database"></i>
							</div>
							<h5 class="content">Instalação</h5>
						</li>
						<li class="steps">
							<div class="thumb">
								<i class="fas fa-check-circle"></i>
							</div>
							<h5 class="content">Finalização</h5>
						</li>
					</ul>
				</div>
				<div class="installation-wrapper">
					<div class="install-content-area">
						<div class="install-item">
							<h3 class="bg-primary title text-center">Permissões de arquivos</h3>
							<div class="box-item">
								<div class="item table-area">
									<table class="requirment-table">
										<?php
										$error = 0;
										foreach ($folderPermissions as $key) {
											$folder_perm = checkFolderPerm($key);
											if ($folder_perm==true) {
												tableRow(str_replace("../", "", $key)," Permissão requerida: 0755 ",1);
											}else{
												$error += 1;
												tableRow(str_replace("../", "", $key)," Permissão requerida: 0755 ",0);
											}
										}
										$database = file_exists('database.sql');
										if ($database==true) {
											$error = $error+0;
											tableRow('Database',' Requer "database.sql" disponível',1);
										}else{
											$error = $error+1;
											tableRow('Database',' Requer "database.sql" disponível',0);
										}
										$database = file_exists('../.htaccess');
										if ($database==true) {
											$error = $error+0;
											tableRow('.htaccess','  Requer ".htaccess" disponível',1);
										}else{
											$error = $error+1;
											tableRow('.htaccess',' Requer ".htaccess" disponível',0);
										}
										?>
									</table>
								</div>
								<div class="item text-right">
									<?php
									if ($error==0) {
										echo '<a class="theme-button choto" href="?action=info">Prosseguir<i class="fa fa-angle-double-right"></i></a>';
									}else{
										echo '<a class="theme-button btn-warning choto" href="?action=file">ReCheck <i class="fa fa-sync-alt"></i></a>';
									}
									?>
								</div>
							</div>
						</div>
					</div>
				</div>
				<?php
			}elseif ($action=='server') {
				?>
				<div class="installation-wrapper pt-md-5">
  
                    
                    
                    
                    
                     <ul class="installation-menu">
        <li class="steps done">
            <div class="thumb">
                <i class="fas fa-server"></i>
            </div>
            <h5 class="content">Requisitos do Servidor</h5>
        </li>
        <li class="steps">
            <div class="thumb">
                <i class="fas fa-file-signature"></i>
            </div>
            <h5 class="content">Permissões de Arquivo</h5>
        </li>
        <li class="steps">
            <div class="thumb">
                <i class="fas fa-database"></i>
            </div>
            <h5 class="content">Informações de Instalação</h5>
        </li>
        <li class="steps">
            <div class="thumb">
                <i class="fas fa-check-circle"></i>
            </div>
            <h5 class="content">Instalação Completa</h5>
        </li>
    </ul>
</div>

				<div class="installation-wrapper">
    <div class="install-content-area">
        <div class="install-item">
            <h3 class="bg-primary title text-center">Requisitos do Servidor</h3>
            <div class="box-item">
                <div class="item table-area">
                    <table class="requirment-table">
                        <?php
                        $error = 0;
                        $phpversion = version_compare(PHP_VERSION, '7.4', '>=');
                        if ($phpversion == true) {
                            $error = $error + 0;
                            tableRow("PHP", "Versão PHP 7.3 ou superior necessária", 1);
                        } else {
                            $error = $error + 1;
                            tableRow("PHP", "Versão PHP 7.3 ou superior necessária", 0);
                        }
                        foreach ($requiredServerExtensions as $key) {
                            $extension = isExtensionAvailable($key);
                            if ($extension == true) {
                                tableRow($key, "Extensão PHP " . strtoupper($key) . " necessária", 1);
                            } else {
                                $error += 1;
                                tableRow($key, "Extensão PHP " . strtoupper($key) . " necessária", 0);
                            }
                        }
                        ?>
                    </table>
                </div>
                <div class="item text-right">
                    <?php
                    if ($error == 0) {
                        echo '<a class="theme-button choto" href="?action=file">Próxima Etapa <i class="fa fa-angle-double-right"></i></a>';
                    } else {
                        echo '<a class="theme-button btn-warning choto" href="?action=server">Verificar Novamente <i class="fa fa-sync-alt"></i></a>';
                    }
                    ?>
                </div>
            </div>
        </div>
    </div>
</div>

				<?php
			}else{
				?>
				<div class="installation-wrapper">
    <div class="install-content-area">
        <div class="install-item">
            <h3 class="bg-primary title text-center">Termos de Uso</h3>
            <div class="box-item">
                <div class="item">
                    <h4 class="subtitle">Bem vindo ao sistema de instalação do script de rifas</h4>
                    <p>A licença Regular é para apenas um site ou domínio. Se você deseja usá-la em vários sites ou domínios, você precisa comprar mais licenças (1 site = 1 licença). A Licença Regular concede a você uma licença contínua, não exclusiva e mundial para fazer uso do item.</p>
                </div>
                <div class="item">
                    <h5 class="subtitle font-weight-dsd">Importante:</h5>
                    <ul class="check-list">
                        <li>Usar em apenas um(1) domínio.</li>
                        <li>Modificar ou editar conforme desejar.</li>
                        <li>Traduzir para o seu(s) idioma(s) de escolha.</li>
                    </ul>
                   
                </div>
                
                <div class="item">
                    <p class="info">Para mais informações, Por favor, Consulte <a href="#" target="_blank">o FAQ da Licença</a></p>
                </div>
                <div class="item text-right">
                    <a href="?action=server" class="theme-button choto">Concordo, Próxima Etapa</a>
                </div>
            </div>
        </div>
    </div>
</div>

				<?php
			}
			?>
		</div>
	</div>
	<footer class="section-bg py-3 text-center">
		<div class="container">
			<p class="m-0 font-weight-dbold">&copy;<?php echo Date('Y') ?> - Todos os direitos reservados <a href="https://thiagorifasofc.com">Thiago Rifas</a></p>
		</div>
	</footer>
	<style>
		#hide{
			display: none;
		}
	</style>
</body>
</html>