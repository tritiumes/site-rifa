-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1:3306
-- Tempo de geração: 01/06/2024 às 19:19
-- Versão do servidor: 10.11.7-MariaDB-cll-lve
-- Versão do PHP: 7.2.34

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Banco de dados: `u517485990_demo10`
--

-- --------------------------------------------------------

--
-- Estrutura para tabela `cart_list`
--

CREATE TABLE `cart_list` (
  `id` int(30) NOT NULL,
  `customer_id` int(30) NOT NULL,
  `product_id` int(30) NOT NULL,
  `quantity` int(30) NOT NULL DEFAULT 0
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Estrutura para tabela `customer_list`
--

CREATE TABLE `customer_list` (
  `id` int(30) NOT NULL,
  `firstname` text NOT NULL,
  `lastname` text NOT NULL,
  `phone` text NOT NULL,
  `email` text DEFAULT NULL,
  `password` text DEFAULT NULL,
  `avatar` text DEFAULT NULL,
  `date_created` datetime NOT NULL DEFAULT current_timestamp(),
  `date_updated` datetime NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  `cpf` text DEFAULT NULL,
  `zipcode` text DEFAULT NULL,
  `address` text DEFAULT NULL,
  `number` text DEFAULT NULL,
  `neighborhood` text DEFAULT NULL,
  `complement` text DEFAULT NULL,
  `state` text DEFAULT NULL,
  `city` text DEFAULT NULL,
  `reference_point` text DEFAULT NULL,
  `is_affiliate` tinyint(1) DEFAULT 0
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Despejando dados para a tabela `customer_list`
--

INSERT INTO `customer_list` (`id`, `firstname`, `lastname`, `phone`, `email`, `password`, `avatar`, `date_created`, `date_updated`, `cpf`, `zipcode`, `address`, `number`, `neighborhood`, `complement`, `state`, `city`, `reference_point`, `is_affiliate`) VALUES
(40, 'Thiago', 'Silva', '92991739596', NULL, NULL, NULL, '2024-05-29 19:04:14', '2024-05-29 19:04:14', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 0),
(41, 'Rafa', 'Teste', '66999563724', NULL, NULL, NULL, '2024-05-29 19:08:44', '2024-05-29 19:08:44', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 0),
(42, 'Nando', 'Nando', '31998538489', NULL, NULL, NULL, '2024-05-29 19:40:50', '2024-05-29 19:40:50', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 0);

-- --------------------------------------------------------

--
-- Estrutura para tabela `logs`
--

CREATE TABLE `logs` (
  `id` int(30) NOT NULL,
  `origin` text DEFAULT NULL,
  `description` text DEFAULT NULL,
  `date` datetime NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Despejando dados para a tabela `logs`
--

INSERT INTO `logs` (`id`, `origin`, `description`, `date`) VALUES
(1, 'SYSTEM', 'Configurações do sistema atualizadas pelo usuário Mega', '2024-02-29 00:43:01'),
(2, 'PRODUCT', 'Produto Aleatório atualizado pelo usuário Mega', '2024-02-29 00:43:18'),
(3, 'USER', 'Usuário Mega atualizado pelo usuário Mega', '2024-02-29 00:55:32'),
(4, 'SYSTEM', 'Configurações do sistema atualizadas pelo usuário Mega', '2024-02-29 00:56:24'),
(5, 'PRODUCT', 'Produto Rifa Grátis atualizado pelo usuário Mega', '2024-03-26 23:55:14'),
(6, 'PRODUCT', 'Produto Aleatório atualizado pelo usuário Mega', '2024-03-27 00:48:18'),
(7, 'PRODUCT', 'Produto Aleatório atualizado pelo usuário Mega', '2024-03-27 00:49:10'),
(8, 'SYSTEM', 'Configurações do sistema atualizadas pelo usuário Mega', '2024-03-27 01:23:34'),
(9, 'PRODUCT', 'Produto Aleatório atualizado pelo usuário Mega', '2024-03-27 01:33:30'),
(10, 'PRODUCT', 'Produto Aleatório atualizado pelo usuário Mega', '2024-03-27 01:33:30'),
(11, 'SYSTEM', 'Configurações do sistema atualizadas pelo usuário Mega', '2024-03-27 03:32:03'),
(12, 'SYSTEM', 'Configurações do sistema atualizadas pelo usuário Mega', '2024-03-27 03:36:54'),
(13, 'SYSTEM', 'Configurações do sistema atualizadas pelo usuário Mega', '2024-03-27 12:57:06'),
(14, 'SYSTEM', 'Configurações do sistema atualizadas pelo usuário Mega', '2024-03-27 13:28:11'),
(15, 'SYSTEM', 'Configurações do sistema atualizadas pelo usuário ', '2024-03-27 14:21:05'),
(16, 'USER', 'Usuário Mega atualizado pelo usuário Mega', '2024-03-27 14:22:56'),
(17, 'ORDER', 'Pedido 17 deletado pelo usuário Mega', '2024-03-27 17:49:36'),
(18, 'ORDER', 'Pedido 18 aprovado manualmente pelo usuário Mega', '2024-03-27 18:05:16'),
(19, 'PRODUCT', 'Produto Aleatório atualizado pelo usuário Mega', '2024-03-27 18:06:13'),
(20, 'ORDER', 'Pedido 19 aprovado manualmente pelo usuário Mega', '2024-03-27 18:07:47'),
(21, 'ORDER', 'Pedido 19 aprovado manualmente pelo usuário Mega', '2024-03-27 18:08:19'),
(22, 'PRODUCT', 'Produto MOTO ZERO BALA adicionado pelo usuário Mega', '2024-03-27 18:20:45'),
(23, 'PRODUCT', 'Produto MOTO ZERO BALA atualizado pelo usuário Mega', '2024-03-27 18:22:41'),
(24, 'SYSTEM', 'Configurações do sistema atualizadas pelo usuário Mega', '2024-03-27 18:24:02'),
(25, 'SYSTEM', 'Configurações do sistema atualizadas pelo usuário Mega', '2024-03-27 18:25:02'),
(26, 'ORDER', 'Pedido 20 aprovado manualmente pelo usuário Mega', '2024-03-27 18:26:00'),
(27, 'PRODUCT', 'Produto novo evento adicionado pelo usuário Mega', '2024-03-27 18:31:15'),
(28, 'PRODUCT', 'Produto novo evento atualizado pelo usuário Mega', '2024-03-27 18:31:36'),
(29, 'ORDER', 'Pedido 22 aprovado manualmente pelo usuário Mega', '2024-03-27 18:33:05'),
(30, 'ORDER', 'Pedido 21 aprovado manualmente pelo usuário Mega', '2024-03-27 18:33:58'),
(31, 'PRODUCT', 'Produto Aleatório atualizado pelo usuário Mega', '2024-03-27 18:46:46'),
(32, 'SYSTEM', 'Configurações do sistema atualizadas pelo usuário Mega', '2024-03-27 18:48:10'),
(33, 'SYSTEM', 'Configurações do sistema atualizadas pelo usuário Mega', '2024-03-27 18:56:00'),
(34, 'SYSTEM', 'Configurações do sistema atualizadas pelo usuário Mega', '2024-03-27 18:56:28'),
(35, 'PRODUCT', 'Produto Aleatório atualizado pelo usuário Mega', '2024-03-27 19:31:28'),
(36, 'PRODUCT', 'Produto Aleatório atualizado pelo usuário Mega', '2024-03-27 19:32:12'),
(37, 'PRODUCT', 'Produto Elias gomes adicionado pelo usuário Mega', '2024-03-27 20:13:45'),
(38, 'PRODUCT', 'Produto Elias gomes atualizado pelo usuário Mega', '2024-03-27 20:14:09'),
(39, 'PRODUCT', 'Produto Elias gomes atualizado pelo usuário Mega', '2024-03-27 20:14:23'),
(40, 'PRODUCT', 'Produto Honda 160 2024 evento teste 1 milhão de cotas adicionado pelo usuário Mega', '2024-03-28 01:19:33'),
(41, 'PRODUCT', 'Produto Honda 160 2024 evento teste 1 milhão de cotas atualizado pelo usuário Mega', '2024-03-28 01:26:56'),
(42, 'SYSTEM', 'Configurações do sistema atualizadas pelo usuário Mega', '2024-03-28 01:31:02'),
(43, 'SYSTEM', 'Configurações do sistema atualizadas pelo usuário Mega', '2024-03-28 01:34:38'),
(44, 'PRODUCT', 'Produto Duster 0Km Evento teste adicionado pelo usuário Mega', '2024-03-28 01:38:22'),
(45, 'PRODUCT', 'Produto Duster 0Km Evento teste atualizado pelo usuário Mega', '2024-03-28 01:39:05'),
(46, 'PRODUCT', 'Produto Duster 0Km Evento teste atualizado pelo usuário Mega', '2024-03-28 01:40:13'),
(47, 'PRODUCT', 'Produto Duster 0Km Evento teste atualizado pelo usuário Mega', '2024-03-28 01:40:35'),
(48, 'PRODUCT', 'Produto Duster 0Km Evento teste 10 milhoes atualizado pelo usuário Mega', '2024-03-28 01:41:11'),
(49, 'PRODUCT', 'Produto Air Fryer com 10 numeros adicionado pelo usuário Mega', '2024-03-28 01:43:36'),
(50, 'PRODUCT', 'Produto Air Fryer com 10 numeros atualizado pelo usuário Mega', '2024-03-28 01:44:13'),
(51, 'USER', 'Usuário Mega atualizado pelo usuário Mega', '2024-03-28 01:45:18'),
(52, 'SYSTEM', 'Configurações do sistema atualizadas pelo usuário Mega', '2024-03-28 01:46:28'),
(53, 'SYSTEM', 'Configurações do sistema atualizadas pelo usuário Mega', '2024-03-28 01:46:56'),
(54, 'SYSTEM', 'Configurações do sistema atualizadas pelo usuário Mega', '2024-03-28 01:47:27'),
(55, 'PRODUCT', 'Produto Sandero teste adicionado pelo usuário Mega', '2024-03-28 01:50:40'),
(56, 'PRODUCT', 'Produto Sandero teste atualizado pelo usuário Mega', '2024-03-28 01:53:21'),
(57, 'SYSTEM', 'Configurações do sistema atualizadas pelo usuário Mega', '2024-03-28 01:53:48'),
(58, 'SYSTEM', 'Configurações do sistema atualizadas pelo usuário Mega', '2024-03-28 01:54:12'),
(59, 'ORDER', 'Pedido 24 aprovado manualmente pelo usuário Mega', '2024-03-28 01:56:20'),
(60, 'SYSTEM', 'Configurações do sistema atualizadas pelo usuário Mega', '2024-03-28 02:01:44'),
(61, 'SYSTEM', 'Configurações do sistema atualizadas pelo usuário Mega', '2024-03-28 02:01:54'),
(62, 'SYSTEM', 'Configurações do sistema atualizadas pelo usuário Mega', '2024-03-28 02:02:06'),
(63, 'SYSTEM', 'Configurações do sistema atualizadas pelo usuário Mega', '2024-03-28 02:02:17'),
(64, 'SYSTEM', 'Configurações do sistema atualizadas pelo usuário Mega', '2024-03-28 02:02:32'),
(65, 'SYSTEM', 'Configurações do sistema atualizadas pelo usuário Mega', '2024-03-28 02:02:48'),
(66, 'SYSTEM', 'Configurações do sistema atualizadas pelo usuário Mega', '2024-03-28 02:03:04'),
(67, 'SYSTEM', 'Configurações do sistema atualizadas pelo usuário Mega', '2024-03-28 02:03:15'),
(68, 'SYSTEM', 'Configurações do sistema atualizadas pelo usuário Mega', '2024-03-28 02:03:29'),
(69, 'SYSTEM', 'Configurações do sistema atualizadas pelo usuário Mega', '2024-03-28 02:03:42'),
(70, 'ORDER', 'Pedido 25 aprovado manualmente pelo usuário Mega', '2024-03-28 02:07:47'),
(71, 'ORDER', 'Pedido 26 aprovado manualmente pelo usuário Mega', '2024-03-28 02:15:12'),
(72, 'SYSTEM', 'Configurações do sistema atualizadas pelo usuário Mega', '2024-03-28 03:44:17'),
(73, 'PRODUCT', 'Produto Limitado 1 por cliente adicionado pelo usuário Mega', '2024-03-28 04:00:19'),
(74, 'PRODUCT', 'Produto Limitado 1 por cliente atualizado pelo usuário Mega', '2024-03-28 04:00:51'),
(75, 'USER', 'Usuário Mega atualizado pelo usuário Mega', '2024-03-28 04:01:35'),
(76, 'USER', 'Usuário Elias  atualizado pelo usuário Elias ', '2024-03-28 12:31:42'),
(77, 'ORDER', 'Pedido 29 aprovado manualmente pelo usuário Elias ', '2024-03-28 13:20:35'),
(78, 'ORDER', 'Pedido 30 aprovado manualmente pelo usuário Elias ', '2024-03-28 13:45:38'),
(79, 'PRODUCT', 'Produto elias gomes adicionado pelo usuário Elias ', '2024-03-29 03:49:10'),
(80, 'PRODUCT', 'Produto elias gomes atualizado pelo usuário Elias ', '2024-03-29 03:49:23'),
(81, 'PRODUCT', 'Produto Lucas Bonfim adicionado pelo usuário Elias ', '2024-03-29 04:01:17'),
(82, 'PRODUCT', 'Produto Lucas Bonfim atualizado pelo usuário Elias ', '2024-03-29 04:01:32'),
(83, 'PRODUCT', 'Produto Lucas Bonfim atualizado pelo usuário Elias ', '2024-03-29 04:02:30'),
(84, 'PRODUCT', 'Produto 20 PARA CONCORRER 400 adicionado pelo usuário Elias ', '2024-03-29 21:45:47'),
(85, 'PRODUCT', 'Produto 20 PARA CONCORRER 400 atualizado pelo usuário Elias ', '2024-03-29 21:46:05'),
(86, 'PRODUCT', 'Produto 20 PARA CONCORRER 400 atualizado pelo usuário Elias ', '2024-03-29 21:48:04'),
(87, 'SYSTEM', 'Configurações do sistema atualizadas pelo usuário Elias ', '2024-03-29 21:50:18'),
(88, 'SYSTEM', 'Configurações do sistema atualizadas pelo usuário Elias ', '2024-03-29 21:51:41'),
(89, 'PRODUCT', 'Produto AÇÃO START 2015 + R$ 10 MIL  REAIS NO PRIMEIRO PRÊMIO 🏆 adicionado pelo usuário Elias ', '2024-03-29 22:03:20'),
(90, 'PRODUCT', 'Produto AÇÃO START 2015 + R$ 10 MIL  REAIS NO PRIMEIRO PRÊMIO 🏆 atualizado pelo usuário Elias ', '2024-03-29 22:03:45'),
(91, 'PRODUCT', 'Produto AÇÃO START 2015 + R$ 10 MIL  REAIS NO PRIMEIRO PRÊMIO 🏆 atualizado pelo usuário Elias ', '2024-03-29 22:04:49'),
(92, 'PRODUCT', 'Produto AÇÃO START 2015 + R$ 10 MIL  REAIS NO PRIMEIRO PRÊMIO 🏆 atualizado pelo usuário Elias ', '2024-03-29 22:06:51'),
(93, 'PRODUCT', 'Produto 20 PARA CONCORRER 400 adicionado pelo usuário Elias ', '2024-03-29 22:36:06'),
(94, 'PRODUCT', 'Produto 20 PARA CONCORRER 400 atualizado pelo usuário Elias ', '2024-03-29 22:36:43'),
(95, 'PRODUCT', 'Produto 20 PARA CONCORRER 400 atualizado pelo usuário Elias ', '2024-03-29 22:37:17'),
(96, 'ORDER', 'Pedido manual 46 criado pelo usuário Elias ', '2024-03-29 22:43:07'),
(97, 'SYSTEM', 'Configurações do sistema atualizadas pelo usuário Elias ', '2024-03-29 22:47:15'),
(98, 'SYSTEM', 'Configurações do sistema atualizadas pelo usuário ', '2024-03-29 22:48:07'),
(99, 'PRODUCT', 'Produto AÇÃO START 2015 + R$ 10 MIL  REAIS NO PRIMEIRO PRÊMIO 🏆 atualizado pelo usuário Elias ', '2024-03-29 22:54:14'),
(100, 'PRODUCT', 'Produto AÇÃO START 2015 + R$ 10 MIL  REAIS NO PRIMEIRO PRÊMIO 🏆 adicionado pelo usuário Elias ', '2024-03-29 22:59:55'),
(101, 'PRODUCT', 'Produto AÇÃO START 2015 + R$ 10 MIL  REAIS NO PRIMEIRO PRÊMIO 🏆 atualizado pelo usuário Elias ', '2024-03-29 23:01:23'),
(102, 'PRODUCT', 'Produto AÇÃO START 2015 + R$ 10 MIL  REAIS NO PRIMEIRO PRÊMIO 🏆 atualizado pelo usuário Elias ', '2024-03-29 23:04:54'),
(103, 'PRODUCT', 'Produto 🏆 AÇÃO START 2015 + R$ 10 MIL OU R$ 20 MIL NO PIX 🏆 atualizado pelo usuário Elias ', '2024-03-29 23:11:03'),
(104, 'PRODUCT', 'Produto 🏆 AÇÃO START 2015 + R$ 10 MIL 🏆 atualizado pelo usuário Elias ', '2024-03-29 23:12:25'),
(105, 'ORDER', 'Pedido manual 96 criado pelo usuário Elias ', '2024-03-29 23:23:34'),
(106, 'ORDER', 'Pedido manual 97 criado pelo usuário Elias ', '2024-03-29 23:23:34'),
(107, 'ORDER', 'Pedido 97 deletado pelo usuário Elias ', '2024-03-29 23:24:08'),
(108, 'ORDER', 'Pedido 96 deletado pelo usuário Elias ', '2024-03-29 23:24:12'),
(109, 'ORDER', 'Pedido manual 98 criado pelo usuário Elias ', '2024-03-29 23:24:36'),
(110, 'SYSTEM', 'Configurações do sistema atualizadas pelo usuário Elias ', '2024-03-29 23:40:01'),
(111, 'SYSTEM', 'Configurações do sistema atualizadas pelo usuário Elias ', '2024-03-29 23:40:23'),
(112, 'SYSTEM', 'Configurações do sistema atualizadas pelo usuário Elias ', '2024-03-29 23:41:00'),
(113, 'PRODUCT', 'Produto 🏆 AÇÃO START 2015 + R$ 10 MIL 🏆 atualizado pelo usuário Elias ', '2024-03-29 23:43:33'),
(114, 'PRODUCT', 'Produto 🏆 AÇÃO START 2015 + R$ 10 MIL 🏆 atualizado pelo usuário Elias ', '2024-03-29 23:44:53'),
(115, 'PRODUCT', 'Produto 🏆 AÇÃO START 2015 + R$ 10 MIL 🏆 atualizado pelo usuário Elias ', '2024-03-29 23:45:21'),
(116, 'PRODUCT', 'Produto 🏆 AÇÃO START 2015 + R$ 10 MIL 🏆 atualizado pelo usuário Elias ', '2024-03-29 23:46:30'),
(117, 'PRODUCT', 'Produto 🏆 AÇÃO START 2015 + R$ 10 MIL 🏆 atualizado pelo usuário Elias ', '2024-03-29 23:47:36'),
(118, 'PRODUCT', 'Produto 🏆 AÇÃO START 2015 + R$ 10 MIL 🏆 atualizado pelo usuário Elias ', '2024-03-29 23:49:06'),
(119, 'PRODUCT', 'Produto 🏆 AÇÃO START 2015 + R$ 10 MIL 🏆 atualizado pelo usuário Elias ', '2024-03-29 23:50:10'),
(120, 'SYSTEM', 'Configurações do sistema atualizadas pelo usuário Elias ', '2024-03-29 23:51:04'),
(121, 'SYSTEM', 'Configurações do sistema atualizadas pelo usuário Elias ', '2024-03-29 23:51:28'),
(122, 'SYSTEM', 'Configurações do sistema atualizadas pelo usuário Elias ', '2024-03-29 23:52:13'),
(123, 'ORDER', 'Pedido 99 aprovado manualmente pelo usuário Elias ', '2024-03-29 23:59:34'),
(124, 'ORDER', 'Pedido 100 aprovado manualmente pelo usuário Elias ', '2024-03-30 00:01:57'),
(125, 'PRODUCT', 'Produto 🏆 AÇÃO START 2015 + R$ 10 MIL 🏆 atualizado pelo usuário Elias ', '2024-03-30 00:03:53'),
(126, 'PRODUCT', 'Produto 🏆 AÇÃO START 2015 + R$ 10 MIL 🏆 atualizado pelo usuário Elias ', '2024-03-30 00:06:22'),
(127, 'ORDER', 'Pedido 102 aprovado manualmente pelo usuário Elias ', '2024-03-30 00:08:29'),
(128, 'ORDER', 'Pedido 103 aprovado manualmente pelo usuário Elias ', '2024-03-30 00:10:23'),
(129, 'ORDER', 'Pedido 104 aprovado manualmente pelo usuário Elias ', '2024-03-30 00:11:56'),
(130, 'PRODUCT', 'Produto 🏆 AÇÃO START 2015 + R$ 10 MIL 🏆 atualizado pelo usuário Elias ', '2024-03-30 00:23:49'),
(131, 'ORDER', 'Pedido 106 aprovado manualmente pelo usuário Elias ', '2024-03-30 00:25:00'),
(132, 'ORDER', 'Pedido 107 aprovado manualmente pelo usuário Elias ', '2024-03-30 00:26:59'),
(133, 'PRODUCT', 'Produto 🏆 AÇÃO START 2015 + R$ 10 MIL 🏆 atualizado pelo usuário Elias ', '2024-03-30 01:31:34'),
(134, 'PRODUCT', 'Produto Sandero teste atualizado pelo usuário Elias ', '2024-03-30 01:49:40'),
(135, 'PRODUCT', 'Produto 🏆 AÇÃO START 2015 + R$ 10 MIL 🏆 atualizado pelo usuário Elias ', '2024-03-30 01:50:15'),
(136, 'ORDER', 'Pedido 107 deletado pelo usuário ', '2024-03-30 01:52:29'),
(137, 'ORDER', 'Pedido 106 deletado pelo usuário Elias ', '2024-03-30 01:52:41'),
(138, 'ORDER', 'Pedido 105 deletado pelo usuário Elias ', '2024-03-30 01:52:48'),
(139, 'ORDER', 'Pedido 104 deletado pelo usuário Elias ', '2024-03-30 01:52:54'),
(140, 'ORDER', 'Pedido 103 deletado pelo usuário Elias ', '2024-03-30 01:52:59'),
(141, 'ORDER', 'Pedido 102 deletado pelo usuário Elias ', '2024-03-30 01:53:05'),
(142, 'ORDER', 'Pedido 101 deletado pelo usuário Elias ', '2024-03-30 01:53:09'),
(143, 'ORDER', 'Pedido 100 deletado pelo usuário Elias ', '2024-03-30 01:53:14'),
(144, 'ORDER', 'Pedido 108 aprovado manualmente pelo usuário Elias ', '2024-03-30 01:55:00'),
(145, 'ORDER', 'Pedido 108 deletado pelo usuário ', '2024-03-30 01:57:55'),
(146, 'ORDER', 'Pedido 109 aprovado manualmente pelo usuário Elias ', '2024-03-30 01:58:57'),
(147, 'PRODUCT', 'Produto 🏆 AÇÃO START 2015 + R$ 10 MIL 🏆 atualizado pelo usuário Elias ', '2024-03-30 02:02:25'),
(148, 'ORDER', 'Pedido 109 deletado pelo usuário Elias ', '2024-03-30 02:02:35'),
(149, 'ORDER', 'Pedido 110 aprovado manualmente pelo usuário Elias ', '2024-03-30 02:03:42'),
(150, 'ORDER', 'Pedido 111 aprovado manualmente pelo usuário Elias ', '2024-03-30 02:04:33'),
(151, 'ORDER', 'Pedido 112 aprovado manualmente pelo usuário Elias ', '2024-03-30 02:05:18'),
(152, 'ORDER', 'Pedido 113 aprovado manualmente pelo usuário Elias ', '2024-03-30 02:05:54'),
(153, 'ORDER', 'Pedido 114 aprovado manualmente pelo usuário Elias ', '2024-03-30 02:06:40'),
(154, 'PRODUCT', 'Produto 🏆 AÇÃO START 2015 + R$ 10 MIL 🏆 atualizado pelo usuário Elias ', '2024-03-30 02:07:37'),
(155, 'ORDER', 'Pedido 114 deletado pelo usuário Elias ', '2024-03-30 02:07:48'),
(156, 'ORDER', 'Pedido 110 deletado pelo usuário Elias ', '2024-03-30 02:07:55'),
(157, 'ORDER', 'Pedido 111 deletado pelo usuário Elias ', '2024-03-30 02:07:59'),
(158, 'ORDER', 'Pedido 112 deletado pelo usuário Elias ', '2024-03-30 02:08:03'),
(159, 'ORDER', 'Pedido 113 deletado pelo usuário Elias ', '2024-03-30 02:08:08'),
(160, 'ORDER', 'Pedido 115 aprovado manualmente pelo usuário Elias ', '2024-03-30 02:08:33'),
(161, 'ORDER', 'Pedido 116 aprovado manualmente pelo usuário Elias ', '2024-03-30 02:09:06'),
(162, 'ORDER', 'Pedido 117 aprovado manualmente pelo usuário Elias ', '2024-03-30 02:09:42'),
(163, 'ORDER', 'Pedido 118 aprovado manualmente pelo usuário Elias ', '2024-03-30 02:10:15'),
(164, 'PRODUCT', 'Produto 🏆 AÇÃO START 2015 + R$ 10 MIL 🏆 atualizado pelo usuário Elias ', '2024-03-30 10:29:49'),
(165, 'PRODUCT', 'Produto 🏆 AÇÃO START 2015 + R$ 10 MIL 🏆 atualizado pelo usuário Elias ', '2024-03-30 10:29:55'),
(166, 'USER', 'Usuário Elias  atualizado pelo usuário Elias ', '2024-03-31 14:17:22'),
(167, 'SYSTEM', 'Configurações do sistema atualizadas pelo usuário Elias ', '2024-04-01 01:27:05'),
(168, 'SYSTEM', 'Configurações do sistema atualizadas pelo usuário Elias ', '2024-04-02 02:36:01'),
(169, 'SYSTEM', 'Configurações do sistema atualizadas pelo usuário Elias ', '2024-04-02 02:36:40'),
(170, 'PRODUCT', 'Produto teste de compra acima de 3mil cotas adicionado pelo usuário Elias ', '2024-04-02 03:01:45'),
(171, 'PRODUCT', 'Produto teste de compra acima de 3mil cotas atualizado pelo usuário Elias ', '2024-04-02 03:02:08'),
(172, 'PRODUCT', 'Produto teste de compra acima de 3mil cotas atualizado pelo usuário Elias ', '2024-04-02 03:08:16'),
(173, 'SYSTEM', 'Configurações do sistema atualizadas pelo usuário Elias ', '2024-04-03 03:55:19'),
(174, 'USER', 'Usuário Thiago Rifas atualizado pelo usuário Thiago Rifas', '2024-04-03 03:56:03'),
(175, 'PRODUCT', 'Produto teste de compra acima de 3mil cotas atualizado pelo usuário Thiago Rifas', '2024-05-21 06:08:30'),
(176, 'PRODUCT', 'Produto Honda 160 2024 evento teste 1 milhão de cotas atualizado pelo usuário Thiago Rifas', '2024-05-21 06:09:28'),
(177, 'PRODUCT', 'Produto Golf GTI adicionado pelo usuário Thiago Rifas', '2024-05-21 23:23:40'),
(178, 'PRODUCT', 'Produto Golf GTI atualizado pelo usuário Thiago Rifas', '2024-05-21 23:23:52'),
(179, 'PRODUCT', 'Produto Bruno matheus Alves de souza adicionado pelo usuário Thiago Rifas', '2024-05-21 23:29:46'),
(180, 'PRODUCT', 'Produto novorifa adicionado pelo usuário Thiago Rifas', '2024-05-21 23:32:57'),
(181, 'SYSTEM', 'Configurações do sistema atualizadas pelo usuário Thiago Rifas', '2024-05-21 23:33:05'),
(182, 'SYSTEM', 'Configurações do sistema atualizadas pelo usuário Thiago Rifas', '2024-05-21 23:33:10'),
(183, 'PRODUCT', 'Produto novorifa atualizado pelo usuário Thiago Rifas', '2024-05-22 00:01:09'),
(184, 'ORDER', 'Pedido 210 deletado pelo usuário Thiago Rifas', '2024-05-22 00:04:25'),
(185, 'PRODUCT', 'Produto novorifa3 adicionado pelo usuário Thiago Rifas', '2024-05-22 00:09:54'),
(186, 'PRODUCT', 'Produto teste de compra acima de 3mil cotas atualizado pelo usuário Thiago Rifas', '2024-05-22 00:13:37'),
(187, 'ORDER', 'Pedido 213 deletado pelo usuário Thiago Rifas', '2024-05-22 00:14:15'),
(188, 'ORDER', 'Pedido 212 deletado pelo usuário Thiago Rifas', '2024-05-22 00:18:26'),
(189, 'ORDER', 'Pedido 211 deletado pelo usuário Thiago Rifas', '2024-05-22 00:18:29'),
(190, 'SYSTEM', 'Configurações do sistema atualizadas pelo usuário Thiago Rifas', '2024-05-22 00:33:25'),
(191, 'SYSTEM', 'Configurações do sistema atualizadas pelo usuário Thiago Rifas', '2024-05-22 00:33:29'),
(192, 'ORDER', 'Pedido 215 deletado pelo usuário Thiago Rifas', '2024-05-22 00:44:38'),
(193, 'ORDER', 'Pedido 214 deletado pelo usuário Thiago Rifas', '2024-05-22 00:44:41'),
(194, 'ORDER', 'Pedido 209 deletado pelo usuário Thiago Rifas', '2024-05-22 00:44:43'),
(195, 'ORDER', 'Pedido 208 deletado pelo usuário Thiago Rifas', '2024-05-22 00:44:45'),
(196, 'ORDER', 'Pedido 207 deletado pelo usuário Thiago Rifas', '2024-05-22 00:44:47'),
(197, 'ORDER', 'Pedido 206 deletado pelo usuário Thiago Rifas', '2024-05-22 00:44:49'),
(198, 'SYSTEM', 'Configurações do sistema atualizadas pelo usuário Thiago Rifas', '2024-05-22 00:47:27'),
(199, 'SYSTEM', 'Configurações do sistema atualizadas pelo usuário Thiago Rifas', '2024-05-22 00:47:35'),
(200, 'SYSTEM', 'Configurações do sistema atualizadas pelo usuário Thiago Rifas', '2024-05-22 00:47:42'),
(201, 'SYSTEM', 'Configurações do sistema atualizadas pelo usuário Thiago Rifas', '2024-05-22 04:41:08'),
(202, 'SYSTEM', 'Configurações do sistema atualizadas pelo usuário Thiago Rifas', '2024-05-22 21:43:59'),
(203, 'PRODUCT', 'Produto teste rifa adicionado pelo usuário Thiago Rifas', '2024-05-22 22:12:48'),
(204, 'PRODUCT', 'Produto teste rifa atualizado pelo usuário Thiago Rifas', '2024-05-23 04:39:52'),
(205, 'PRODUCT', 'Produto teste rifa atualizado pelo usuário Thiago Rifas', '2024-05-23 04:40:03'),
(206, 'ORDER', 'Pedido 243 deletado pelo usuário Thiago Rifas', '2024-05-23 04:53:15'),
(207, 'ORDER', 'Pedido 242 deletado pelo usuário Thiago Rifas', '2024-05-23 04:53:17'),
(208, 'ORDER', 'Pedido 241 deletado pelo usuário Thiago Rifas', '2024-05-23 04:53:19'),
(209, 'PRODUCT', 'Produto 1 m numeros atualizado pelo usuário Thiago Rifas', '2024-05-27 23:20:39'),
(210, 'PRODUCT', 'Produto 10 m numeros atualizado pelo usuário Thiago Rifas', '2024-05-27 23:20:48'),
(211, 'PRODUCT', 'Produto m adicionado pelo usuário Thiago Rifas', '2024-05-27 23:21:18'),
(212, 'PRODUCT', 'Produto 5m numeros atualizado pelo usuário Thiago Rifas', '2024-05-27 23:21:29'),
(213, 'SYSTEM', 'Configurações do sistema atualizadas pelo usuário Thiago Rifas', '2024-05-27 23:22:39'),
(214, 'SYSTEM', 'Configurações do sistema atualizadas pelo usuário Thiago Rifas', '2024-05-28 02:31:25'),
(215, 'SYSTEM', 'Configurações do sistema atualizadas pelo usuário Thiago Rifas', '2024-05-28 02:40:13'),
(216, 'SYSTEM', 'Configurações do sistema atualizadas pelo usuário Thiago Rifas', '2024-05-28 02:41:07'),
(217, 'ORDER', 'Pedido 305 aprovado manualmente pelo usuário Thiago Rifas', '2024-05-28 02:42:40'),
(218, 'SYSTEM', 'Configurações do sistema atualizadas pelo usuário Thiago Rifas', '2024-05-28 02:42:42'),
(219, 'ORDER', 'Pedido 244 deletado pelo usuário Thiago Rifas', '2024-05-28 02:43:15'),
(220, 'SYSTEM', 'Configurações do sistema atualizadas pelo usuário Thiago Rifas', '2024-05-28 02:43:52'),
(221, 'ORDER', 'Pedido 306 aprovado manualmente pelo usuário Thiago Rifas', '2024-05-28 02:43:55'),
(222, 'SYSTEM', 'Configurações do sistema atualizadas pelo usuário Thiago Rifas', '2024-05-28 02:45:54'),
(223, 'ORDER', 'Pedido 311 deletado pelo usuário Thiago Rifas', '2024-05-28 03:08:09'),
(224, 'ORDER', 'Pedido 310 deletado pelo usuário Thiago Rifas', '2024-05-28 03:08:13'),
(225, 'ORDER', 'Pedido 312 aprovado manualmente pelo usuário Thiago Rifas', '2024-05-28 03:08:29'),
(226, 'SYSTEM', 'Configurações do sistema atualizadas pelo usuário Thiago Rifas', '2024-05-28 03:13:33'),
(227, 'PRODUCT', 'Produto RIFA 10 MILHOES DE BILHETE adicionado pelo usuário Thiago Rifas', '2024-05-28 14:01:48'),
(228, 'SYSTEM', 'Configurações do sistema atualizadas pelo usuário Drope', '2024-05-28 14:13:51'),
(229, 'SYSTEM', 'Configurações do sistema atualizadas pelo usuário Drope', '2024-05-28 14:13:58'),
(230, 'USER', 'Usuário Thiago Rifas atualizado pelo usuário Thiago Rifas', '2024-05-28 14:14:36'),
(231, 'PRODUCT', 'Produto RIFA 10 MILHOES DE BILHETE atualizado pelo usuário Thiago Rifas', '2024-05-28 14:17:04'),
(232, 'PRODUCT', 'Produto RIFA 10 MILHOES DE BILHETE atualizado pelo usuário Thiago Rifas', '2024-05-28 14:19:37'),
(233, 'PRODUCT', 'Produto FAZENDINHA METADE GRUPO adicionado pelo usuário Thiago Rifas', '2024-05-28 14:40:21'),
(234, 'PRODUCT', 'Produto FAZENDINHA METADE GRUPO atualizado pelo usuário Thiago Rifas', '2024-05-28 14:41:21'),
(235, 'PRODUCT', 'Produto FAZENDINHA GRUPO INTEIRO  adicionado pelo usuário Thiago Rifas', '2024-05-28 14:42:05'),
(236, 'PRODUCT', 'Produto FAZENDINHA METADE GRUPO atualizado pelo usuário Thiago Rifas', '2024-05-28 14:42:30'),
(237, 'PRODUCT', 'Produto MODELO RIFA GRÁTIS adicionado pelo usuário Thiago Rifas', '2024-05-28 14:45:40'),
(238, 'PRODUCT', 'Produto MODELO RIFA GRÁTIS atualizado pelo usuário Thiago Rifas', '2024-05-28 14:45:55'),
(239, 'PRODUCT', 'Produto MODELO RIFA GRÁTIS atualizado pelo usuário Thiago Rifas', '2024-05-28 14:47:36'),
(240, 'PRODUCT', 'Produto MODELO RIFA NUMEROS adicionado pelo usuário Thiago Rifas', '2024-05-28 14:48:52'),
(241, 'PRODUCT', 'Produto MODELO RIFA NUMEROS atualizado pelo usuário Thiago Rifas', '2024-05-28 14:49:06'),
(242, 'SYSTEM', 'Configurações do sistema atualizadas pelo usuário Thiago Rifas', '2024-05-28 14:52:20'),
(243, 'SYSTEM', 'Configurações do sistema atualizadas pelo usuário Thiago Rifas', '2024-05-28 14:53:11'),
(244, 'SYSTEM', 'Configurações do sistema atualizadas pelo usuário Thiago Rifas', '2024-05-28 14:53:26'),
(245, 'USER', 'Usuário Thiago Rifas atualizado pelo usuário Thiago Rifas', '2024-05-28 14:59:15'),
(246, 'ORDER', 'Pedido 320 deletado pelo usuário Thiago Rifas', '2024-05-28 15:01:04'),
(247, 'ORDER', 'Pedido 319 deletado pelo usuário Thiago Rifas', '2024-05-28 15:01:06'),
(248, 'ORDER', 'Pedido 321 aprovado manualmente pelo usuário Thiago Rifas', '2024-05-28 15:01:17'),
(249, 'ORDER', 'Pedido 322 aprovado manualmente pelo usuário Thiago Rifas', '2024-05-28 15:01:41'),
(250, 'ORDER', 'Pedido 322 deletado pelo usuário Thiago Rifas', '2024-05-28 15:02:11'),
(251, 'ORDER', 'Pedido 321 deletado pelo usuário Thiago Rifas', '2024-05-28 15:02:13'),
(252, 'ORDER', 'Pedido 328 deletado pelo usuário Thiago Rifas', '2024-05-29 17:58:08'),
(253, 'ORDER', 'Pedido 327 deletado pelo usuário Thiago Rifas', '2024-05-29 17:58:10'),
(254, 'ORDER', 'Pedido 326 deletado pelo usuário Thiago Rifas', '2024-05-29 17:58:12'),
(255, 'ORDER', 'Pedido 325 deletado pelo usuário Thiago Rifas', '2024-05-29 17:58:14'),
(256, 'ORDER', 'Pedido 324 deletado pelo usuário Thiago Rifas', '2024-05-29 17:58:16'),
(257, 'ORDER', 'Pedido 323 deletado pelo usuário Thiago Rifas', '2024-05-29 17:58:18'),
(258, 'PRODUCT', 'Produto MODELO RIFA NUMEROS atualizado pelo usuário Thiago Rifas', '2024-05-29 17:58:35'),
(259, 'PRODUCT', 'Produto MODELO RIFA GRÁTIS atualizado pelo usuário Thiago Rifas', '2024-05-29 17:58:49'),
(260, 'PRODUCT', 'Produto FAZENDINHA GRUPO INTEIRO  atualizado pelo usuário Thiago Rifas', '2024-05-29 18:00:22'),
(261, 'USER', 'Usuário Thiago Rifas atualizado pelo usuário Thiago Rifas', '2024-05-29 20:04:33'),
(262, 'ORDER', 'Pedido 342 aprovado manualmente pelo usuário Thiago Rifas', '2024-05-29 19:05:21'),
(263, 'PRODUCT', 'Produto MODELO RIFA NUMEROS atualizado pelo usuário Thiago Rifas', '2024-05-29 19:06:05'),
(264, 'PRODUCT', 'Produto MODELO RIFA GRÁTIS atualizado pelo usuário Thiago Rifas', '2024-05-29 19:06:18'),
(265, 'PRODUCT', 'Produto FAZENDINHA GRUPO INTEIRO  atualizado pelo usuário Thiago Rifas', '2024-05-29 19:06:34'),
(266, 'ORDER', 'Pedido 344 aprovado manualmente pelo usuário Thiago Rifas', '2024-05-29 19:08:06'),
(267, 'ORDER', 'Pedido 343 aprovado manualmente pelo usuário Thiago Rifas', '2024-05-29 19:08:08'),
(268, 'PRODUCT', 'Produto RIFA 10 MILHOES DE BILHETE atualizado pelo usuário Thiago Rifas', '2024-05-29 19:09:24'),
(269, 'SYSTEM', 'Configurações do sistema atualizadas pelo usuário Thiago Rifas', '2024-05-29 21:39:48'),
(270, 'SYSTEM', 'Configurações do sistema atualizadas pelo usuário Thiago Rifas', '2024-05-29 21:40:17');

-- --------------------------------------------------------

--
-- Estrutura para tabela `order_items`
--

CREATE TABLE `order_items` (
  `order_id` int(30) NOT NULL,
  `product_id` int(30) NOT NULL,
  `quantity` int(30) NOT NULL DEFAULT 0,
  `price` float(12,2) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Despejando dados para a tabela `order_items`
--

INSERT INTO `order_items` (`order_id`, `product_id`, `quantity`, `price`) VALUES
(342, 28, 301, 0.01),
(343, 28, 301, 0.01),
(344, 28, 601, 0.01),
(345, 28, 1, 0.01),
(346, 28, 601, 0.01),
(347, 28, 301, 0.01),
(348, 28, 301, 0.01),
(349, 28, 1, 0.01),
(350, 32, 1, 10.00),
(351, 28, 301, 0.01),
(352, 28, 1, 0.01),
(353, 28, 601, 0.01),
(354, 28, 5000, 0.01);

-- --------------------------------------------------------

--
-- Estrutura para tabela `order_list`
--

CREATE TABLE `order_list` (
  `id` int(30) NOT NULL,
  `code` varchar(100) NOT NULL,
  `customer_id` int(30) NOT NULL,
  `quantity` text DEFAULT NULL,
  `total_amount` float(12,2) NOT NULL DEFAULT 0.00,
  `status` tinyint(1) NOT NULL DEFAULT 0 COMMENT '1=pending\r\n2=paid\r\n3=cancelled\r\n',
  `date_created` datetime DEFAULT NULL,
  `date_updated` datetime DEFAULT NULL,
  `product_name` text NOT NULL,
  `order_token` varchar(100) NOT NULL,
  `order_numbers` text DEFAULT NULL,
  `product_id` int(11) NOT NULL,
  `payment_method` text DEFAULT NULL,
  `order_expiration` text DEFAULT NULL,
  `pix_code` text DEFAULT NULL,
  `pix_qrcode` text DEFAULT NULL,
  `id_mp` varchar(500) DEFAULT NULL,
  `txid` text DEFAULT NULL,
  `discount_amount` text DEFAULT NULL,
  `whatsapp_status` text DEFAULT NULL,
  `dwapi_status` text DEFAULT NULL,
  `referral_id` int(30) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Despejando dados para a tabela `order_list`
--

INSERT INTO `order_list` (`id`, `code`, `customer_id`, `quantity`, `total_amount`, `status`, `date_created`, `date_updated`, `product_name`, `order_token`, `order_numbers`, `product_id`, `payment_method`, `order_expiration`, `pix_code`, `pix_qrcode`, `id_mp`, `txid`, `discount_amount`, `whatsapp_status`, `dwapi_status`, `referral_id`) VALUES
(342, 'a0f468127f0c2', 40, '301', 3.01, 2, '2024-05-29 16:04:17', '2024-05-29 16:05:21', 'RIFA 10 MILHOES DE BILHETE', 'f4943c0e5d84bad9c6ec01a2da77211c', '5397677,9374674,0005231,6702126,1623907,3028515,2714891,4238621,9025421,9181221,2046407,8642318,8584004,4718017,7464581,1636253,8320498,2461380,3789188,9896953,4627469,0347814,5359484,8991536,6461638,5327390,5091008,2157283,1612221,1211056,1395188,9326862,2979636,8363922,0850020,1498563,3014732,9715591,3445511,3407307,7536339,1859713,8296998,9026178,7391756,9437104,9410075,8506204,4440656,6639548,5229280,7377658,2720031,0907500,2595817,3942550,5147213,2952561,6386035,0494957,4507504,2239760,2852991,7993259,2294449,5288446,8229857,4997395,6040804,7030097,5694913,0430272,5895097,2203116,8463099,4476868,6537429,1587997,3426259,7042847,8346066,3113168,9378479,1346551,0152880,5440881,1214970,6279658,5589132,9069933,3207241,4064516,4556887,3320121,0306992,7605434,4311020,0455490,0423113,6434249,5715462,4395568,4511764,8751720,5603355,8923032,5995948,6304989,4807989,8702821,8889032,6604792,3454298,0007866,5922462,8833840,5078308,5573340,5865302,6445174,3673585,4598935,2797518,4900770,0354032,8022465,8044582,3972224,6338211,6670350,4325765,2673279,7519445,6464876,2773537,7248618,8597927,9098871,7695545,2996900,2133645,3826017,7554538,2745429,5605321,1725323,7845739,4566988,6345736,4400478,7148278,1930791,9872737,9333612,4090422,5749695,6461419,3807275,6581969,7516513,1142421,1215689,0924180,7104223,3028839,5214257,3136712,2318195,3854975,4619917,1578095,0502981,3716257,7999702,3733495,7911145,9607155,4396480,9865284,7766088,6476895,1252972,3992455,6367482,6968698,4433829,1712770,7108802,5992314,4919830,5215951,1440956,9092020,4109869,0624070,1779285,7365711,3233208,8304964,0572613,2457277,1020841,5414655,9118175,5977191,2907433,9874278,9284749,5637695,4920983,2714955,6654548,1656101,3354932,3091428,5221196,2212025,9766822,6815781,1090793,1139943,4987238,4767036,7509262,9600595,4554074,2633106,2456397,4263147,0650352,2904135,5736984,6141809,8374784,6280458,1249167,4047099,3856504,2247226,3347052,9715636,6296811,8006821,4452676,8396796,3761334,2719311,0077842,0399436,7912094,7380218,9469174,8688792,0651316,6323732,1604478,2287701,5197144,5378279,8327590,6527864,6124078,0260471,5571145,7971643,1786788,0063719,9442677,2998727,5615236,0363199,2981702,5943903,6346963,7387560,5453324,3190575,1818748,7304583,1714674,1214180,8379742,2698904,3905485,3757702,1049561,1853899,4084278,8692324,5521043,3600252,5159576,1922742,0454973,5944139,4053976,1113721,9509063,9876263,7572279,7846239,', 28, 'Manual', '15', '00020126870014br.gov.bcb.pix2565pix.creditag.com.br/qr/v3/at/96548f2e-de99-4572-aecc-7b6d598db5865204000053039865802BR5925PIXCRED SOCIEDADE DE CRED6009SAO PAULO62070503***6304FFA7', 'https://api.qrserver.com/v1/create-qr-code/?size=150x150&data=00020126870014br.gov.bcb.pix2565pix.creditag.com.br/qr/v3/at/96548f2e-de99-4572-aecc-7b6d598db5865204000053039865802BR5925PIXCRED SOCIEDADE DE CRED6009SAO PAULO62070503***6304FFA7&choe=UTF', '899f1dc5-bb21-4900-afac-e8e95c0f1bec', NULL, '', '', NULL, NULL),
(343, 'fc33ce67d3efb', 40, '301', 3.01, 2, '2024-05-29 16:07:21', '2024-05-29 16:08:08', 'RIFA 10 MILHOES DE BILHETE', 'd6c4b58c080c8d2b41b9ae5dca4f58a8', '2692964,7969829,9927156,6753961,3453737,5227951,7987808,0646029,2962786,5915807,8494911,0774239,2844130,1414698,1609020,9487389,6012700,0116467,0833920,9135095,7989174,3130723,7105448,9964295,3905819,3505366,9769667,0691790,6807920,5501976,6845747,5567388,9460007,6004387,2893927,8580627,7264913,6324223,8251842,0196263,7214314,6587945,3839897,0872288,1118533,2591225,4783319,9514704,7923487,5759930,6012987,0858397,5823011,2095428,4604035,3365454,1957751,7818863,6582424,0553095,0373604,2632186,7780224,5909899,7650403,3888749,0838337,1761124,5412576,6112689,2018498,9032707,8648263,4259686,5997345,9877246,4786765,8649411,0994556,0515912,5077937,0580846,7429919,5550384,1271693,6614612,7945768,9241132,2020739,9527350,1352806,7216364,6973377,9826556,7427881,3486836,9741322,6918174,0774398,3375310,8485641,7923446,9278649,0569556,3044450,7659908,5417358,5469121,1631264,9169882,5051013,8069016,6339343,4736881,1164063,5790377,4174330,2754388,1289494,1368128,4536844,3344145,8035543,3212939,4902373,8837391,4887743,1350760,4715505,2127774,3455032,7347968,4236172,4473275,2705412,4269791,8563459,8194843,3051772,7662525,6443767,7998520,6330253,6389727,4287634,8472301,3003630,4705993,3634779,4414957,7157808,1332759,0557039,4628887,1618688,8881182,3958207,6661334,1426721,5284568,9117885,1882350,0490057,7619753,2204521,7675905,0277955,9562992,0606691,2470279,4546565,8902555,5982503,0109777,2906554,8663471,0901117,1401148,0624446,7888057,4050461,2381285,7475649,8485958,1944701,2935364,7226863,3164342,5968150,5028715,4872545,9357115,0038637,6883875,0802956,8140012,3247330,6193817,2638821,1124243,5246960,7770989,8572545,5600766,7827322,2851874,0647227,2657797,3006398,5909079,5920699,8385916,9716655,8888186,7789227,0901943,5902106,6569047,2809607,9829837,6287129,8213277,1452442,9863885,8723566,4310723,6493001,2964269,2791751,9233988,4020044,1808165,7272993,3196987,1836439,4047650,1030249,1704478,4208962,5666328,2222256,3194312,0964615,7208666,0605040,3345176,5247220,0033135,0844348,2036288,3830924,3246706,2511176,5167999,3008738,4211426,9587111,4432796,1006874,5150333,9307653,7752575,2855082,6495683,5199312,0628868,7865452,5491213,5795261,5488101,9421010,0121194,9947792,8151130,5667215,6645220,8278764,7670776,7352275,7482321,1902225,5116927,7067032,9612576,9249821,4006199,5110449,4140941,2632203,6683552,1742868,9875997,2025512,3232782,9026017,6853783,8514628,6316502,6986710,1457288,2989707,', 28, 'Manual', '15', '00020126870014br.gov.bcb.pix2565pix.creditag.com.br/qr/v3/at/29462a6a-526f-4b8e-b9ac-e5d6ec02362c5204000053039865802BR5925PIXCRED SOCIEDADE DE CRED6009SAO PAULO62070503***6304DE7D', 'https://api.qrserver.com/v1/create-qr-code/?size=150x150&data=00020126870014br.gov.bcb.pix2565pix.creditag.com.br/qr/v3/at/29462a6a-526f-4b8e-b9ac-e5d6ec02362c5204000053039865802BR5925PIXCRED SOCIEDADE DE CRED6009SAO PAULO62070503***6304DE7D&choe=UTF', '70c70647-38fa-4111-b55c-9c66e5bf51d0', NULL, '', '', NULL, NULL),
(344, 'c15e1d5511b25', 40, '601', 6.01, 2, '2024-05-29 16:07:45', '2024-05-29 16:08:06', 'RIFA 10 MILHOES DE BILHETE', '87ab4ad268b8ff3adae3be34590bb3a8', '9997556,8257522,8914143,9484553,9127154,5512409,9307157,1386182,1670472,3097319,8898302,5479708,6539192,1346159,6229124,3129249,4044111,0405501,3730604,3807707,4489909,4801053,7103518,5421769,4007648,9002173,1931545,6926405,9701602,4098337,7932955,2213847,9595392,3978887,7932110,8358739,8325258,0765553,0857947,2150137,1579680,9107020,4603001,3077903,3390974,2932725,0419901,0525383,3731505,8546447,1998254,7750535,5949552,3364784,5706545,1071281,8289435,9654042,2376648,4551112,4777321,0590751,9349533,2961940,2072328,2014238,0623621,3264350,2054067,3318347,3635555,7963776,8823420,3144320,9346607,3385609,1644060,9187649,6918138,8116773,5643487,8851325,0378467,4770469,7975967,3750171,5824209,2323794,1218150,9740925,7977369,2164269,3647069,0222755,0642327,7192142,1296801,1017735,1017134,2551320,1971868,9251740,6199420,6505163,1084894,0756678,1981104,2964826,2057171,9392374,9143384,8490973,3755657,9728795,5459337,4907917,1602705,6774229,0197578,3269407,3122113,1856933,1061369,5415742,4634542,7715302,9235402,2340165,5128350,4054517,9867487,3088581,5528111,8989273,7471626,1630801,4897825,4517103,9383719,8567223,8742602,2811161,5612117,7263856,9583456,1769836,6447874,8893152,0607247,0616504,6725811,6568247,4026449,0458242,0329165,8415506,0467340,0422801,5905953,1308528,1071338,2326022,6361787,6743651,8542219,2131491,9398919,8140095,2451300,5415691,6763271,3031953,0151613,9353507,6463524,7216019,0504073,6102719,7851166,3476805,0602670,8433161,8163522,0887820,7101546,4139759,7703743,4455445,8483550,1148109,1442352,7120377,3876356,7639178,5472068,0708580,5675508,8166494,6235947,4004625,5296481,2980885,5964595,9027094,4064115,3926905,1239593,2729179,3656225,5111791,7346222,1961099,4234247,0818495,7853724,5801133,5271556,8132558,9095630,4702414,6955474,8828283,1977524,7692328,3979185,4832016,1499990,1873128,6506205,4205306,8076198,3832420,9365433,7646270,2005901,2921005,4760814,0831298,3950134,6546130,2004558,8375445,4956090,8853484,2771599,5894275,2641989,0719587,9603572,8721735,4816408,5550873,6359745,4193262,3909737,2165618,0534124,9139628,7888033,5451018,4426132,2446749,9378109,9060495,4924722,1165792,6628414,2045433,1175954,0250972,7256105,8099771,1839305,8755552,1807702,3921110,3471769,6697219,7971110,5319847,9077295,1316665,6467779,4091328,1706448,3184600,7672245,8746254,4938050,1689138,9191366,3962273,2033882,0148416,7197216,6250270,8440263,6250703,5185645,7906621,7802422,7858806,0041092,2312567,3821832,3549768,8822984,2329153,4569229,1729848,2351762,4771141,5984975,4304914,3254760,6323451,1211473,6098346,4667057,0970035,0261715,5627798,2969620,8384688,0968337,2353286,5536865,4619969,8686904,0085567,2183058,4313389,8325308,2969913,5931601,1616884,9175722,0702906,8710468,2028773,2279915,1256164,5395069,9433340,3308478,1138297,3234584,4031502,2698758,6257048,6832868,4552530,7317902,8018629,7609973,9284327,9972845,8183602,9305007,8052045,7782148,4285149,5290423,4333249,6094802,5268482,3762786,8430705,9627855,9191853,0122088,2578783,9515372,1135772,0577379,1064965,2130071,8595688,1524515,3326437,2019476,1061143,1623598,1173854,2904092,6255907,8094763,0825217,1000929,0978075,4013438,6158260,4577352,1289048,8754209,1958561,3047470,3159404,7808955,4697456,5089608,3042831,1997612,6710790,3405808,0020215,1695550,0901391,1017008,4902831,3968857,7625323,6568240,3192355,0494554,9275109,5010187,1825477,8615481,4289507,1092996,5409747,4118015,2567050,2776432,1792722,0662701,9021620,2846609,2441390,3897473,1869749,8898113,1099415,5033636,9552111,5356036,3677700,1114511,7206226,2599778,9569404,8133958,2234153,8577707,7676789,7174746,8823706,8521574,0441311,4913593,7429878,6145175,5995132,5687594,8997252,0989251,5143087,3456954,2688155,9332533,8616108,1500029,1509654,3087704,9871263,1928016,9558803,0939743,0624457,3395368,0243315,9135064,0808016,5635792,2694413,8097557,8452032,6597926,9947793,7610644,7872995,7267583,4845645,3171416,1351843,2197986,9117837,7067489,4693511,6997789,6733969,2745875,4135962,5404551,9053001,0305298,0518207,5151022,8031385,8148991,2828406,9391040,5672329,5316033,7474504,3310550,9544825,3742923,0791895,5656121,9328860,7340756,7021268,3498195,6619876,1080436,9230497,5158173,4171486,0703536,5381243,6351715,7589099,5807233,0562934,8637868,2361853,9785825,3968724,7589811,8655725,9810140,7795380,2464344,7268570,9813323,6140322,7467070,1734680,9622725,2071237,7613899,8599171,0695788,2682514,8442225,7482542,6392190,8187502,4099198,7348930,2404232,4757355,7578086,1562243,9656766,2557180,7490097,4072567,7940907,9167614,3082219,4244180,4817676,5479507,9696921,4255894,9979329,1979712,6746769,0262662,0809163,0244615,8790117,8188546,5782824,1665979,3317123,7776945,1184840,7967215,7783689,2647750,9303719,8612502,6647944,0414745,6765158,1884069,2963991,9793939,1612799,0911761,0120154,3696746,4807521,9100883,3134576,3470103,7605159,', 28, 'Manual', '15', '00020126870014br.gov.bcb.pix2565pix.creditag.com.br/qr/v3/at/e6e107a7-762d-4d89-bede-447a1f81e5345204000053039865802BR5925PIXCRED SOCIEDADE DE CRED6009SAO PAULO62070503***6304583D', 'https://api.qrserver.com/v1/create-qr-code/?size=150x150&data=00020126870014br.gov.bcb.pix2565pix.creditag.com.br/qr/v3/at/e6e107a7-762d-4d89-bede-447a1f81e5345204000053039865802BR5925PIXCRED SOCIEDADE DE CRED6009SAO PAULO62070503***6304583D&choe=UTF', 'd43108f6-3323-4117-84db-498846227041', NULL, '', '', NULL, NULL),
(345, '8e18a1e411445', 41, '1', 0.01, 1, '2024-05-29 16:08:46', NULL, 'RIFA 10 MILHOES DE BILHETE', 'e982635434e5789b0b749d65f45c6234', '0315751,', 28, 'Pagstar', '15', '', '', '', NULL, '', NULL, NULL, NULL),
(346, '507852fefda11', 40, '601', 6.01, 1, '2024-05-29 16:10:21', NULL, 'RIFA 10 MILHOES DE BILHETE', '425753e27dbf8af7b5ef3367356fe5a6', '5027007,1509594,0830967,7704782,1244655,7176980,9357537,9211820,0405517,6752490,7357554,9394241,0954463,8224470,8752226,7927918,0269174,8358628,6630288,0650126,3684498,6918413,3098593,7700412,0215613,6290236,6539796,7532742,9709424,4674559,3027204,1346274,3164001,5676475,1288622,2246867,7608240,2444320,7989612,7220668,4849229,8556272,3915721,9558593,3013082,6360711,8742523,4706745,0472338,2280688,8141092,0718169,2216462,9389855,2735212,7184499,2455839,0742991,2926289,4136427,8284375,2802224,1086016,5078620,6167156,4229938,9760383,8130709,3243470,9988921,3554681,4615634,5372075,0613473,7910607,6832888,3018451,0577903,9646603,8230661,6618742,4066322,1956496,7237261,8919744,7677550,2202671,7349742,2499402,2343650,3326558,4615971,3725993,4450560,7474900,4008841,0663125,4787007,9511810,3696334,3142840,8091874,8385505,9527481,9571173,2995823,6907145,6209377,3520565,6210752,5500830,8503702,5723561,6632933,5653793,4631674,0984276,9916765,3716396,3631851,8383863,0901373,7327345,1932368,0840369,6327192,1175417,8499544,0916683,6176212,8643732,7274376,0886981,8033039,0697444,4966260,7988067,8736432,4310287,5600646,6246545,8411753,1917794,4409300,7967900,3634308,8655836,1936220,3379784,2021848,0563752,5399189,9953516,5013962,7162445,9815274,9298845,2904768,0862245,4495046,9351274,0600311,8773600,9668423,6623024,7336476,9394125,2351580,9656827,5160576,6840739,8142449,5688918,6420379,4009319,7634327,1763269,8131785,0991435,0984975,3440180,5958901,8246468,2732051,1079036,4936816,4936217,8776915,5257835,6733793,9723489,3332500,0058870,8074827,5385672,8937258,6236554,2681923,4491986,8074884,2748747,0227306,4947164,9715994,4430070,1948655,1049527,1717406,8453956,9566739,0551285,3502479,8503315,3909229,7091284,6147755,2633818,6149214,5713958,1203977,7304153,6164321,1313226,1232749,5353055,8798258,5244280,4674438,4684383,2415271,8959456,2840827,8426005,0076648,5365188,1370674,5491325,4273536,8622988,0002362,5309812,5161034,1674339,7606122,1949005,7851321,2292870,8701358,6519038,4441391,8072803,9038147,7941962,9535544,6317001,9579789,7709203,0186110,5569138,9197216,7651822,5835168,4472129,0178801,0225647,5406717,2029355,8841621,2699847,6879865,6104068,3082090,4268978,4827518,0587121,6543756,0083486,3896103,9444746,7727857,7776102,0178388,0405815,7410999,0772163,0494934,2106309,4332383,8464670,3675219,6861528,0846064,4942998,1000437,7263208,6924512,6213834,5516310,6617057,6455338,6095273,5957974,8489528,5849963,0263926,8290031,7762203,6476694,0191958,4292018,0794400,8242854,2297516,1282356,2106207,1753484,8254993,9634182,9385369,9369674,6207327,9906903,1831439,5471261,6921248,5250078,2606092,7205062,1356132,9991318,4779155,2047452,6301131,3546801,9152658,3901091,9299254,0359869,2862226,6863775,1948670,9299308,8326665,4836051,4163401,8372084,2878232,3102596,7995492,4882156,0625783,0916324,9942520,3557604,8887423,2705042,3720974,3502553,9425994,2334042,9536705,9577851,9207797,6561617,6254291,9032595,2360701,8155648,4327262,1439716,9232348,7361656,3869100,3629712,8735993,8057647,7229372,7959489,9891353,3535691,6554390,1525084,8874555,3758072,0694677,7114579,3247303,7395087,1665043,6153961,4716407,9917070,5860648,4817340,3966597,8979982,5149942,7676556,1878925,2542222,1295323,8587660,4189827,9198596,7981902,7568088,6729329,3639471,1978296,7928942,0032446,4289295,4259288,0195622,0212522,7381255,0973015,0849678,3845396,4689293,5522074,8914138,9519585,4756009,1715407,4478067,1091805,5103469,0972124,9230191,7322833,1443721,4427633,7833136,2182910,1932224,7496325,5798988,5311977,5122636,5983994,8632430,2618765,1005807,0781238,7918038,5935168,5307508,4706897,1278727,1327135,0473338,3704554,2552927,2037604,5750641,4238791,2351596,3948184,9395489,8038793,9896564,1356862,0457071,3563417,8392925,1297549,3729663,4702035,5732652,1699502,8460094,6661602,2283900,8900768,2039881,1653382,5433085,2522501,6383858,8324897,3538083,7655165,1845454,5408674,7456979,7983681,1322608,1748452,6904496,3199649,2284361,3225247,4849498,0975568,9905808,4087196,6017443,1188490,1701431,9011295,3256532,7996094,2325157,3365046,7830918,6206938,5137447,2397270,2147687,1914396,4582831,2288383,0714570,8844042,6250398,9313248,6675898,6311075,8717759,6450397,6669238,7702310,7725073,8836992,4918710,7479410,4435974,9910880,1446625,5475575,9261245,2578521,3190694,5558405,1481013,5969219,5660622,4776537,1128366,5771283,7542650,5403234,3808537,0295171,0871814,3899038,2550274,4409749,1016809,7312044,4322712,0751464,9179413,6035943,4343002,2208025,3299796,9525736,7031458,5261676,7496879,3291843,8930501,7991107,5230606,8640569,0735596,7485019,4199932,9939846,5509689,1258569,5314789,6569847,1905797,4375829,8238802,6864722,6686814,8775085,9495874,1384484,2824999,9283773,4109787,5910492,7063510,2069895,6717107,2699533,6618660,2508573,5026435,3861964,4798350,7719468,7262927,6321349,6090549,0604931,', 28, 'Pagstar', '15', '00020126870014br.gov.bcb.pix2565pix.creditag.com.br/qr/v3/at/a400ac3a-8ae8-4b97-93ad-418d69db4b5a5204000053039865802BR5925PIXCRED SOCIEDADE DE CRED6009SAO PAULO62070503***63041D01', 'https://api.qrserver.com/v1/create-qr-code/?size=150x150&data=00020126870014br.gov.bcb.pix2565pix.creditag.com.br/qr/v3/at/a400ac3a-8ae8-4b97-93ad-418d69db4b5a5204000053039865802BR5925PIXCRED SOCIEDADE DE CRED6009SAO PAULO62070503***63041D01&choe=UTF', '5e5e42a3-46fe-41e3-b0e4-85281be8de39', NULL, '', NULL, NULL, NULL),
(347, '55e32641f6305', 40, '301', 3.01, 1, '2024-05-29 16:10:45', NULL, 'RIFA 10 MILHOES DE BILHETE', '44545939511f0195665f3dda8f1e3010', '9891832,9694817,0617333,1150395,3533450,2870593,6752510,0464556,1722802,7692546,8988090,2099443,1616742,3964040,3624638,6188904,0446457,1604007,1691494,8546736,2155213,4965445,0293134,2663176,6129771,7084168,3595922,0981058,8957267,5542988,8227941,8656543,5634443,6907647,6535613,6894049,5018294,1136134,1554693,9082440,3931221,9570471,2213824,4947289,8180071,4312439,1686783,4971802,8224024,0339323,6824692,9638451,9374630,5580077,9474768,5688667,9999115,3669725,5827634,1986943,4184432,7105518,1114214,1722267,0171596,4003356,0405750,2663972,6525100,1655118,4699297,1032087,3557848,7599572,4757841,8836001,8738861,9364486,6222849,7857468,1037207,7613203,3039483,9410044,1002552,8110487,6666023,2316739,0093523,9012852,1550574,4160808,8173344,4109429,3316923,1420071,7021804,0603493,5880896,7136261,9501773,3492796,8358026,2208255,5792972,4237348,5835119,1051624,4145742,4261934,6694364,1504867,1927272,9186822,9344260,1142411,6557207,8141992,9221871,3931932,8991965,1017977,2007927,7608339,2290772,9754412,6560298,9664982,2607515,8685967,9280520,1180892,9219995,1795202,4748397,7513573,0999602,8669378,9095881,7282928,2178785,2540400,1425568,9391991,3415227,8453656,9058529,3161189,1343218,1677918,1737333,4994087,9393673,5158410,6624249,5811498,5989834,6412743,2850425,4512638,2702955,0025121,1008419,1399264,8237653,6085898,4944732,6223352,7941546,9030632,8101523,7249020,6886321,9496602,0143757,5501691,7182906,9863139,9065725,7424294,2474131,6406722,7161776,2601584,1535407,0390787,6986772,2733925,7962012,9027468,3620549,2275491,7574242,5875372,4052348,4938418,0232326,6913189,7029242,6650223,0826560,3027239,9089135,5819882,1900632,5147087,2381554,4911716,5195220,0393669,6419151,0806620,5071241,3895656,3714512,0524913,7481612,5327739,4964962,6586606,3322831,7917563,1577405,9613948,1439021,9790867,2613438,9810562,1933376,9397011,5668650,6304869,1513921,0850579,4028360,6839964,0992972,1752102,3331037,3414297,2755450,7932926,4316888,5029762,9254300,7324986,3562261,1282035,7556795,1147560,6789693,6586379,7442310,8379637,5032403,7195589,9759003,9877349,5241421,8212860,9863123,4527616,5872244,4049227,8813445,5406904,3574253,4918333,1196716,9535740,6650628,5808591,1038525,2107680,1356127,0951161,4674024,4690945,0427836,4343187,2498352,1794528,3259376,5531149,6438655,1667751,9701354,4424394,9086200,2006356,1090464,1969738,6681039,5856077,8359579,8603722,1398759,2879600,0681122,4841089,8886739,', 28, 'Pagstar', '15', '00020126870014br.gov.bcb.pix2565pix.creditag.com.br/qr/v3/at/d99e30fd-1be9-4aee-bee2-a6550352bc055204000053039865802BR5925PIXCRED SOCIEDADE DE CRED6009SAO PAULO62070503***630452FF', 'https://api.qrserver.com/v1/create-qr-code/?size=150x150&data=00020126870014br.gov.bcb.pix2565pix.creditag.com.br/qr/v3/at/d99e30fd-1be9-4aee-bee2-a6550352bc055204000053039865802BR5925PIXCRED SOCIEDADE DE CRED6009SAO PAULO62070503***630452FF&choe=UTF', 'be23a2b9-706a-46e5-bea0-150737482e7f', NULL, '', NULL, NULL, NULL),
(348, '490db30c7c0b7', 40, '301', 3.01, 1, '2024-05-29 16:12:04', NULL, 'RIFA 10 MILHOES DE BILHETE', '095a035435141d0a1af73d850a3192e4', '4251985,2036017,4949512,9118024,0877625,9333256,4302870,0563031,5708385,9926478,8758318,1709778,4107909,4786799,9600300,3131207,3286321,4244305,2771148,9510681,2484729,8217979,2233444,2287983,7991166,3187158,1955567,2421708,1425482,2002120,3947496,6176012,8509263,6020398,0039604,3248450,8317435,5912287,3757013,3068415,1637087,4678411,1042858,6197338,0274193,8857103,3330688,7176428,3417193,1313644,6107508,1871655,8470407,9612220,4714147,2150284,2090209,5635198,7313866,9995260,5514209,3613370,6416551,3456338,9527290,3660939,0588602,3638937,7143553,5244961,8375633,4851719,5579988,0249378,7436954,0394908,8518687,9901677,6794211,8526684,6517251,5024366,1034480,4186195,8046067,4030346,1892363,9968983,1438836,5770129,8735558,3330910,0116954,9453928,6080474,1046358,3043259,8748736,0294792,8862685,9466444,2090839,7357829,4496687,4286168,1944942,2526665,4045133,6799974,6682217,3845297,8758000,6514725,0723914,6446154,3226329,3008175,2955730,5330457,7806221,0808697,4530130,9109132,2076851,4053496,7282203,6401803,5235601,1754960,9883679,2139815,1233285,4872752,6671672,6599917,9143843,9235778,4615741,3793415,9734866,9754874,1920663,3281414,1258709,0878227,8254726,2484718,0556733,7718860,0512182,5996372,3968124,1144157,0797535,4125667,6323978,4115082,9643787,3545065,1731895,5456896,1476887,3060115,7627431,7035576,5089150,3871721,7060140,0838908,7998203,1015873,3622939,3580561,4680921,0571399,7555437,7077942,4908446,4404273,4810947,9084415,5609718,3837493,2948963,4838477,9983387,4022845,1623532,4838585,1161796,7778657,3586784,7121745,2361308,2733256,7128809,1327206,9281957,2189483,8025181,8329229,2567974,5779042,6551860,6629694,1687307,5716053,2514012,3770988,8885683,8331923,6062388,5006100,7902075,7275622,7167154,6397429,0509236,4225696,0394258,7797141,0681708,0443148,7056425,1955950,4828096,9562207,9441239,7487793,5315539,9258104,5491383,9989575,6426835,4026653,3248459,1926963,9408119,9646198,6158051,3311649,3876922,5257858,1213095,4271443,0000022,0983138,0664574,9069658,2820056,5161565,3062105,5763948,6668023,0531706,3876431,6044465,9003765,7001039,7762776,7240987,6870545,2044457,8358402,0411712,1926064,3040016,9496637,3386059,1280853,0712079,4553855,3768786,4952139,9022494,7676475,6527814,7686108,2555700,1773617,8276263,0015613,8253022,0995208,8942719,4981963,2814934,8436300,8966811,4081334,2174103,9668822,9185424,5160755,3336896,3189298,6936389,8418913,9716565,7092518,4178371,', 28, 'Pagstar', '15', '00020126870014br.gov.bcb.pix2565pix.creditag.com.br/qr/v3/at/f4e43021-cb91-4db6-b684-af8db81a625e5204000053039865802BR5925PIXCRED SOCIEDADE DE CRED6009SAO PAULO62070503***6304A0B1', 'https://api.qrserver.com/v1/create-qr-code/?size=150x150&data=00020126870014br.gov.bcb.pix2565pix.creditag.com.br/qr/v3/at/f4e43021-cb91-4db6-b684-af8db81a625e5204000053039865802BR5925PIXCRED SOCIEDADE DE CRED6009SAO PAULO62070503***6304A0B1&choe=UTF', '33793af4-5dfd-473f-bdee-947a945c9069', NULL, '', NULL, NULL, NULL),
(349, '914fbe2320220', 42, '1', 0.01, 1, '2024-05-29 16:40:52', NULL, 'RIFA 10 MILHOES DE BILHETE', '4bca81f8806980ebbadeeec8f80f04b1', '5506471,', 28, 'Pagstar', '15', '', '', '', NULL, '', NULL, NULL, NULL),
(350, '86e4158d5deb9', 40, '1', 10.00, 1, '2024-05-29 18:14:35', NULL, 'MODELO RIFA NUMEROS', 'ea19ef0e6ff79d080bd70cba4d4fc09d', '004,', 32, 'Pagstar', '15', '00020126870014br.gov.bcb.pix2565pix.creditag.com.br/qr/v3/at/2e02ae65-e9ad-463e-87ab-882583c287b05204000053039865802BR5925PIXCRED SOCIEDADE DE CRED6009SAO PAULO62070503***6304347C', 'https://api.qrserver.com/v1/create-qr-code/?size=150x150&data=00020126870014br.gov.bcb.pix2565pix.creditag.com.br/qr/v3/at/2e02ae65-e9ad-463e-87ab-882583c287b05204000053039865802BR5925PIXCRED SOCIEDADE DE CRED6009SAO PAULO62070503***6304347C&choe=UTF', '462ea5c7-2c1a-4a7e-a4e0-e8b858cc5021', NULL, '', NULL, NULL, NULL),
(351, '8c003f09733c7', 40, '301', 3.01, 1, '2024-05-29 18:40:58', NULL, 'RIFA 10 MILHOES DE BILHETE', '5203d3ca263afccb64e96bc1f4d67b43', '1898575,4265520,3107240,9441928,3277269,3844413,8151461,0247553,5960836,4976679,0217143,1383843,7879865,5521793,1348991,3307540,7029553,9255256,2594961,9404453,2490483,7251833,0146722,0368955,9089541,1406332,3492126,4818319,2700261,8131539,1876733,6990774,3051467,8424073,6679555,3730228,9407297,3663033,4020210,4024921,6594921,0217504,9481184,5655235,6578521,9892948,1069833,8906757,7779526,5232624,3887135,5614112,5606485,0104735,8702106,1513050,8198077,5638359,0013539,7160615,1444539,9434504,3172649,7586575,0621264,6242937,1928827,2883069,5659180,5639983,5316707,4883706,6431284,8182536,3983879,7851657,5981327,2077729,5245853,7905309,4136873,3518603,2392161,2531871,0049085,4156346,2376960,2270557,3022828,3131972,3594173,5313367,5005779,6909283,2481178,6608797,4303499,7305200,2720806,5705112,9148041,8910239,6244605,6177346,6100312,2841141,3850774,7607607,9856493,5433987,8966519,6430418,2592131,8370350,6433182,4140557,4899696,8344089,8177058,1726219,8422026,6217718,3916864,9897227,0485748,2885182,9379852,8766507,7831996,1959392,0770780,9599643,9346749,1427451,3022188,2725775,0466248,6822542,7278298,6203801,8555731,2820295,8220138,3092880,6165481,7912838,5400293,5599962,9232611,1984135,7232331,9629916,4019614,8700434,2931238,5897184,1797859,1371360,7314053,2419355,0715058,6312841,8453855,1510611,1310634,8017871,1611577,1475832,3670696,7437144,2657417,3675913,5931558,2580101,5830153,7795472,9137422,1351865,4947373,2480613,9803539,5842054,3900553,7317685,5103910,7949958,5618861,6278102,1999083,3308724,3667391,3977300,0012788,2148706,5536843,4865405,4348383,8555618,8713618,8327044,4496749,7778957,4977030,7869622,5480758,0231967,0901265,0178037,1340694,3741940,4929732,7931665,4941019,7911707,3287874,6819643,7859794,3003802,2812954,8894219,0295031,5949517,4026590,7583013,7013467,3629216,3403383,3019784,3444179,4037207,4615811,6199336,8019704,3935699,1244730,6477892,9108201,8261163,3921435,8595010,2296900,3869612,2135630,2194544,5293662,3742153,1870461,2117604,3799572,4615579,3149104,0245533,3228992,1307170,4414970,8919735,2793673,3920637,9990373,8966062,4699335,9895115,3887247,8798512,2956720,7156004,9218865,7840334,9161427,0011854,2010667,0533565,3917318,2535000,8425093,5690540,2963869,8079176,9245867,3078095,8671881,0995306,3898679,8167959,5761737,4959145,0304939,5079592,0302201,6760634,0550782,2533920,2494296,7616336,8851561,5968030,6408708,0541029,5239430,2789232,8008077,', 28, 'MercadoPago', '15', '00020126580014br.gov.bcb.pix01363c615d77-4222-41e0-be1a-8f45807fdd5a52040000530398654043.015802BR5915THIAGO-DESIGNER6006Manaus62240520mpqrinter791233331236304B320', 'iVBORw0KGgoAAAANSUhEUgAABWQAAAVkAQAAAAB79iscAAAN9UlEQVR4Xu3XS7bctg5GYc3A859lZqB7jQcBAlCtNA6TkrP/RpkPgPh0er7uF+Wvq558c9CeC9pzQXsuaM8F7bmgPRe054L2XNCeC9pzQXsuaM8F7bmgPRe054L2XNCeC9pzQXsuaM8F7bmgPRe054L2XNCeC9pzQXsuaM8F7bmgPRe054L2XNCeC9pzQXsuaM8F7bmgPRe055K1V82v32e/tCyd2VZu/x/rlQuPXfy1/zzcTo/mxMtoZSsXaD21Cu10Oz2agxatBi1aDVq0GrRoNWj/eW2Z6NvynJ2V57bZcTF9sz0RrxTtAwMtWg9atBq0aDVo0WrQotWgRat5uTb6p0fkbjprns1t3yIzZFtWfW7ZWtCWEt/aDNmWVZ9btha0pcS3NkO2ZdXnlq0FbSnxrc2QbVn1uWVrQVtKfGszZFtWfW7ZWtCWEt/aDNmWVZ9btha0pcS3NkO2ZdXnlq0FbSnxrc2QbVn1uWVrQVtKfGszZFtWfW7ZWtCWEt/aDNmWVZ9btpY/UFt+9v5EKdrpq3LbPZDRokWL1lZo0eoKLVpdoUWrK7RodfWf05Y55cISqJJSvH2aFOQHfDsxVt1ajmVo0aJFm8vQokWLNpehRYsWbS77cm3Zxll53assZVg7ixTKZV+Q2zrDgrZ3yMqC1rfTbLS6LQ+0LdreISsLWt9Os9HqtjzQtmh7h6wsaH07zUar2/JA26LtHbKyoPXtNPtbtCWu/ad/OgPtT/10Btqf+ukMtD/10xlof+qnM9D+1E9noP2pn85A+1M/nYH2p346A+1P/XTG67Vz5H941/q/nvfbI9P/J/31x1W8Eg/YjM9B+2CMVbyC1l5Ci1ZfQotWX0KLVl9Ci1ZfQotWX/o2bXg8cmyrTRbkXF62PTbD8WUbX9DOJGg/BW1Ejm2FdpRNZxK0n4I2Ise2QjvKpjMJ2k9BG5FjW6EdZdOZBO2noI3Isa2+SxvDTDZ1+cVUki+2jlwiF9OM0ibZ/kBo21i0N1q0HrR6hhatnqFFq2do0eoZ2ndpS4O8mb9ALvwsvyQTpcRXtvXbCSXJ5f3WSjI+XaBFu3Zo0eoOLVrdoUWrO7RodYcWre7eozVZvtQ5ucQVuTi0cTGlXzRefK4z0LaLKf0CbS6REbJCi1ZXaNHqCi1aXaFFqyu0aHX1r2t7gpxlvrJGP7OegvKvks0alh74XIIWrZagRaslaNFqCVq0WoIWrZagRaslf4rWu9blBpUSTymxurjw4riI27bdRtpF/DEiaD22RXujlS3aG61s0d5oZYv2RitbtDda2aK9X6kNnv2UxAd1aCkpW8umKHVxlh/NvWuJNm8taNFq0KLVoEWrQYtWgxatBu33a9eRn4XH097cst5Pn9E+aKPkv43f2kpu5VG0chZz0KLVOWjR6hy0aHUOWrQ6By1anYP2xdr8knT1RwLvL67b6Uc6/OWyzV9Q6pxnV2inH+nwl8sWbTTYm2hrHdrIBO28skUbDfYm2lqHNjJBO69s0UaDvYm21qGNTNDOK1u00WBvfpc2NxT3RPY6e2L7lnjALgqvtG0l+SyCVi68Dq0ErT6AFq0+gBatPoAWrT6AFq0+gPZdWolVbzyb6LdtTrR5ypz8pd724e/Qb1fbWmpsHFq98Da0sY1btGjRos23aNGiRZtv0aL9Ju1w2VFlbJxJm8+xC0/DS7zDTj/NsKBFq0GLVoMWrQYtWg1atBq0aDWv1/pL5eeREomnrKQX5wt/L9f5Krb5DK1nKs4XaNGiRZsv0KJFizZfoEWL9ru10m+PyMO+ytsC2Lb5gQ3QFKXX8bG190rQotWgRatBi1aDFq0GLVoNWrSa92rj4dwQZH9zvpXE2E/fbPM2Xu7wW0t8KVq0fraWaFsJ2tmDds1Fixatd6FFizbmov0qrdeWsXYfUO/PdVESr2zD4iMjdiUJ/HQrQRuvSNDeaCVob7QStDdaCdobrQTtjVaC9n6bVmJlLouzPMwvyhcUT/s+//rYfij2uWuUdOTdjRatp7TGGdqUVuxz1yjpyLsbLVpPaY0ztCmt2OeuUdKRdzdatJ7SGmdoU1qxz12jpCPvbrRoPaU1zr5UWyiSGOYXeTUBtlfWevvc7SLy4RZtdJTiG+1aox3f2/LhFm10lOIb7VqjHd/b8uEWbXSU4hvtWqMd39vy4RZtdJTiG+1af7VW3oky6bIfTynOHf3TIrHNnxYzttjVVrfOYm21aNFqLVq0WosWrdaiRau1aNFqLVq0WvsS7TryLm+wg1A8rKK49LY/QZzFxVYXyWS0vRftOtKgrSVo7eDBiDYFLVoNWrQatGg1aP8NrUNLptvcducPykU+Z/qM3Bt1Jf4nsKCNoI2g1Vu0aPUWLVq9RYtWb9Gi1Vu0L9RuFWVOqbMz/2m90uavxFl+b3uq9cZICVq0GrRoNWjRatCi1aBFq0GLVvNybRmbf6T/3idumTpKGkDaJFPv9vVo28QtaFsr2tQmmXrReqaOErStFW1qk0y9aD1TRwna1oo2tUmmXrSeqaMEbWv9Sq0nKsojMSx/QXykj7CSbZt7t8Rt6bV1BC1aDVq0GrRoNWjRatCi1aBFq3mvNsu2lJesWC4kDo0Li39f3OZsH26rrTdWq2Mt0bbbHLQXWgnaC60E7YVWgvZCK0F7oZWgvb5UO/XbWfz0s/aR2+dOD+SLSPxFyqAIWrS+3Xdo2wP5IoK2n6FFi3Y972epAi3atd13aNsD+SKCtp+h/RvamGOtnlXr6d9idYEvcYVEOh+/r5D3aWuJdgUtWg1atBq0aDVo0WrQotWgfZfWUxRxVj4o3pzdURcz5AH/KV+QH4330KJF6y9VY66LGWjR6gy0aHUGWrQ6Ay1anYH2DdqgyFbiZ3GRH3FKlOSLuN0+Mq+62xJz0UbQatCi1aBFq0GLVoMWrQYtWs17tZLcL/Gx89n2cKnLiuiVCy8uH16esmK0PgKtBy1aDVq0GrRoNWjRatCi1bxc27ruvJqhpdi3kdwh2T6oXMi/MRdtLkarQYtWgxatBi1aDVq0GrRoNa/X3vZIdm8/VuJvli9oMjnzPF5YylN3HokWbdyuZQra1DZdWNBKSQxDu27RokWrdWjRah1atFr3z2tLRbyZtdtZ/qBrR/ltwedbiT+Qi+NlCdoLrQTthVaC9kIrQXuhlaC90ErQXmglf5DWy6w/LqwhdeTXPbHNCsmGt7Oo85I8vE2LdZTlhriwBrRrjTaCNg1v02IdZbkhLqwB7VqjjaBNw9u0WEdZbogLa0C71mgjaNPwNi3WUZYb4sIa0K412si/py0P5/wycmwleXXtIyZj+aqeuLCVzM3fspayQ4tWd2jR6g4tWt2hRas7tGh1hxat7t6jHS47YKNYcWxlTudFXfnw9p6cRce2QovWgxatBi1aDVq0GrRoNWjRat6rLYrycJHlVUQ8PlFi262tfWQMKt/it6t3LWWHFq3u0KLVHVq0ukOLVndo0eoOLVrdvUlrR9vr/Sz3b8kTvWQqNkp5z2e0P0sELVoNWrQatGg1aNFq0KLVoEWrebnWXpKVjN0etuckm2IaURR22j98vVjPMt5611Lz2GX3aFfKGdooRrsNQjudob3RovU8dtk92pVyhjaK0W6D0E5naOOlbaxk70oPxyp+8lf5WKuTRF058+Lyx7CgRatBi1aDFq0GLVoNWrQatGg179XGHNt6yjZ7fER7ffvcuUSyvTIN3/9Ka4nWMpdI0G5btGg9aH9nGo62UdCi1aBFq0GLVnNcu468oni8Vf6V0jjLc2LrP9bxIMvFZbt9M1q0HrRo/SLv7CgB0KJNKxsnQVtlaG+0ZYsWbT2zi7yzowRA+4Nae3rLPFYis/2nkePRybhdlMxPoZVX0KLVV9Ci1VfQotVX0KLVV9Ci1VfQvlhrhdvsaZVf8o68vfIc25a2+Ei/La+gjY68vdBK0F5oJWgvtBK0F1oJ2gutBO2FVvJ6rdTKNp7zbVttmc7ilYb35JLI1mZBW4JWujy2Rfs7aNGiRZtXaNGiRZtXaL9cO0XK59e3b5GSuLC6NsxLtgvb9jPvW0GLVoMWrQYtWg1atBq0aDVo0Wreq81dkkCFzN22lVUxbm3tzNvm7+t1cYsWrQctWu9YS63IQbva0LZ+tB/r0M4TpzNvQ9v60X6sQztPnM687b+mjXPfSpe1+uu22s7yRcyWEn8qzizbtMfeHLR9Ilq0aDVo0WrQotWgRatBi1bzQm28VLarYQPENtqmlOKCn9rm4WtZeU8NaIe2efhaVt5TA9qhbR6+lpX31IB2aJuHr2XlPTWgHdrm4WtZeU8NaIe2efhaVt5TA9qhbR6+lpX31IB2aJuHr2XlPTWgHdrm4WtZeU8NaIe2efhaVt5Tw/drr99zHmR2ET9eUs5Kb9xm/DY3zixovQTtWqJFa0GLVoMWrQYtWg1atJo/RPv4sJ35w43nt5HcKys5i1f6DLR2ihatBi1aDVq0GrRoNWjRatD+OdqyjRHxUoFG8ln/UnvUb2Nr6+22/VkkaCVo0WrQotWgRatBi1aDFq0G7au1JY4qP0GRRG9+avvSfFs+cvv6+Kry4etsLdEOt2ijDG0KWrQatGg1aNFq0KLVoP1C7fcH7bmgPRe054L2XNCeC9pzQXsuaM8F7bmgPRe054L2XNCeC9pzQXsuaM8F7bmgPRe054L2XNCeC9pzQXsuaM8F7bmgPRe054L2XNCeC9pzQXsuaM8F7bmgPRe054L2XNCeC9pzQXsuL9P+DyQ0IqNPkWETAAAAAElFTkSuQmCC', '79123333123', NULL, '', NULL, NULL, NULL),
(352, 'b88fdd4d7267a', 41, '1', 0.01, 1, '2024-05-29 18:41:46', NULL, 'RIFA 10 MILHOES DE BILHETE', 'f38480cef0b1ad11a528b712e490c6e3', '9190907,', 28, 'MercadoPago', '15', '00020126580014br.gov.bcb.pix01363c615d77-4222-41e0-be1a-8f45807fdd5a52040000530398654040.015802BR5915THIAGO-DESIGNER6006Manaus62240520mpqrinter793787411826304DA2F', 'iVBORw0KGgoAAAANSUhEUgAABWQAAAVkAQAAAAB79iscAAAN10lEQVR4Xu3XS4LdOA5EUe2g9r9L70DdCRAMEKCyJkn7yXVj8MwPAB7lzNf9ovy66sknB+25oD0XtOeC9lzQngvac0F7LmjPBe25oD0XtOeC9lzQngvac0F7LmjPBe25oD0XtOeC9lzQngvac0F7LmjPBe25oD0XtOeC9lzQngvac0F7LmjPBe25oD0XtOeC9lzQngvac0F7Lll71fzzdfaPl6WzsbXb/0cDlHHxa95qFbcq2Q3NsVsL2hutBe2N1oL2RmtBe6O1oL3RWtDeaC1v1up82Wpcuk5fEGkvxueWb9YM1eXeBwZatBG0aD1o0XrQovWgRetBi9bzcq3625BreHKxLizyPLZFcV71d8t2jp/Lh7LHZ9GiTcVoN9s5fi4fyh6fRYs2FaPdbOf4uXwoe3wWLdpUjHaznePn8qHs8Vm0aFPxB2rLj2X2J0rRZnL/KvtXZ7luxxhtc/lQhhYt2tx2o0WLFm1qu9GiRYs2td1oX6Rt76hOQ3RRskwpn2YFo3H5E+wYs24ut2Vo0aJFm8vQokWLNpehRYsWbS77cG3Z6ixPL9ui6B3jbUuhXKM3t3XGCNreYasRtLHdvd22aGfQou1btL3DViNoY7t7u23RzqBF27doe4etRv6r2pLQ/u6fzkD7Uz+dgfanfjoD7U/9dAban/rpDLQ/9dMZaH/qpzPQ/tRPZ6D9qZ/OQPtTP53xeu0+9j+8a/5fL2J3ulC9pueVOuSxW/3nM0q+CVq0HrRoPWjRetCi9aBF60GL1vNm7eJR/1gJZXX2rN62lK0iWfSWURbVtTML2l3QovWgRetBi9aDFq0HLVoP2jdp9dh+sCXIqitv5584K1P2b2hymaegRRtbrdH6GVq0foYWrZ+hRetnaNH6Gdp3aRW522DLMl0XpU63O5RlVFr67SjJ+HQxg7a33Wibog1Gm0rQ9jrdolXQ9rYbbVO0wWhTCdpep1u0Ctredv/XtOtlBVhUpyf0feN2l+VPYGm88hexUWjR+ii0aH0UWrQ+Ci1aH4UWrY9Ci9ZH/R3aaM3jlu1IGNVmGdvoyJ+xfMuIXvuuBK1lbKMDbbpD+z1lFH9XgtYyttGBNt2h/Z4yir8rQWsZ2+hAm+7Qfk8Zxd+VoLWMbXSgTXcv1ZatxjXZ0lEuxjZWum3b7ImLYhm36267Rbts0aL1LVq0vkWL1rdo0foWLVrfov007T0nBU/bMWlx60fJUyzqsJTvK2/EWR6ae+fSo4o2CW19I87QokXrW7RofYsWrW/RovUtWrS+/ZNau9K2eEZJmbmkfMaYVz5ooeQ/QdyOld1qqAUtWg9atB60aD1o0XrQovWgRet5s3aZtB9iq2VmPlu+xe4et/mhUqcpFrRoPWjRetCi9aBF60GL1oMWredv0I7+mKRt0Y7bOz87RwSqDIgzJbdFsUrymYJ2eQzt3F1o0druQovWdhdatLa70KK13YUWre2uF2nvdbDe6bfjYKkb6V9gGb2W8ndYPmh3O9vm0qMutL0Nbb8dB2g3t7NtLj3qQtvb0PbbcYB2czvb5tKjLrS9DW2/HQdoN7ezbS496kLb29D223Hw57Tt0s40RCV6dqnLWb6g4FUiXoNaWwlaC1q0HrRoPWjRetCi9aBF60H7fm1MGg3RnyctdeUij9I2otvdvHwbK23R5lFoI2hjG9Htbl6+jRXaxkOLNo1CG0Eb24hud/PybazQNh5atGkUWuXX5EVruyhaPaFtDMjFelHFC2pEb1yrYNyuO7RofYcWre/QovUdWrS+Q4vWd2jR+u492jI9j1um66zI8pfG9+USXVhilXv1bpk8OuayQtGiRbteWNDaRemKszYTLVq0I2jRetCi9aD9/VobN87rSq35M2JwLtZWJbGaBI/q2kPl1oIWrQctWg9atB60aD1o0XrQovW8V2tRrabbpPxYGLVtF8tn5O1yq+Q39H12oaBF60GL1oMWrQctWg9atB60aD2v10bt2Koh3m4rAe4x4PFF25ZvKfnmFi1aD1q0HrRoPWjRetCi9aBF63mvdgy2t2Pm+InMrn9ti7QP2n3aknG11M0zrUctWrReixat16JF67Vo0XotWrReixat175EO4+iLFZjjM7KzLht3xcrfV8708VSp2QyWrQetGg9aNF60KL1oEXrQYvW82at3l5Sbm2zQ+VVbEtx/mNEcl1JfP0IWgWtgnYtRltSbm2zN6JFW1exLcVoS8qtbfZGtGjrKralGG1JubXN3oj2b9IuFeUdneVt3LZeu1BHnOV5wi+fkUsUtGg9aNF60KL1oEXrQYvWgxat5+Xa8mz+sf6oK2TLrqOkAazNsutdvh5te3EJ2taKNrVZdr1oI7uOErStFW1qs+x60UZ2HSVoWyva1GbZ9aKN7DpK0LbWj9RGVFGGlLOxDYWe2NXlP8YS3bahJWgf6tBadi/uzsbWBqOtQftQh9aye3F3NrY2GG0N2oc6tJbdi7uzsbXBaGvQPtShtexe3J2NrQ3+3dosW1ImjeK4GAexyo3LqFKXOxbjiHrz584lWrSzFu1MqUNrQbt0oEXrHWjRegdatN6B9rO0o99k1zpTP+UsUqaPlU3pA/KFor9I/6C5XXdo24B8oaAtZxG0y2ps1x3aNiBfKGjLWQTtshrbdYe2DcgXCtpyFkG7rMZ23aFtA/KFgracRf6QVpOUVmIzY7trK2/nld3e33xfIa+vzaXtPGhjZbc32rktJWhT0MZ219aMaPuzY1tK0Kagje2urRnR9mfHtpSgTUEb211bM6Ltz45tKfkMbcR6Hsn5LLSP7rFVr8nip3zBfh5atGjr9LjIdepFa/2PL+psNz0ucp160Vr/44s6202Pi1ynXrTW//iiznbT4yLXqRet9T++qLPd9LjIdepFa/2PL+psNz0ucp160Vr/44s6202Pi1ynXrTW//iiznbT4yLXqffntFYR0ZAxUE/YmW2Xd1TXRqm4fFB3j0QHWrRo0c6LWI2gRetBi9aDFq0HLVrPe7W5TC/Gz25weaKQ85lejIfK5PyGbq0YbdmiRetBi9aDFq0HLVoPWrQetC/WKurK/RZ9wVK3O8sXy1cJUIrbvPKlaNF60KL1oEXrQYvWgxatBy1az8u16lJt+Xma5GkyO4s8Xowsn2YnaNGijaD9Clq0aCNov4IWLdoI2q/8HdpSoZlqaGf6oGtFla+yW9vq1qJvLn8CfTPaC60F7YXWgvZCa0F7obWgvdBa0F5oLX+R9l+n6yJPj+RPk8JS8JGG1+PqHbdaqyw32AXaGbQjaNF60KL1oEXrQYvWgxat59O04zwluy3FE6tcvDOWr+rRxVjZ0Pwtc4n2K2jtMsrQprbR0aOLsUIbq1yMFi3aEbRoPWjRetD+Ru16Ge9ECmUUd1nhqU5ftZ9nZ+pYVmjRRtCi9aBF60GL1oMWrQctWs+btTap/CwzNW5nVGLkOiCKy0fmLyjfErezdy47FC1atCpGi9aL0aL1YrRovRgtWi9G++HaHE3vZ7n/ISrZFQ9KmadvXr4lB+2N1oL2RmtBe6O1oL3RWtDeaC1ob7SW92p3Q8bZqF0ihZ5Q9Fgodlu9YSlnbTLaOMurhy3aWbsE7XrWJqONs7x62KKdtUvQrmdtMto4y6uHLdpZuwTtetYmo42zvHrYop21Sz5BqzJd5FtrXR7LW+u1LJ9WSoYnFPksitvXW9Ba0KL1oEXrQYvWgxatBy1aD9oXa8fMMtj6YztWYdQT+e3+TinJWabsHs9taDuqlOSgje1Yof3K7nG0aCNo0dY2tB1VSnLQxnas0H5l9zhatJG9Vg2PHl2oI5+V3mueadVl5a+UtzobF1qXmWj9VtvxMlq0HrRoPWjRetCi9aBF60H7WVrLGN2zo4wLa9O3xFbZG5eLkvwX0Si0sVXQWmrbDFq0HrRoPWjRetCi9aBF6/k07SjUs8HTherGajGW27y1txdA+YI2Hi3a1BHFI2jjNm/RWtCi9aBF60GL1oMWreddWqu17TKzoEZJDM51JcsA+1eUMWXXu3sXbQla64qMLdqvoEWLFm1eoUWLFm1eof1w7S47o0Xf8ni2eWyrGNt+Fn0zaNF60KL1oEXrQYvWgxatBy1az3u1ucuit+2da/TrxbJVR3PrLNoy/rs63aJFG0GLNjrmMl5U0M42tGjRXmhTG1q0aK+P1+o8tnmSPJH84rLVgLZSltda7zW/SkG7M6JFW1cKWrQetGg9aNF60KL1oP1orSYV7civMSSenNsHj1a597s/QTuTAK2CNoIWbbSinSu0uRbtthitBS1aD1q0njdo7Z0dVBelJD8Rb0RJGZrxetfGx9kI2hg1gjbOhwNt5aFFixYtWrSxQou28tC+S7ug8jtK99gmz1P0J7CSa07WquNH0KL1oEXrQYvWgxatBy1aD1q0npdry3YMscSkMbpnV9e+wFK0inoX8rydS7RoN+exzePQpjYL2ofs6tC289jmcWhTmwXtQ3Z1aNt5bPM4tKnNgvYhuzq07Ty2edynaUusTI/Fi6N4+Za86hSthkeRrLyhOrRaoY2zuUTbbtHmMrQpaNF60KL1oEXrQfuB2s8P2nNBey5ozwXtuaA9F7TngvZc0J4L2nNBey5ozwXtuaA9F7TngvZc0J4L2nNBey5ozwXtuaA9F7TngvZc0J4L2nNBey5ozwXtuaA9F7TngvZc0J4L2nNBey5ozwXtuaA9F7TngvZcXqb9H6GHEJEvimeWAAAAAElFTkSuQmCC', '79378741182', NULL, '', NULL, NULL, NULL),
(353, '166a572a65836', 40, '601', 6.01, 1, '2024-05-29 18:46:22', NULL, 'RIFA 10 MILHOES DE BILHETE', 'e619c5aa25a6fde4fb52f2b37f6080ed', '3136535,7033591,8984932,9333183,8859594,4968433,3351177,9305428,7992839,6241522,3589823,3003190,8722861,5593967,6972051,7130468,8692417,5867597,3742841,0162455,9630707,7332586,7949019,3628297,1267088,2357348,7674422,0049066,7866622,5661453,9263982,1613172,9319628,7644399,7440940,6369893,3278852,5340434,6136423,4774980,6059014,7100821,9051126,5146759,7685324,5327225,9144865,2526286,4561316,1651705,6243253,4243955,6199121,5422596,0551274,2323878,2083031,5736981,6495807,3300402,5145256,5958385,3228768,5562158,8702925,9122842,5536293,1610302,2381648,2939767,5211814,5032128,3565877,6580303,0185772,2369465,6408303,3478110,8006069,6869812,8452152,0765491,9875654,9802544,7610819,1566223,7574199,7683482,2022277,3268227,3031309,8863324,7255801,1592012,6624055,7975760,1414958,1090332,4563420,2980940,0869447,6760839,9512488,5131108,3403381,0997762,9307041,7046201,4515688,3862343,4307568,5642106,7859055,9445787,2108392,8100994,5011186,5465599,5950494,1688840,4777137,6813859,1699897,8151573,6014869,7489298,6953647,8909236,4362433,3112584,9086086,2423568,8687737,0052647,6987406,9987239,1897790,6301208,4834072,8734108,5599345,3789317,0939888,2975893,5784614,3058173,3450820,0798354,5140990,7504272,6387541,0557152,6800744,1171631,9605231,1933057,8855154,6205763,8178342,6960722,7894749,8683282,0919993,8138408,4299747,4924449,4019065,5530238,5845549,3563950,9045588,7114751,8671471,2783433,0321775,6745426,0108960,1532319,1589783,8349513,2396299,3635071,4494006,5537333,6632836,5297538,0970995,9491161,0700728,0569321,8188403,8161896,6553780,8346611,0444598,6955483,3083259,3883217,0364960,1175592,1200767,2684131,4435522,2750697,2932329,9593122,9776916,1750092,2164788,8276749,7541929,4160260,3749099,7835852,1578598,5972801,9804175,6560966,0748595,0776194,6011138,1740404,3078443,9129872,3363150,3099871,3597412,1459480,0629285,2501523,8704022,1511326,7197322,0607705,1775176,9722904,7061216,9121139,8907468,1554796,0294696,8111240,2774958,9842744,4811576,8120122,4251549,8229941,3684072,4581654,0015878,5825432,3868970,6961915,8381532,0738580,0905984,2052412,6297528,2180083,4210494,9958511,8226435,9698517,5843801,4910247,2433392,7791444,0848638,2820187,4334789,4312165,6109500,1104240,1337018,0575208,7755843,3212585,5318247,9946004,4430709,2921010,2729859,0975290,7503358,1198145,8810720,7394486,0808644,0677448,6742314,0424358,3585195,0210888,4838227,4461633,1536809,6353696,0739589,8213598,4766355,0639510,1974424,8219306,8942355,7647929,9513045,4774227,4820895,7014307,3629331,0666826,1276321,5743221,9424004,0340069,1741184,9912379,2948672,7473927,3617584,2165053,1407285,2960412,1520790,6867244,1659648,8164964,2886298,4600946,8224874,7145184,2873386,9876021,5091391,4398250,1432569,4841465,6736190,9417604,5109454,2232934,1545885,4068808,6014012,4996433,5530428,6759861,8866185,3184229,6880573,9183092,2403043,4277768,4857819,8447762,2398546,6369627,4940417,2310309,3818221,2549816,5254416,2938759,2253113,7557534,4842170,5653945,3427187,2422078,8532954,4477982,1249563,3545101,5279608,2345847,4618071,5235728,2113187,8252417,7426075,7401418,9272948,5962596,6409129,1493359,6277667,3702550,8834719,1334952,4993420,6830895,0096648,2892453,0201096,0900398,3370826,2042688,7792412,1542311,1818551,0154110,5539954,9999404,3867719,7295493,9392223,1320134,7609357,9742352,5749761,7861764,4273574,6944584,3941441,9561486,2379354,3859983,4404972,9754365,3790818,5541693,3158685,3762097,2533150,0624290,2158027,7571283,9451878,2966868,7296447,4086536,2941449,9635961,0709832,4710442,5591851,9587269,9530719,3681100,6433176,0670553,0520355,9496679,2445280,4256407,8106575,1452185,4045043,0790116,3722259,4972623,1387000,1583856,2502180,2303858,3701385,7452856,0060219,5660477,1267203,4550339,7536467,1558970,2924062,9745635,7708087,3454800,6338543,2065502,5402444,7103388,3443552,9376361,4324219,4756333,0805492,6595135,8694990,3999695,4689242,3199919,5155705,7547864,9785648,6468185,4140705,6811732,0698162,9586414,1283207,2787999,0011439,0413100,2679961,4496940,0112134,7532842,9754782,9093470,6059628,6088937,6383645,5258315,9796984,2441801,3450144,0254423,0226023,0701103,9962511,9369376,0469723,9591167,0703847,9630071,8176682,9461232,1323275,6920087,9007437,1050318,5935642,9357208,4744391,9752069,5165360,8105932,3878942,4983606,6598864,8304912,8201978,7910261,1532578,5239814,5469914,4124502,3579481,0714018,3710981,0102638,1840306,7331804,3094705,8815848,6772757,6949155,7689230,1495364,5293649,7448388,9967218,8894601,8560757,5048909,4236132,8555751,6554048,7248484,5323465,1672398,7133817,0967120,8212146,2693196,7463546,0714295,6400477,1465295,2451481,3855213,3052451,8839526,2394298,5736307,6240219,9966650,2229622,5736944,4808255,0588884,7870305,7854550,4588226,9464528,3299323,7826805,9612840,9578763,2259620,2603941,0327487,5046779,7885171,2318620,8313002,5200756,2142591,4960231,8092068,', 28, 'MercadoPago', '15', '00020126580014br.gov.bcb.pix01363c615d77-4222-41e0-be1a-8f45807fdd5a52040000530398654046.015802BR5915THIAGO-DESIGNER6006Manaus62240520mpqrinter791238950096304DAC0', 'iVBORw0KGgoAAAANSUhEUgAABWQAAAVkAQAAAAB79iscAAANrElEQVR4Xu3XQXokqQ6F0dhB7X+XvYN8X+lKISGRWW9g2o7q/w7CgAQccubr9aD8c/WVnxy054L2XNCeC9pzQXsuaM8F7bmgPRe054L2XNCeC9pzQXsuaM8F7bmgPRe054L2XNCeC9pzQXsuaM8F7bmgPRe054L2XNCeC9pzQXsuaM8F7bmgPRe054L2XNCeC9pzQXsuaM8F7blU7dXz6/faL7WVNZ9G1ZbzFIuv/eOf1jKq7dAWq1rQvjaepWVU0cYa2hfacTDaHrRLfA1tpHeh3VfRxhraF9pxMNqed9pcX6at4GvtuOXuLKyXKfdC6Ws/QW1Bi1YtaNGqBS1ataBFqxa0aNWCFq1a/hpt7t8dYjWX5Y7WHC37HTZto3lvm3rQRst+h03baN7bph600bLfYdM2mve2qQdttOx32LSN5r1t6kEbLfsdNm2jeW+betBGy36HTdto3tumHrTRst9h0zaa97apB2207HfYtI3mvW3qQRst+x02baN5b5t60EbLfodN22je26aev1Cbn8woTO3+pZYdfnm4n4MWrYIWrYIWrYIWrYIWrYIWrfJXa+s9ecXS1+6uWU6p74tmG9VHWmEy7r57uG1DixYt2tqGFi1atLUNLVq0aGvbD9e2aa7V0yO76n4t0yiXv6BumwwP2t1aBm1Md3dndtX9WgZtTHd3Z3bV/VoGbUx3d2d21f1aBm1Md3dndtX9WgZtTHd3Z3bV/VoGbUx3d2d21f1aBm1Md3dndtX9WgZtTHd3Z3bV/Vrmv6ptCe2//ZkMtF/1mQy0X/WZDLRf9ZkMtF/1mQy0X/WZDLRf9ZkMtF/1mQy0X/WZDLRf9ZmMx2v3sf/wrvt/vYjVspD9eXobDY9VY28e+iFo0Spo0Spo0Spo0Spo0Spo0SpP1i6e3O+jiap3W9p0iR9gd8Qz2jRfMNYsaN8EbYst+wjtVrZbs6B9E7QttuwjtFvZbs2C9k3Qttiyj9BuZbs1C9o3Qdtiyz76Wdq8bBy8jPJVu7vzVWNv5O0dXm3nZdCijWmO0S57I2/v8Cra6Buno41pjtEueyNv7/Aq2ugbp6ONaY7RLnsjb+/wKtroG6ejjWmOn6XNpNuzPKOdPl4VO7K63/YadwyetdSjSuEO2rntNe5AOw5GW1rQolULWrRqQYtWLWjRqgXtv62tu7yoe2r1uqf2gsV4b5zPtcy1wZvPRZuFWm2Za2hr9UKbQWtTtGg1RYtWU7RoNUWLVtNv1tbeyNhv0xiNbfGC1pxQ3xHb7O/nFrTZgjanpYb2M8X+fm5Bmy1oc1pqaD9T7O/nFrTZgjanpYb2M8X+fm5Bmy1oc1pqj9Lueusn1mrfcmPtszXrW36CLNRp9URhOequ5jj3e9DehTpFG2u1D60KaNGqgBatCmjRqoAWrQpov0+bsf3+sSyUOo1P7bOWuDGP8rQHtTtibXcoWm+50KK1lgstWmu50KK1lgstWmu50KK1lgvtk7VvPba2O3OJNbRn7B8U0/qgqPrIqnYoWluzKyYULVq0OUOLVjO0aDVDi1YztGg1e5LWl94csvDyzKzupt48p/UFrS9/EQva2WwTb55TtLkBbUntQ5tBW+5AO5tt4s1zijY3oC2pfWgzaMsdaGezTbx5Tv9r2jTmcY1y+VusP/vKIbeivXnwclv8QG3v5uR1dqFFa7MLLVqbXWjR2uxCi9ZmF1q0NrvQorXZ9SDt6z7YRmk0VFSzpfa19+1acq39DsuDdtV72z1U8ky0aNGiRZstuTY9XkUbLbUPLVq0aGsfWrTfox1FW8tDsmWhZMHvseRLrTkO8OZoqYUGtW0taC1o0Spo0Spo0Spo0Spo0Spon6+Nk9ooT/LmSBq9lDfumm2aT2t9n6Zo94pstinaZYR29n2aot0rstmmaJcR2tn3aYp2r8hmm6JdRmhn36cp2r0im22Kdhn9NK3tr3fHqOKt8Frf0qoLfty47M2WenmcV7YoaNEqaNEqaNEqaNEqaNEqaNEqz9XWu3e85XQvLA/KG71zeb1lVOO8HOVRnnwpWrQKWrQKWrQKWrQKWrQKWrTKk7V23JJcuzeX/dXYps0d1XrKtd6Wp+yqFrRoFbRoFbRoFbRoFbRoFbRoledqLdnmW/KKZbRrSePoW56R00wW2vE+tqBFq6BFq6BFq6BFq6BFq6BFqzxem3fnNC+ztFHeE9dmtd44tV5Y8qGKFq2CFq2CFq2CFq2CFq2CFq3yXG1eVo1RaNcOXsjysn3VkifHKZl2Rw1atLGWY+9Fi1a9aNGqFy1a9aJFq160aNX7EO291Df4MYsiH7Sf5tp1k1+1JZ/hhaUvU8loM2hb0KKNJbRotYQWrZbQotUSWrRaeog2KUtqNba2qo+n1quLsQKi6qOW+Ak8aDNoM2hVRYtWVbRoVUWLVlW0aFVF+0Dt0tHuaX3eEtWx1wo2mh4/L496c6gvWNCiVdCiVdCiVdCiVdCiVdCiVR6ubdfWj+2Pvv0Vc0fLANg2y25vTD1o0Spo0Spo0Spo0Spo0Spo0SpP1kbeAvKy+oJ8ZFzRTvHk3iVZrXuzkEGLVkGLVkGLVkGLVkGLVkGLVnmuNgEt7SRvjkKdxsgT78tqzfJwHy17c3TvuIdofy+gtV60aNWLFq160aJVL1q06kWLVr1P0u4PtjPzs1tbyC1v++p5cWi+L9dKB9o1b/s2lAvtWEN7r5UOtGve9m0oF9qxhvZeKx1o17zt21AutGMN7b1WOtCuedu3oVxox9q3aK3XL8mRHey9JbmWhdZS10Lha59ua2SfWtAuQZvru/13b0muoY2To8+DdgnaXN/tv3tLcg1tnBx9HrRL0Ob6bv/dW5JraOPk6POgXYI213f7796SXPsmbT04pxFbyYMT6oVYG3dbIeLV+LQX1EPzd0Aba2gjaNFG9R7arBVLbAXt0oLWpmjRaooWraZo0Wr6E7Q5yUP8wOWKdo+Po28ctTyyjqbbk29Gm0GroEWroEWroEWroEWroEWrPFn7Gh02qSfVrSVvX5CozNiR2nxVNqNFq2a0aNWMFq2a0aJVM1q0akaLVs1/obaNvG5XLPG+aGl72zNqoTVHwf6++4HuodJ2oY1Ca46C/UVr8b5oQRtBi1ZBi1ZBi1ZBi1ZB+y1an9r+5eOx47IvMmSx1vq80LI8zVbQ+ja7Am1U76HijWjXPi+0oLWgRaugRaugRaugRat8s7Z15JlVu6wl2VbqUVGtdyd59+ZszpMtaC+0FrQXWgvaC60F7YXWgvZCa0F7obX8Rdo/nj7OzOqrNleFpeEjA5+X516v5jjb6gYroL2D1oMWrYIWrYIWrYIWrYIWrfJjtDWxa6AWXh21K3bG9qqZLPjoV3/LPVyCFq2CFq2CFq2CFq2CFq2CFq3y87W+pRbjHtu/jHxHvKDt2L8q1vycPCrPs7XcsYzQoo2gRaugRaugRaugRaugRas8V5seP3P5WPK4aoyCV2ehPag9sr6gvSWq9957aLMIWgUtWgUtWgUtWgUtWgUtWgXtz9dmRzt9HJz7o8X3BqW+rzXbWjT7NPHzLTVo0Spo0Spo0Spo0Spo0Spo0SrP1dbe1y2zg1uLZSpq2rWfXx9paw2E1oMWrYIWrYIWrYIWrYIWrYL20dqX99bTLcvpu2m9NtcidUe01J8l16J5/2OgRaugRaugRaugRaugRaugRas8V5u9OfW1Wd0bM8uN+xbLcsru8roN7VK17FssaGcV7fZytIOCFu1atexbLGhnFe32crSDghbtWrXsWyz/Ga2t5z3Nk1vbmcuax6ZL31tZa67TcWiO0aJV0KJV0KJV0KJV0KJV0KJVnqW1OCCTFLtsFwO8+fihO+NSaKkvjVPQoo2gRaugRaugRaugRaugRas8V+uNeU/j1V3zpEzzXPfdy7b2gvq03BHNHrRoFbRoFbRoFbRoFbRoFbRolcdrrdemeeYO9ao37t9nWVrs73hQtmTayRa0LWhtV8SnaH8HLVq0aOsILVq0aOsI7Q/X7lKvaGsTmlUfjcs0bQWfzrXYdwctWgUtWgUtWgUtWgUtWgUtWuW52rrL0qDmWW70bQugfWrLPO//6MsqWrQRtGhjxz1Ee588FWjt792L9k99aOsOtLHjHqK9T54KtPb37kX7p7732lyPaT3OTrdD2ihPj+n+AFvLLLeNvdf9qgxatApatApatApatApatApatMrDtXlSVWT+8Wm+wKfR5wfEKVXR9mZz3ptZLB60GbQRtGoZzWjRlr3ZjNaCFq2CFq2CFq3yw7V5zyLLZNWnedR8rjcth+7e0o7yoM2j0EbQolXQolXQolXQolXQolX+Bq3tagdbcxR8ZGmvCkWmFmxkawu5VvP3sqBFq6BFq6BFq6BFq6BFq6BFqzxc26Z5RZ6UB9dC9L19qVctTZtpd1gL2uhDm9V7iBbtZj2m9Ti09zYPWrQKWrQKWrQK2p+hbUnU8mmFJvNRnNdG2eJpr58/AVrrR6uWe+0eoh0jtLUNbQlatApatApatAraH6j9+UF7LmjPBe25oD0XtOeC9lzQngvac0F7LmjPBe25oD0XtOeC9lzQngvac0F7LmjPBe25oD0XtOeC9lzQngvac0F7LmjPBe25oD0XtOeC9lzQngvac0F7LmjPBe25oD0XtOeC9lzQnsvDtP8DCikUzRGxljcAAAAASUVORK5CYII=', '79123895009', NULL, '', NULL, NULL, NULL);
INSERT INTO `order_list` (`id`, `code`, `customer_id`, `quantity`, `total_amount`, `status`, `date_created`, `date_updated`, `product_name`, `order_token`, `order_numbers`, `product_id`, `payment_method`, `order_expiration`, `pix_code`, `pix_qrcode`, `id_mp`, `txid`, `discount_amount`, `whatsapp_status`, `dwapi_status`, `referral_id`) VALUES
(354, '36c043d11b724', 40, '5000', 50.00, 1, '2024-05-29 18:46:46', NULL, 'RIFA 10 MILHOES DE BILHETE', 'f4bd4395f970e3974ad2ac7b7bcaf12b', '6887463,2624289,5355366,3614141,3061062,0682199,6180082,6100974,1633449,5224421,9676629,9612451,4794229,2308802,2576174,8616530,8782102,0199416,7408253,2083484,0706976,1516524,1126694,6409699,7502463,9456431,8481214,8614963,8544818,9728157,5717316,9033081,1438970,1505373,7401930,2197196,5658600,6761692,8809231,7781630,5276807,0621300,8598813,2792225,5908358,5381351,4767946,1874325,0004099,8989012,8632753,4043359,4874814,1363369,5767400,3316479,2472994,5392011,4004918,8502916,0699681,4259752,4613151,6244867,7523821,1101652,0271323,2082264,1591875,6428421,9952996,9271908,0393435,7468598,5971152,6994430,3412235,6450030,9030256,7075123,7769983,1485052,2372469,2742068,1286497,4990510,1454070,4464485,6450865,7068214,9004888,2564835,9198140,0731133,5131986,7819174,0723450,3869960,4452507,9185131,1353962,5412273,5386490,5794090,0563402,1030094,8847595,6036884,8280247,2499895,3751446,0231774,0910545,2325940,0347340,5573885,2663709,5497402,8307618,5718212,4504946,1412180,6368189,5933067,0704985,9951101,5867015,4270944,6070601,8943318,9861412,2930045,3503146,4223829,9754085,0962399,5487600,1162104,5857970,7536641,0632427,6303940,7469877,5174607,0220904,4435728,1818284,5890105,9964550,0459254,1485929,4986496,9676737,1106870,1766764,4737851,7804476,4820572,0997338,2897793,9343888,2515645,4183436,5849818,8251602,9903227,7540133,5541005,4034193,1659695,1256876,1049764,9783176,2408442,1524365,3290680,3037042,1121625,1297786,1591615,3145497,8767349,2107699,4236545,6273910,3828792,4241796,3102663,9581482,8544699,2304009,5065958,1830562,6071429,4719308,7774469,4280168,7046604,3445177,6062178,2751678,7047422,1001536,2250442,1032699,7969541,1567314,7003629,1873802,7783485,8315663,5706007,2545625,6730339,9732468,9045911,0895445,6773911,3565340,6345762,6310059,5052746,5903906,2805349,1365341,9908754,3478855,6781734,4689914,7652921,6680730,4196156,1821018,5636803,8021232,2536232,7268352,7334552,6798496,4883242,9141511,7309310,9280465,6384155,8983927,5899581,2890941,1797940,4317326,2492492,6482179,7983430,0597680,2623636,5184261,4090711,6349051,9642745,4759596,7049020,1162665,9320831,5040007,0004328,9249119,1573019,2696559,7201671,0556383,2467523,7475677,6957911,1383686,2122341,5022781,6547144,3425123,4251530,9735978,1702302,3182990,8871821,2716430,9286976,6650488,1376881,8126885,3426958,4723073,4843819,6601020,6587126,6669840,5162448,4266794,3091430,9126952,4833089,0098862,6365359,0212808,3904085,3840847,8808456,2287568,5497411,4493345,5390895,4564236,6702326,2146193,2686872,5654559,4022484,2999161,9239057,3616787,8693569,8531353,2223956,6385754,3503677,3317861,9462210,2121143,6118107,5431342,7238204,4206151,5418126,1750311,1265483,3356478,5373636,2378462,9780449,7376717,0565290,2476724,4957270,8771988,8710655,9370259,8463543,9471500,2209533,8306724,1510778,2269652,9947865,9312563,3846177,7060565,6703120,1432211,6043442,5168156,6536745,6126008,7452039,5014821,2113831,7435044,9536593,7590889,3695977,7220204,9298724,4171401,7508098,5774799,6643339,8319988,2412965,6651111,6137649,9989996,7826170,9928578,3471021,8270051,7350793,2395980,6868031,7704459,4130680,0903426,6826654,7872950,5171689,4250729,3129918,5655482,8232942,1683947,4096584,4688448,3345900,4251628,9786770,0639547,3575621,2845469,8869345,2095679,2635806,3880268,2871657,7469243,0746952,0264647,0176779,6527124,7478130,2603702,8643192,8177087,3952487,4716485,7087016,8875284,5557819,7711853,3700660,2073022,5371203,1386930,2618043,0400577,1998195,4360929,4932553,0831719,0872398,4434664,9299724,3033981,1952982,0334135,5636090,3514982,3806234,4367930,2780352,9168259,6522734,0380275,6615880,1644450,8095827,1164601,0383623,3952930,9005404,2023412,8416886,7699551,7519914,5981577,4921929,2159512,6742705,7524732,1695972,3679688,2050641,3391663,7658811,3910343,1850883,6653435,2462434,9184644,5519537,1132950,3555646,5124521,9670539,7240071,8016012,2519469,1340089,1826121,8897501,1896049,2865385,4036913,4455020,1108923,5716727,3731078,9192785,2899272,2016332,1488237,3346391,7193997,3469788,0357511,2904593,5076957,3544289,1299152,5422247,0275127,5121511,3403098,7864003,5996766,9681630,0886030,0636064,9187771,0295274,5396624,2754712,6229931,5213199,3612901,1455135,2673461,3908530,8803969,4618926,7036627,9224418,5223547,3419860,3583131,4674560,5082180,9828693,0090820,5311288,1192644,7192577,2892748,1960781,7687605,2969945,9754830,7656631,2824601,5873177,8840155,8847390,1356292,8279086,9877543,4915291,9247600,2012989,4283512,2396933,9427622,3737154,9477846,2033682,8724072,0145824,8442157,7223708,0657857,3106873,9241223,8131716,4330949,1495327,8289468,3539599,3357320,5337006,3547510,9341664,1387407,9208213,4657513,4600393,8858342,3504573,1818530,2076308,8035246,5400627,2771565,1611212,6297981,9764843,5382145,4899981,6337538,6587130,1426846,8075201,9922738,8946881,7052454,3883687,6245723,6815944,7248135,4677322,8687589,6830963,6286437,0990430,4717865,7782567,3287542,1273755,5698383,0003655,1274390,0840487,2705470,1898182,5412163,5287016,7130770,2523777,2635759,1409753,4496007,6337761,2199999,4575612,7220180,5721311,5961353,7169826,4738260,4825096,3917453,1908363,9145464,6322991,4819706,9874336,8784067,1887078,1262276,3527753,6986390,2925880,2843703,2870263,3550477,5669687,0126532,4095820,1317717,1724696,4400175,2110438,0664965,8488829,2131113,9519982,8264860,4285436,3559372,9486545,6566669,7721409,7528422,6122186,7084010,2863327,7002502,8061865,5778316,9802922,2347573,6706327,8994705,3761534,0583971,7654130,7721969,6985442,7064040,7206618,3978103,8075802,5002383,6067073,3211038,9171523,0134257,9245779,9024381,8496637,4453797,1810455,1273589,6636247,3681247,5982279,1358875,1754663,0227823,3616941,8392987,8606991,0841133,7858338,9926751,7906237,8435235,1479922,3002600,7265348,5809092,0948101,7984331,0391035,3461715,6494785,2145665,0226331,3655972,9033040,8964570,9102050,7916074,3299137,1275943,2816736,3139134,6656244,2893838,0616596,4558964,6646572,4118736,2913172,7755275,4699380,0850479,1698608,5368307,9966919,9106968,9684465,1248254,3934385,7226482,7374895,7078607,8377061,2979722,5205339,8457869,2588301,7011919,9875828,6339297,0578829,2198452,7532182,2629423,1980582,7685866,8879518,4896531,2296726,2778440,6683915,7878727,3087394,7592621,2184288,8103880,5138882,3453193,5978163,5338882,9991002,0492163,0565840,5611271,7143003,7575579,0935950,6128067,1553307,1005789,8123617,0973286,3321514,5456394,2743560,0764577,1998956,8949721,9064314,1294031,1569585,7873311,2319340,7127183,4004735,4096259,8885217,4398680,2524147,5932254,2070699,0505455,5110014,6678443,0488249,4421540,0813053,9866914,1636123,8139778,8638670,5060298,9567098,2381193,5861967,1160317,0378520,6394236,4000507,5090312,3812665,8350238,4558995,4415358,6813764,4801197,4720657,9927589,1803819,7236163,8017623,5115377,4615183,5842834,7114758,3313761,4933639,7306933,9441900,2814380,6930214,1310153,8629675,6232428,3468110,6321321,6542754,1339707,8712294,3576862,4533918,5522934,8115348,4846215,4718595,0313692,9410178,0488006,9579194,4993810,9070509,2822979,7195830,8658121,5023764,3957830,7089837,7366438,9523473,9240105,6988151,4831669,3077499,4726863,8014476,8644520,9543305,7607087,5075932,4924611,9084078,3759721,1681630,8803765,3825228,1727467,2772891,4474143,9894210,1188805,4716587,2342173,9443777,2930986,6353912,3367581,4979665,7432155,7619552,4574910,5182061,0315375,9387794,2552928,1719673,4006983,3762633,1389719,6243607,8955119,2349779,3186227,0273585,0339873,4829399,1819355,9355751,6636748,3926438,3186817,9445719,5707221,9205619,1863218,8780717,8694644,6120535,4422259,8962027,8690899,8974702,1693862,0635886,1087298,9913759,6253614,4838523,4691528,4757628,1918995,1672540,8593810,9410177,6885038,2825869,4446841,1705557,2900925,7363402,0348064,0006846,4437828,9685072,0619900,1469731,3436173,1837547,0105719,0324105,7492454,5398245,7048632,9800942,1748825,0202306,0063249,8503035,2528167,3554195,8926657,8894998,2871473,7539742,9476616,6712903,9226372,8875111,2932350,4886837,2854568,6881801,5132199,1881130,5415426,3522495,4362789,1730538,0704502,7205540,1801092,4834400,3109701,2239090,9428943,8030665,9539354,1127453,8801263,3716354,4137634,8016219,7641692,9398648,8392222,6733326,4274513,1821244,0347625,7481208,0712487,9443494,9288264,4269586,0382269,9557729,5945827,6194443,6543061,0160001,8171840,4462207,3908338,3939370,3886643,7264830,8328068,0295974,0120527,2614543,1522573,7014994,3088469,8367652,9075322,1284814,4302931,8534214,5649685,5869075,6969149,9930480,7247753,0039655,3804445,2311283,8557521,3718805,8221690,3850028,7948679,3774417,5161757,1250740,5267760,0109823,7465034,2361058,3907003,7754406,7294350,1185355,4536394,9641826,0301322,2239092,7825003,4552667,2897703,1681530,1517302,6640147,1711596,8538757,5703505,1234278,1619705,2073723,7731143,4643735,3437521,9102639,4927848,5177020,0985788,2657018,5910604,2616139,2244243,5898831,5782954,4870663,2639332,1852919,3050808,4120313,7329813,0598418,4746409,9182984,0091542,4145081,6342661,7797817,6161519,6457731,1128900,4184814,6590266,7956239,7136107,4552851,0043557,1175552,2950179,4202685,1401312,5333926,7720744,4765680,7374148,0253288,1677134,1396886,1847243,8824873,2260750,0511461,0519660,3758293,4239964,9782817,6981320,4625500,7818344,5790208,3390576,3739241,8017424,4511399,2519852,9813663,9429159,2507674,5801182,3569106,1359825,4643959,9289635,7983465,1859293,1445434,7357356,4658081,8112263,1962992,1859794,8509776,2776488,2774298,5931266,9330361,5472445,8493478,4161818,0356247,3855807,4927557,5794158,1585551,1900720,2768378,8396200,0321417,3307498,7470434,6281351,6976213,4899761,4010608,6896846,4309821,1741128,2555522,4737172,3639069,7507322,3130289,8744846,1887810,1602706,4027927,2376240,4876199,5308247,7670069,7935292,7264241,3470032,6263672,2781158,2571515,1887780,3299421,1718046,9631889,9731780,5512947,2609259,0898194,1168220,4741004,2102802,3966510,4435641,1724958,0979094,4950460,3799776,5978294,9221199,8842216,4822333,4737730,3155581,8218197,7747677,0530860,1459914,6237836,8576531,7498433,1708786,7663024,9308574,5758237,9777063,2791273,5668784,7492281,4532220,8641529,2003173,5427903,6203630,3078555,2788700,4539226,9516473,4467354,8999712,7272160,8086519,8894867,2043528,0029310,6796480,5414518,1507941,8773877,3364641,7449029,3296709,7138914,8549961,0238033,3468885,2206642,4003339,3790290,6371722,2767662,2455741,4884399,9628443,0559731,0444106,9463400,2449580,2974480,2819392,9068256,1150894,7949177,7779231,7467250,2307144,5715996,7716495,7469438,9915371,6080934,7741106,2531013,4341295,2181307,8304619,6409361,8993407,3012794,9692278,5489373,3852901,4553137,7573586,7694693,9515081,9813254,1291763,5661098,5127198,4416549,8005571,3110676,6333103,2213002,5041076,6349077,5852684,2081148,9060980,5156395,6667166,1464263,8001543,0321194,5990838,1156498,6810674,2705247,0827203,2726293,8487590,7745924,4385338,1050072,7547643,8598759,0347721,0015207,3625173,8423400,2009588,6902889,7317170,4315606,3438297,9553251,2766686,2167165,5868615,0005640,6844647,8803473,0896090,8704320,9843374,6403340,4993176,5956918,7854193,1963667,3394749,9011564,8196342,0356957,1540830,3260105,5119926,9718120,6951750,2124903,6532850,5789998,4535283,5341532,4156019,7144687,2499404,5111660,3131609,3474820,6340432,1798746,7031702,6072442,7156994,2847469,3742359,7726981,8168137,9203926,8228074,0672959,7806746,1739466,0560255,4645667,5252211,5819969,1005676,9426753,2913201,4728446,0087439,8387372,9659272,4786028,6034652,8604605,1046596,5026907,7507887,3610541,5977479,2132323,1924222,4587462,9145356,5162657,2560482,2404494,6509516,4603885,3372195,9892232,7474231,8578682,8309719,2026467,4947149,0659047,8569843,8838670,1070515,7706865,4349677,1722716,1890003,4065042,3116827,9093327,9704208,9732074,4603444,7399982,5101122,9272152,5250076,7069278,5232515,8234113,4339449,9685275,1930646,8952224,5812540,2873200,7143029,4092551,5218668,8492895,4048555,7524165,1775685,2643167,7011263,4135912,0919867,2428175,9777755,8903662,2020597,4468848,1330435,3182714,8481597,3698741,7290070,8851572,2753932,8989967,6900386,6861092,2336002,1805843,8196745,5215007,7602815,7261418,4472997,0211341,6452655,6007195,9376265,4622091,5300204,9587930,2459869,7760594,0000254,0405965,4344527,8367780,8868556,0282308,3641988,3316544,5934102,6372488,1707767,7663151,2415967,3936816,9624106,9112767,2293065,2533098,5062955,1148212,8582672,4086560,4805534,7319943,4360055,2476454,4112892,6798763,1721610,7561720,0341297,9636310,6635733,5068279,9418703,6814949,1053669,0795098,1447712,3027995,4245902,0222891,2275020,1577481,4447028,9582952,6761598,8948148,1047952,3333319,1880492,4161886,8509404,2060247,7041326,4803818,8952514,2497697,1525526,0689408,8677147,7305749,3230333,1018731,4930549,7941375,7645741,2154027,9628431,2004795,6794371,3563504,6240216,6072236,0668864,1249313,2049617,7284012,2555997,3383906,9961207,6235020,9861133,9964476,8791066,2884576,9287695,1720249,6649157,0902184,3345449,9031375,8945246,0451428,4413980,2794580,3703929,7962820,3880718,3610858,0802897,8533914,1619857,0879240,8950783,2076737,4830406,2188186,8856944,6710523,9980095,0774837,7218528,7615742,6894938,0711649,7487218,0875398,1879427,0699847,2622928,2612394,1720010,0782735,7206347,8748084,0136975,8078923,8459607,6018124,3512791,0566224,5470268,9152055,4966345,3351083,3278938,1285624,6306437,3462859,5182269,2312454,5909649,1796194,9014594,7317088,7043000,2634926,7457257,0907773,4271797,5697118,9462588,1776090,6220620,1673855,4159422,1116861,8856793,8173737,1437611,1476405,0855633,6548889,1681255,1001203,1621138,9179384,9591526,3734441,7487051,5159837,8793885,0875985,9056386,0639372,7875236,4459965,9137532,8423559,7138591,8237154,9717722,6619947,3876234,4572227,8697470,4953421,7849006,3134912,3789098,6582956,0095171,2412998,8388368,5792520,1439043,8701836,4920760,6693148,7857370,1102258,9877865,5809823,6514715,4631785,4184756,9390134,3435651,4540011,0477320,1821145,7676698,2121506,3050246,4581685,7131839,9384432,5263082,4315131,1855727,5100141,6614131,0802974,6985616,0242569,9998519,1122624,7505014,2838041,9193592,2706002,8227663,2737418,8707977,7792550,3048393,5069247,5454372,4145664,1505745,7370433,1842640,3402234,8679996,6698819,5083749,6512183,8773286,5888422,8285230,2574844,7742908,4374114,7739841,1115628,8636062,0071903,1946674,7536498,3632240,9523567,6197680,7873573,3926930,2697417,4067284,1440001,8374903,0104494,7016818,3939768,6981521,2999815,0253198,2269928,4920923,0505983,7982364,5565681,4482447,7937938,2340922,5373968,6580821,5003044,4125872,8681249,6553848,8634959,5843701,5112462,7868120,0218216,0567128,9321196,7365475,6617419,7401375,0182064,0817770,1797965,5589525,5026855,3256921,5708784,7684549,0921235,9848550,9677985,2184031,7365556,6464363,7834845,3648723,7347344,0534871,8858517,7001713,6716933,8949156,3378845,7975094,1693618,4234520,0729654,5884916,1911176,8008139,4693751,5963226,8772614,6399513,8630709,3440814,2418514,1065034,9130688,7381024,0790198,8919617,2952237,6577187,2271974,0249229,7721297,1858813,9351677,2574425,5597413,4573800,0113688,2878473,4882574,6439914,3924459,2622060,2478574,4365334,4595259,9266410,4974078,5947827,8959994,0098074,5377950,2909885,1833436,8170723,1802792,6429414,6957201,9860299,4680554,8800631,9137271,3239303,6210021,2298141,4336604,2693127,8552206,6034180,3151582,6290405,0832841,5586553,0158476,3522799,1840190,9452152,2384527,7930599,6300849,2704754,2491071,7920739,9571159,4213161,7487219,2942266,0246140,8045649,4696532,7490808,1372544,3651726,4011170,5583722,0175394,0005340,9045012,5633744,7024684,0866837,8175903,0121994,8743891,3952351,1512535,5152908,5860445,5532749,2020990,3184018,8493185,7005557,0361607,2304944,5778094,9724719,8082985,2687698,5294216,4892707,0289573,3670378,0079376,3121478,4367812,1414644,3183813,3046240,9012109,3348920,6612966,8766658,6605012,3185030,7930002,2964228,8415104,8868837,3220395,4335065,4921927,3049267,1826340,1345065,5751294,9796247,5616347,4666193,7449718,4393368,8017581,3283916,6077320,4016078,2516305,9830259,0056377,5068713,6578328,4529150,1787773,0413819,2800900,7878344,2430177,3783964,3426548,1366571,5761958,5856932,7646640,0405392,5485720,4793852,0152323,7104503,4246645,1923447,9467307,6805260,0005794,6236967,2132408,9411022,9737442,0690983,5476236,5607779,8598630,7468016,9063460,2363549,9517108,1158215,0679140,4594017,9458484,5577075,9348803,7737200,5713655,9783787,5348730,9054846,4750251,7242943,9686216,8543205,3903541,6839595,8190964,8997040,6823336,7237862,9398413,6032743,9594930,0000502,7315798,9639507,5752713,7200041,8051423,2264872,5914782,2868502,9257143,6386666,0743029,9388324,6866788,7784234,1587510,7907703,3495089,1344136,2717525,1459064,1952176,8886845,0854304,3556644,3835233,3945973,1582516,8370105,6272794,1729502,3099387,9924506,8962933,3122175,8321927,6735119,8496724,0485687,4984121,9077508,8304209,2869121,5618798,0221891,7593078,3474747,3662650,7466923,7852790,6279921,8206772,5620886,5610134,7329404,1359801,9817744,1938942,9575366,8491675,9679002,6330047,3613337,1765712,7157659,8546925,9291959,9802258,6012167,0094830,4037201,1076828,7017470,3941545,2970663,9263336,6186692,8040927,2466145,0868842,0701304,8651215,0733190,1676717,2963674,5055565,9648294,0708483,0088962,0872358,6250968,3900387,5943213,7179037,2574309,8203452,3220158,2304946,7398963,5581686,9652346,6948804,5733085,6840186,6145107,8160285,7181986,2440754,2957892,2085093,3427026,5332732,8561774,6819374,8638947,9306828,8112489,1218946,3519554,6000061,0061087,7152679,2647648,9293320,0797734,7850690,4344499,1893478,6423832,7584302,1724623,4298328,1705347,6984638,4451224,1037070,0563233,9080678,4856969,0225567,9843047,6358427,5698128,5351880,4684358,0395306,3367595,2099047,7848625,0663417,3084550,3136453,8345309,0112089,5371509,0959476,5462670,8805322,2537210,4286861,8319282,7257470,2106372,8887599,9899874,8465865,7803197,7146072,5774986,8387187,6120605,8331699,9561868,5603847,8917932,6102353,2735963,6895774,6294066,7971686,2562536,2987189,0294335,9687498,3052238,1778448,8673459,7901986,7525502,8960116,5316857,0520107,4380980,1361777,4103117,4343499,3600850,2519426,8010861,8733076,8038605,0110445,4435654,8985805,6598672,2736495,8922070,2791322,4373736,8942915,6005565,7645069,6157212,2541386,0440054,1027141,6438856,4136175,5379633,7586383,3753890,0319728,7942588,2135415,8802287,1062882,5374107,4256649,7935768,2546484,1268119,3561560,2544191,1937502,5761676,9175711,7980211,2805937,9882667,6933118,8698176,1167878,0890790,0925498,6992389,5185112,8258188,0789809,8517949,6658110,5327321,9647294,2129322,0294114,9786545,9940853,9108433,6536101,8886976,7822594,9647272,8209625,3506658,7708112,6106994,7463234,9747065,1692145,4875238,8750062,3286032,3176450,7726192,7475460,5590312,5401493,7302844,8266178,1759524,4327924,8529081,6185142,8532810,9955465,1987626,9547347,9747845,8110782,3948711,8354421,4682857,8854519,8392930,7104610,0433182,6028554,8298683,0022153,5681769,4460422,4868515,8018981,2095608,2684013,0729024,9145552,0431684,8915026,1994128,1537515,8841455,1020022,4648732,6599791,6981222,6662207,1210169,8893125,1851994,9621843,1177754,5117273,8422123,6845195,4120240,7525023,3044870,3982765,7888085,7479919,5950388,6877396,8739833,0953588,3303076,6457751,5164838,6323234,4016862,3943501,1663322,1741201,8592487,5141522,6750762,6468483,0725960,1858999,8404431,3798108,8014176,6191849,5324010,5642504,3283694,7991975,1312314,8345111,7391053,0012734,9378554,5888660,2517280,0032679,8262312,6783152,2442227,4134469,2322658,7563690,6953891,0651470,0553786,7407456,9380777,5812034,3355548,7258317,6414219,1794416,1458836,5751220,3949623,9685180,3534614,7483856,5294396,4789194,8587860,1003838,2991357,1118006,4206070,4225237,4838130,4270343,5077714,8224983,9865108,1104816,7231755,9193632,3921732,4424688,2023473,3583079,6062878,0110886,9687352,2114074,9015970,3518703,5088903,0720545,1229444,6597957,3792203,0529115,7052641,8480753,4546396,5128357,6482395,2206788,2654765,9616392,5094727,4865568,8608913,8006810,2978787,0595784,8277370,9739717,3928535,2617117,0142140,9488770,8787399,0431797,0046360,1392126,0798590,8555722,3282918,4405689,9388168,7242425,4045930,2437723,8616762,5119342,5524376,7272848,7681923,5690549,8290622,8262065,1284391,6452647,1768324,7942279,4729359,5927639,4193699,2547543,3403492,8656713,8407087,2473311,0303704,6797470,9530152,6099327,2163661,3478683,4081510,7159326,0705082,0424368,2508479,8134596,6903388,5161888,9862845,0138735,3004976,2757962,7381802,2503725,4150327,3365949,8562778,9568454,6351766,5239636,5931301,1130669,2130352,6675090,2978438,6436811,5456923,6929001,0056148,3197534,3151385,3935919,1203825,2407247,4885772,0696989,2754353,6565018,4319753,2927017,9534696,1045591,0110709,1938156,7756154,2009355,6137837,9140347,6660703,5021841,9077056,5126911,8580584,3699773,1284732,3032044,8255472,0257820,5407407,1811414,8489818,9959532,1715597,9268708,9962675,1994026,7427156,8273884,4030819,7292220,0500820,9141013,9508513,9898473,3543600,0171184,0968065,3082680,0834568,4697973,4814843,8720433,6404336,3094581,8407638,5839016,8116330,5831964,1183738,9713595,7051587,6968178,1997420,5765487,8571828,7836719,7358920,2600620,1092318,6321573,8095479,2492787,1373758,1284959,2102692,2868242,2991526,7455198,7691712,7993078,2837916,9829990,4517757,8919412,8331095,7176610,1233045,0333662,8791045,5062423,1796324,1922091,2198023,4909877,4398082,3941053,6877749,2801335,6108178,1931029,9162363,0001128,2610620,8178902,0122830,2128901,1936507,3532462,9147991,2270497,5093888,9715919,8729003,6020061,7644242,6474181,6077197,2825856,9056375,9875624,8345725,0399541,5099424,4747499,8796388,1416311,9054787,4455073,0039933,4351226,4930878,9635848,0483796,0516883,7314326,9907917,3303802,7009594,2678605,5601887,2320038,5094804,6244177,9577795,1491654,4889613,7078443,1597406,0654810,6334942,1799018,3006765,0982388,6970801,3696397,1914152,1837432,5203629,4978720,0968540,0959986,5552101,9563130,8422318,7000173,6301199,7367388,9407658,6091142,2106024,7456222,5246868,7734409,1669951,1151334,1643667,7160166,9004028,8811935,6397069,4242089,8391165,3535735,7171428,7702777,8149771,1756182,3038966,7486944,0952175,2883541,3590958,0688231,6227503,5352970,5614828,9359920,9099469,3555572,2512112,9488076,8638792,9813035,2736254,2763933,5470038,2646839,0887690,9029209,1111857,1942569,7022155,2238287,4807932,6196352,1291216,2657571,1870251,7291455,6322400,1804165,4300984,9665654,8195074,8715144,3628908,7809648,5593789,3945762,3336573,3257920,0802094,5991314,8610976,5547287,7877505,7958473,5976649,6569422,2979853,1542103,6579403,1263882,0559189,0182756,7313159,5219449,0253331,5378383,8661418,3658210,2437286,9903672,8795436,4491445,5192431,5014988,4385387,5060399,0733018,9683948,6484667,1435973,0410968,8896549,9486625,6180330,8244836,8652941,0630806,4167481,0489258,3135586,1158582,2506776,9427613,8819312,2885163,7029185,6535538,5358711,4958924,4102199,6983285,1150248,7762171,7942094,7118120,7156614,7898191,6678725,1074547,3819364,4475693,8696293,8083754,0778195,6023039,4060954,2923825,8750871,3118691,6046553,8313382,4464164,5331243,4440503,9289705,4253077,9810850,3743539,8677475,8679288,9278360,4913228,8991699,1913204,5236267,0359248,8057884,4825739,5504394,0474602,7096682,4389573,8790176,3066181,5436979,6552874,8229657,3980493,4108887,6553596,6479029,0421615,9820214,6827362,4034571,1970708,0370684,5220380,4071221,3847302,9013091,8301778,1232188,6550725,9934596,1893308,6236090,2137346,8491142,3059082,7189228,7799418,7223881,8449166,5757637,8841775,0680233,5738543,5512185,6971393,2054024,1365729,7492920,6322081,1222768,2641625,4195388,0718218,1033255,5300499,1627603,1890644,9127901,1012683,0566617,1191214,4133989,0271059,2750687,5799164,0897845,5764337,5128970,7577367,2052084,0728193,5453232,5437295,9762417,7165151,7029506,3167292,0695076,6940529,3895271,8045686,4874272,0946083,3270944,1367782,0391724,9165050,5627483,5068432,8940087,2921187,9480486,2725933,3198908,3714304,7573515,6814681,0931351,9692115,8528020,5279669,8942976,9922992,8377559,7579519,8772170,9824500,7150901,2491821,3718705,6532807,1165567,1298068,2523040,6886470,0243288,1843867,3631742,6214073,7709733,3346109,7737244,8646855,2773548,0999981,8606027,6609976,7748630,4420206,1608556,4606047,9464905,0615240,7114150,9141184,7689885,8886555,9749111,3881589,8547410,4759845,4141899,2150001,3060486,3793077,8808601,3597147,8915660,1721537,7291145,1315179,2902704,5476011,2000507,9737575,8573988,1326816,8714135,3503748,0819192,9332974,7743280,5941587,4212470,8505151,2033335,8781310,5246666,6306400,6361731,7251224,8028416,0846032,3392653,3212670,2087841,9499487,1675974,5766513,9383128,4260422,8336723,2685867,0237953,3396206,2114193,9276314,8681152,0249894,5155910,9370381,5052141,8598435,4318629,4791495,8967608,6314768,6668869,6931850,5450703,9527171,5816956,7829443,7220870,3927902,1859019,4730477,6270314,1348638,4735078,1298091,9429304,9508854,9790260,5888118,4411913,4701130,4472418,5866064,4347355,8672640,4925957,5302324,4708720,7942045,7596189,1074318,0677432,6401754,4608875,6427605,6383946,8498353,9898266,4430718,1442907,4231239,4226920,5803114,8399055,0690218,0944809,7660721,5609485,7591591,8231431,0010082,8070317,0308503,4439683,4558134,7476847,4272427,1050170,2624009,3313489,5714186,0515448,2543441,8029129,5771574,5302154,6601134,3062297,0921376,3232677,5987675,4583776,0698712,7406589,9661020,3299257,8362076,5934484,6360695,4583870,3347589,3672971,9689045,9968808,8086265,9906063,1087823,3260834,6111464,9399859,6919800,6259973,7442326,4386867,2378749,4321568,3166749,3374577,9315188,6376300,3851570,2745831,7192941,5203233,8929636,0925880,9580752,1034338,2749544,7317179,3319855,5855378,8589071,0855191,7624284,6720518,0756492,3576242,2691203,6524282,8388617,5160238,5120007,0163662,5473177,8521844,8750164,9682473,5554309,5631847,8379721,9271869,4718854,8964912,9938737,1798755,1498399,4434923,4765634,5448018,9128518,3431781,7342065,8615436,9796274,4473712,6518597,3688612,2072798,0082825,3918110,3374299,1659181,1135779,1187943,7907232,6212482,8831783,0956743,8215373,3225479,8904127,9269593,5841303,1449946,6496287,5110230,7268389,0726699,9292390,9643881,5023051,9986710,9960151,8428193,1049973,0987642,7871966,3801871,6650253,5598440,2258705,9234907,3761125,8802438,4276978,4754783,3668281,9224073,4114191,3527543,7153265,8783701,6972310,7662081,0630630,3436309,4685195,7767305,4355300,3886761,7230060,3670840,6694233,9244921,5582555,2012540,0272814,9307598,4499739,2035849,6607714,0308386,1282322,5981045,4001728,5334194,1664054,6046927,8686220,5284063,3995944,7482692,4854349,8177539,3387718,6807835,0689311,3026400,8105146,2806547,8022030,4819370,4233860,9425235,6339713,8120228,0123862,3409319,5049176,9417430,3996839,8441646,7017037,5653390,2654951,0213086,3717875,3467932,6966483,9962414,7029416,8868634,2760545,1575919,4693469,1522173,0320604,9081867,2594616,7333798,4274729,6635195,9234708,4623406,9701998,4953253,4981100,8177843,0275962,0525187,0756469,8904859,4023414,1316582,6420397,1180001,2069653,8036842,7621734,3825638,4768699,6243229,5648421,0095234,6980299,4781075,9256840,8712927,5440016,6481061,0315082,0033362,0113311,0196684,9489480,1299333,8841716,0289090,8129245,4561310,5137410,7814687,3882024,6856108,3213124,8122393,9681048,9069052,8179789,3640680,6007248,2368669,3828218,5773772,1896598,0562121,5014460,4406273,9580374,7414205,6004704,7236897,6753174,0466337,1751731,6618810,3919938,6533508,5178018,8743886,6757319,4890113,3849952,3373095,4881967,5531185,9535227,7286292,3260772,7987919,5282755,0453929,7952899,1977637,9822507,8552026,7633821,8163291,8841446,1531372,9776247,0351933,4679294,6874517,4274659,7539035,2409427,3948078,2994910,9049679,1457121,2144193,7426735,1767305,2451004,6482178,5895230,5971047,1468252,3346605,5030348,7854505,1185920,8587368,0272374,0750942,0942934,2980881,1431122,4342357,8211301,9724488,9079030,4896003,5551878,2516026,1767377,3847307,8024514,4591073,0249905,6446309,0675394,8922908,5247195,7038045,1913726,1675915,6957684,5424262,2842099,6840847,4226855,0839313,8035956,3148850,9643660,2375154,1675439,6334480,4582483,5502777,7748702,2365841,7901712,1717645,4294729,8285117,5112611,0721541,2421407,7533690,6133818,7048883,3092655,5668226,6226300,3246964,0029212,9520526,4614494,8344070,5822169,2937395,3889105,5033400,4766953,8167821,0917384,7389282,4403219,8234372,6977583,9897540,9060054,4297291,9881639,2670369,8766746,3261242,0586459,8400235,9945037,3534584,6936127,8591642,3789463,7373071,1103202,8428719,3697448,5606650,3062489,9531817,3942778,5540613,6352325,4003443,5141191,8261965,4549088,2505155,9279637,4001294,8535866,9346620,6645974,0597859,1969625,5398670,8859979,7463356,1445391,5363139,7193654,4463004,7635681,0764060,0748779,2169735,8726016,4955517,5640640,5115452,1490104,5944514,2211649,3314976,3374538,6348387,5153260,2747409,3093106,6883032,0004237,2033390,5765400,4361425,2501114,5066211,9456293,2827018,8282466,6771309,2581148,6077218,7290855,9449283,4320259,8596573,0911633,2470697,8374789,7025783,4622211,3399173,8999513,7634738,3744669,7183828,3599473,7500807,6311640,8880669,4851034,6355731,9553077,0306206,0019513,5570773,9797201,7820825,4695771,4997439,7589982,5777481,0600026,1595133,1817469,2192586,6268585,6967566,3276928,7812313,5864505,6441981,6560461,2856238,9891933,7436434,9690835,0660218,1413955,6621135,4427581,3514205,5460858,4276215,7435462,1961229,7071656,8887747,4178489,1398909,4887708,7883429,7690996,1107741,1353615,3597723,4204647,6914443,9646912,2930671,1674449,4980011,2356911,0742844,0374437,6504173,6135583,8559517,0445010,3560949,9543397,0161482,1099999,2763260,5353100,7391167,7613497,1213822,8869970,9284944,1623943,4975359,7074221,0323354,4967554,0450669,6031496,2918607,8692588,2361130,1325931,8222848,7860695,0643061,1775823,5546265,1985618,1992431,8243126,2795706,3437987,7208008,3057828,3970955,8678049,4498873,0147591,6218796,3686849,1141356,0438836,9652745,7168540,7819855,8233491,9929520,5431435,0802762,6500468,5428691,8832634,2292771,3961387,3866408,7470947,4428859,9788324,1746175,3181642,0023559,8712900,3227361,2799196,2981490,5270186,3095474,2878308,9426099,0413506,4748033,5584585,3987956,2252581,2514107,8620677,4558607,6157017,7323854,0622818,5099720,9316289,3004048,4830083,3916314,5774026,9475529,7998901,3514721,9849416,6418978,7136757,4310605,3721597,8945386,4221405,9383170,0670363,9026664,2962594,9374225,7606090,2623052,3212717,7685211,3247150,2683087,6970924,8641383,2007683,2846142,2499473,1045334,8540402,7564227,1086551,5444899,5684722,7012940,7322774,7971097,0952238,3304925,8339779,8746774,9255306,8354705,8340834,7120073,4320557,0530055,6675432,1227191,4920744,6924716,3017457,4272980,6117182,5373508,5554829,4373886,2826421,2072478,6099212,5359272,5132082,4579451,6939768,6116043,3294881,3548008,8089854,8113972,2352659,2557469,9575154,6971524,5540021,3857672,2232178,0860056,4054446,6004196,2229311,6541519,4297879,8473043,4827419,6683333,8120052,6560653,8987023,6859532,7139482,6434556,7869542,2157869,6317882,5286203,5972188,1236779,2977075,9821539,0870480,3092496,4205850,1284060,6945371,4266911,8292239,1283662,3753585,8437717,8423880,1013573,4458381,8215013,2034475,2569253,5493064,5335306,8700098,1018537,7437462,8001143,7784877,0510016,3827826,9892620,7653520,8391063,7371895,4254828,4449572,2963670,7894053,0310263,9998599,3389742,5671493,1160449,1402787,2160779,5765414,2283117,6344545,8293301,3420724,9632226,7564833,1493694,8292946,1254704,8996530,7844586,2466735,3586650,4848191,5733804,0205191,1051930,6852021,4623233,6365309,5170896,6328981,3893404,0532221,4419115,1006159,5981135,7743586,9160170,1244673,7533295,9791798,7469840,7666180,2466167,2518050,3609963,2263543,3704596,3736846,5162741,0614257,2234514,1029278,5787658,3182014,7036255,3215237,2848037,5845928,4622042,7733644,7803200,3639260,8606474,6929382,6627006,8196773,3976850,0584603,3370816,2859643,8399958,4807143,4415015,1532912,0035712,5128070,0873551,3807469,2294890,1315981,7725092,4094418,2901354,0138626,8142714,8348985,2878975,5410745,7032257,7109156,2032391,2325332,0794914,2436565,0344284,1273236,1423362,8839141,3937263,0431597,2183205,8883057,0679585,8340624,7995907,6098994,4911410,2659221,0128196,7931454,8270950,0901197,2977924,2533159,3179472,3839879,6064223,7513947,6588105,3946410,9391240,7599463,2036121,0488995,1773964,8311212,0193136,6847422,1586466,2904305,9580920,8732838,6301420,7135672,5715124,2144495,3870310,3072276,4424413,1757441,5310072,8440902,1981488,0303184,5390637,8137774,6313670,5369341,9557869,5839132,7560126,7288254,2697025,2367762,1089655,6288792,9174437,9055022,5008221,5895077,4465607,1537456,4261347,5599503,1052470,3758803,6431409,7303116,5586478,4963305,9976559,5705675,1569504,9993187,8714972,7130035,8455547,2800946,2047529,4206631,0566624,7705620,9693241,2074648,2889622,1057022,6204379,3041099,2208826,1877798,8160553,1155120,6873598,1331794,2550285,0664375,0287413,7283645,3402612,8963048,6241757,2330605,4774302,3422274,7028876,3122068,1380909,5457218,3756502,1632174,5388541,2628902,0816065,5193426,6143575,7517143,6886051,6060884,3648813,6581898,1659751,0435659,0183778,4980755,0588784,4918370,2779196,2334949,2240600,4247599,3815136,2820787,5653900,0114736,1234143,6027811,1288188,2793803,1190594,0967561,2180210,6665507,4367079,1317760,4153812,9151332,2777053,0777717,3431977,9231166,8585118,1068976,2491540,9354802,1192380,1545052,3441336,9737290,2661435,2683871,1212630,1283579,0843089,0254609,1568328,3223925,1090440,4621379,9051250,8491472,9172988,5626436,8815530,7687245,0654219,2674607,6551911,5856393,6446193,0442743,5842341,3977096,1074906,0979505,2627928,4007196,6452963,7438677,1226817,0929524,7692884,9998124,3204972,4932513,0982639,5617197,9718682,1268173,4466456,5712022,1080904,3532309,5568213,0162034,4516777,7702758,3202122,0986824,0432138,1693208,8348852,0276241,1315807,5663588,4628249,2701569,4421309,1303727,9939860,5838612,4956077,5266729,3124281,4822441,2269650,9358490,7332903,9319792,3835636,3488601,2353839,1371176,0550056,1277660,2796491,6959542,6327377,9391833,1174302,0661605,6039542,1900251,8426843,0393503,6507419,5408235,7870264,8610220,1666564,5065702,4549599,9323530,0417318,4349075,3134405,7277978,8019680,8220418,9918796,6891050,8733386,8529890,4892502,1785644,2354300,8699735,3558367,9092759,2077991,8698091,7903810,7201847,8681227,9139533,5694549,2845535,2911987,6302995,1978349,6390567,9577733,0024801,0885295,9437909,4805447,1493046,6048471,6940310,5559789,1675664,3194532,2492553,4383483,6710550,8590240,7808230,4825886,5761803,9129578,3508710,3016041,4949321,8776638,6641328,5628111,6432601,3681848,0917377,2757014,9395902,0544465,5600200,8678139,8912497,8828395,8304129,4277718,8925439,8436083,3411655,4228516,5351311,4385411,3293925,4214191,2971083,2313781,4941616,4154776,2300285,6111264,4571177,3849284,0172705,7379738,8119343,9487163,4651680,6010992,6432995,1752563,9886573,4722344,4547580,9974758,2685569,2016073,2986957,1076092,0792678,5071213,3993186,9496184,1116995,4343143,0846034,2425689,3412868,7872245,2868608,6717696,0844876,4964225,8366450,6895063,5493494,0095822,8593011,6968399,3819765,4088775,3196596,0782667,3108691,6567619,9704826,7807429,8135417,0223646,4901506,2859963,7371884,7420689,2995777,7265071,3317792,1126779,6515901,4733989,7795482,9261012,3111501,3566466,4813087,0811131,1761350,8534680,1412729,2878062,7284919,0295361,2209708,4974052,6480703,9044964,4529677,3884628,3321918,6574173,9107778,8820615,4119872,4524144,8299913,4194044,8025442,0439919,5113671,8873422,7648234,7559148,3331271,5556164,2961161,3715810,2591021,2386839,3819673,6487422,7807917,6835594,0723862,5570065,4168277,1609445,4279083,4836244,3154793,4145338,6604832,2986680,9414027,7728046,4023163,8271949,8296260,0687320,5096914,8755075,7135750,7224350,9205163,1215695,0486673,7086578,6180206,8593859,0509866,6062614,1333244,8881523,1373038,5865070,8013392,4397876,5237953,2609222,4313892,1157081,4266835,4152991,8165258,5678139,8187141,1453850,6463805,9726121,3715164,7284578,3820217,5547148,2037939,9755423,2433823,0967821,5273759,4902190,4742875,2142171,6755761,3725687,0480697,9267520,6896081,8176976,2180011,3702042,4304934,4754744,9618276,4903530,1631095,7481451,4989803,8458866,7737685,4123087,7528950,1788707,2239952,7649913,2512527,6057067,6903661,8008322,7441164,0258399,6646184,0012503,8791547,9908208,3968691,5666967,4103460,2592723,8136311,6272921,8062132,3528440,1550043,3472086,9630647,8284372,7052352,8633059,6758178,6639480,3570700,1357794,7517596,3336323,2065146,6484561,3182895,0084935,4700477,1356781,4506279,5620896,7848194,4831899,8608018,7857618,6157828,9177913,9569433,8674371,2040417,5964021,3200689,8529783,5468689,4188821,8314942,5855200,2382235,6799835,4793939,6385208,7852212,6456901,6734156,8086383,4373663,6535908,7227817,0256733,4969266,2089901,3118323,6196381,7042059,5133947,5548179,8351928,8486814,2182872,2366144,1530331,2590453,1794703,8879238,3193985,8902404,3212962,4585067,0692618,9742422,6401426,5491106,4154695,6050952,7711388,2889855,9151589,3716130,5513239,2302181,8381095,1343206,8886962,6341009,4811666,8204383,9004100,5213056,6545917,7773119,8984978,1506995,1220837,3378884,3461295,0087123,1825971,6621588,2445715,0294088,6586095,2198465,9474571,7374930,3466865,9557151,2015174,9692769,0185505,0635241,6287068,5461910,8593704,8361146,4626883,8488339,9645217,8673584,3178983,5106844,1744884,6871719,9415727,7213891,2760340,8805889,0599082,4287403,6379022,3383149,0987316,1845212,4633513,3135092,0439337,8907148,9660135,2441524,8040495,3184664,7787593,7703389,8483390,0127594,1722727,8451948,9729211,1851189,2167517,4255694,1839353,3282261,7973428,2847523,0957020,2799044,7232544,9255839,4616149,8723010,6152476,3605932,2875570,8967011,6576272,4697900,9173163,1300296,9272682,6837349,9169268,9104406,4990226,4736201,2875492,0065913,7976812,2495841,9051731,2439225,0468389,4168539,7767042,8107476,0627979,8429029,0979809,9175921,9172180,3871794,1809788,5474555,2838342,3551222,7067349,4854632,5558376,7426442,4020531,2358024,5201997,1942193,2519700,7517417,5396493,8055265,8703888,5933996,1883770,3258685,8664180,3011836,7405739,9219809,7639556,2396823,0027451,7354580,8907664,9637615,6044143,8998290,6697389,9018935,3273055,4443091,3900853,2786283,8860538,8084926,3363558,6947238,4332949,8792008,3048123,8065397,0497902,5801637,0947803,1580422,7614393,4322829,8608460,6008449,9001240,7828295,2458969,9075434,0544832,7093445,5997502,0739590,5613624,4821529,9589958,5083690,3363749,6358516,5300856,9450928,1714137,8364932,8224890,6694262,2928715,6718115,0931005,3122713,2202830,3916481,7010180,2000925,0503888,6186293,7815973,0553916,2015277,7369371,2500806,9970200,3996941,0362635,0725743,9520277,0627467,5025913,7555060,2703860,7291030,4362768,6758596,4053981,1140615,8040817,8739197,4413192,5902283,2722447,8398764,4630891,4204360,1673959,5923792,7567489,7121883,8011247,6878009,6200403,0860562,1926228,3310993,7469377,4314649,5223716,5241040,7156956,8520073,3172451,0759548,8831564,3780883,3494934,9523193,2849053,2724048,7681990,5190383,6768082,1799326,5517160,4828408,1474515,1307320,8840857,1027349,6735608,5864186,1963214,8230239,1161250,8112446,8958501,7616147,0849793,1097540,2924093,2489317,9737926,4083478,6221286,3516665,7143630,6747834,4737328,8875904,9563450,0396327,8485331,5587349,8558144,5025853,0296708,5916593,6074529,9253149,6305464,8069777,6944555,0570822,6761221,3058349,7776329,2321109,0027021,4290884,6097485,8471631,8328102,5500320,5762397,4202763,0575819,3671480,9528087,6375999,3845354,9306467,2640891,1579855,0795883,0229188,7409027,8749315,4863409,7917343,8389923,5293732,2111640,9043844,8492594,6756069,0176177,6882908,9600600,2124770,4955359,2854627,5253373,6781353,0349273,6784845,4934275,7390023,1998352,2451549,8119734,9915018,9530926,7563434,8157151,4779748,2331698,1696600,3537204,9905719,2869115,6968624,2671047,3466189,0690115,0336191,4346027,9371296,7326087,0348995,1472598,1050804,9097691,5036792,9935796,9825589,0005802,3929561,0341976,0240176,5722455,6703825,4163265,0337448,7590848,0630918,8106892,4645802,1955126,7959191,7029697,7392818,5475800,0726345,1856980,5044362,8615209,0075040,9153425,2182815,5736786,6807576,7851312,2788386,1270575,3763737,7800234,2105379,3306294,4496970,7904451,3051636,4589588,1358740,5424955,0284855,3821676,8022933,0097856,4372574,0447625,7862550,2481364,0686330,2245223,4241724,6799216,0702631,1018903,7801227,5263324,3751261,9426794,6361270,9100033,1556399,8637935,8722176,7421549,', 28, 'MercadoPago', '15', '00020126580014br.gov.bcb.pix01363c615d77-4222-41e0-be1a-8f45807fdd5a520400005303986540550.005802BR5915THIAGO-DESIGNER6006Manaus62240520mpqrinter791237634696304B8AF', 'iVBORw0KGgoAAAANSUhEUgAABWQAAAVkAQAAAAB79iscAAANzElEQVR4Xu3XUZIbuQ5EUe1g9r9L70AvhAQKIMBqz0Q0banfzQ+ZJAjiVP/58fyg/Hr0k3cO2nNBey5ozwXtuaA9F7TngvZc0J4L2nNBey5ozwXtuaA9F7TngvZc0J4L2nNBey5ozwXtuaA9F7TngvZc0J4L2nNBey5ozwXtuaA9F7TngvZc0J4L2nNBey5ozwXtuaA9F7TngvZcqvbR88/r7B9dK2e7jnq6K/x6rewnqnlWZ9jIlhyJdldAO6+hRatraNHqGlq0uoYWra6hRatr76xtlNi25/Ks/jzq7JyTq/zm+kCrxnsZtK5Ai1YKtGilQItWCrRopUCLVgq0P0eb/btHrOaXY5W91bOs2r3ffd/cetBaAS1aFdCiVQEtWhXQolUBLVoV0P5EbU6s1cfGvVzOeJvdy8+wQvLajwVtrNCiRfsK2lihRYv2FbSxQosW7Ss/WtvcFbqgau+SrLZvzk/bXfYDtK13SVbRtmto0aJFW6+hRYsWbb2GFu1HaNu2nXlybH7GMmxXrVmu7M4yaC31bFZr0KJV0KJV0KJV0KJV0KJV0L65tiW0f/pnMtB+189koP2un8lA+10/k4H2u34mA+13/UwG2u/6mQy03/UzGWi/62cy0H7Xz2R8vHaf/E+gdS3/J7Stn2U1Xl/naFD1tGpc+SJo0Spo0Spo0Spo0Spo0Spo0SqfrF0oFjtuWz+zsfGT0LzsWc7aB+XIfPTLb76Wtuux47b1M7RodYYWrc7QotUZWrQ6Q4tWZ2jR6uyva/1Ib9au3MbD7azOsSu7jki9YtucEdt25kFrV3YdkXrFtmjRaosWrbZo0WqLFq22aNFqi/a9tP503PVtPFxX86X9Zcvuw61jmXH7Z/GCBS1aBS1aBS1aBS1aBS1aBS1a5eO1cS1bq6wZ4yVvXLZpHPci43nL8mlovREtWgUtWgUtWgUtWgUtWgXtj9Bma33uec22VW2dXxqyOsx6b1DZm6vsResFC1q0Clq0Clq0Clq0Clq0CtofovWjOGue5ZF6Jb9vgX7Ns+Q2r9RtC9rdvbz8RLuunncKtGXbgnZ3Ly8/0a6r550Cbdm2oN3dy8tPtOvqeadAW7YtaHf38vIT7bp63in+njYfybE+2++qkNv2U9se9TPG90Xq5eXMM0ZeS7T+Glp/2oK2tEXQXndbK9rfjLyWaP01tP60BW1pi6C97rZWtL8ZeS3R+mto68To93FtOz8jFX65QWPrbVm1jna2q1rQ2mW0aHUZLVpdRotWl9Gi1WW0aHUZ7Qdrs6u6A1/fzLMotHvjm+e2fcEYZPeWLVq0EbRoFbRoFbRoFbRoFbRolU/WLq01y8P+Qc/xfXk5VxWar9g2kw/ElVqo93LtF9G+ghYtWrTXew+0r6B9BS1atGiv9x5oX/kQbb27PJxf0LSZ28IgL2eW9kF1ePvLoW1B6zsFLVoFLVoFLVoFLVoFLVrlE7TjRrTWz/Cuvhra5XPrU3a5FaJj/2kZtFHIoPUX0KJV0KJV0KJV0KJV0KJVPkYb1zK1mokP8iu7b0lF9mbb8mn5im+tGqvcokUbQYtWQYtWQYtWQYtWQYtW+XBtG+ZzMgu0Pvy43MuIdVhUI7V3XrkaI2jRRjXXaNEqaNEqaNEqaNEqaNEqH6jd/WS13luG1csxcXzzVLS2PPNVtHnQolXQolXQolXQolXQolXQolU+WZsvWWv+RLW2RgYgku7xY2lP5eXIWrcrua430KKNc7RodY4Wrc7RotU5WrQ6R4tW5++uteS1+tzy0nWqgv3rheUja+ypLLSXH3VkVrPgQYtWQYtWQYtWQYtWQYtWQYtW+XhtNuTEHGZX7JHlC9qI5rnW3bNLm1aDdtmizaBFq6BFq6BFq6BFq6BFq3yMdijyJ9Iu7z6jdbTs8ZZmDEYNWrRxlut8Dq2CFq2CFq2CFq2CFq2C9hO019HSGj/tbHzL/LRM+6Ccldt6b4FWMtoZtNdR3EWrbSS39R5atH2aFdCiVQEtWhXQolUB7Z/X2rVdAmrZrXz73GjzM+rYXt0PH23X0nY3QbtW98NH27W03U3QrtX98NF2LW13E7RrdT98tF1L290E7VrdDx9t19J2N0G7VvfDR9u1tN1N0K7V/fDRdi1tdxO0a3U/fLRdS9vdBO1a3Q8fbdfSdjdBu1b3w0fbtbTdTd5cGzfyJf+JlCdfycujd1n5jPwCS2qzwx5dRqIdvcsK7ZiDFi1atBa0eh4tWj2PFq2eR/vmWvu3Prc8nB/0r9paGvlxtUV19Mb2aruWtrsZi/YVb4vq6EV729aC9rkZi/YVb4vq6EV729aC9rkZi/YVb4vq6EV729aC9rkZi/YVb4vq6EV729byzdpnbWhbP4s5lnolk71xpW3r5bxiL7fe5QztmBipHUu8jhatghatghatghatghatgvZttGNsZNMVheyNbTRdV9rlfOpX/dz2d2h/NA/aJeMy2iVotfIOtGjVgRatOtCiVQdatOpA+15a75+v159IvbKc1dmJWh7we7sHBq/51h3a8YDf2z2A9onWCmifaK2A9onWCmifaK2A9onWCmifb6C1u/XHnpvGLOTEcRZaP0jFzr2MrB9pV2rvtUSL1oMWrYIWrYIWrYIWrYIWrfJp2sf2hlIBy3OWdqWtGs9XMSPP6qNoI+0KWju7ltuX0PYZeYYWbTeivS6hHffQoo2gRRtn13L7Eto+I8/+izZlGTv21fJSTfKWxKs+sZ7FF+zP4i9S/zZ+5VrarseOfYV2e4Y2gxatghatghatghatghat8le0tRitaRxVS7sXw7KjnY2OTA7KL7AtWrTaokWrLVq02qJFqy1atNqiRavtz9BGcoT/xFlDjaq9Emftw/OsrUZ1+TS0aNWLFq160aJVL1q06kWLVr1o0ar3Z2gt3t/OssGyyOqw6PX17luW7J6ybfuzXGfXUvFH2hnaXkBrmSMqwAoWtEv8kXaGthfQWuaICrCCBe0Sf6Sdoe0FtJY5ogKsYEG7xB9pZ2h7Aa1ljqgAK1jOanNszNlv46w+1zx5Flfs2K9UwPay34sOD9qlivbaRdC+4lfQZtAqaNEqaNEqaNEqaN9Q21ANUFfLCG/LEbFtn1E98d5Iq2avb3ONVle8hDaCFm00oO2eFrRoFbRoFbRoFbTvoL2Oypvj4YWXRotfzo+Mr6/fZ2nuxejr5euvtmuZR2i9zYM20qpoYxWvoEWLFi1afwktWr2EFq1eegNtzKnbnB1pZK/aahnrWT48v8DSRvrZErRo4wwtWp2hRasztGh1hhatztCi1dlP0GZ/UkZ/fEEt7CbmR+ZT+UGxqlcs7XJUPWjjFd+itfOYgxYtWrRobYvWzmMOWrRo0X6etp73wk5Rc/ORrrAkwKrLjPFyq1rQolXQolXQolXQolXQolXQolU+V2upbzbj8rPT7kc8N3+HlC2pl22GpfZeSwUtWgUtWgUtWgUtWgUtWgUtWuVjtOPNLNhL0V+HxcN5r35uZHdlFPLMsvtwtGjjLNdoZ0dcGQW0c8SOUretI66MAto5Ykep29YRV0YB7Ryxo9Rt64gro4B2jthR6rZ1xJVRQDtH7Ch12zriyiignSN2lLptHXFlFNDOETtK3baOuDIK/1HrN+bDDl1keeb3Hvsv8DNL/jEsywM53M/y5fo3LO1o/cyCFq2CFq2CFq2CFq2CFq2C9kO02VWNdmbVncwSz2XBk1/fKHZv+bPsLrdvRutry5yNFi1atGjRztlo0aJFi/bTtBYHZOz1BV8T1d22PjqNtbD8HbK3DregRaugRaugRaugRaugRaugRat8rtYv3vBymxPXl5bLUW0dtRAzRvWLGdcS7ZhdC2gjaNU2ql/MuJZox+xaQBtBq7ZR/WLGtUQ7ZtcC2ghatY3qFzOuJdoxuxbQRt5Um8OW+NnNt3iCd3tWefZAvJdXPHmG1vL12AdatBG0bVvP0P6mDa3l67EPtGgjaNu2nqH9TRtay9djH/+/2l3sehvRCvlc/Za4UodFWqF+/dLr6wxatApatApatApatApatApatMrnav2RTM5uUCs8xjY7hjs74pX2Xr03n/egRaugRaugRaugRaugRaugRat8sjbPY5vakRtKLcS9cRbxU8vsrVULWrQKWrQKWrQKWrQKWrQKWrTKh2v9mRiR26uhVOs225ZUxa+x9cy2u+HXsvPuGkoV7TxDm21L0FrG2H1DqaKdZ2izbQlayxi7byhVtPMMbbYtQWsZY/cNpYp2nqHNtiV/WBtndVheWQrtqa95oxpt9eV8yoI2nhoetPHcaEWLVq1o0aoVLVq1okWrVrRo1foJ2kgdZskRs5rbvFILN73JyBVatGj7xLbNK7Vw05uMXKFFi7ZPbNu8Ugs3vcnIFVq0aPvEts0rtXDTm4xcoUX747Rtm4/knP2w9mlL1X/ao0uhfm6bgRbt1XFduZZoBwptbnM2WrRoRwHteCnGoo0ZaNFeHdeVa4l2oL5T21KvzdetIx6u2hy2fEY+tfuzjOcX/HV2LdFe2wfaNWjRzmtoPWjHc9aBVkGLVkGLVkH797TvH7TngvZc0J4L2nNBey5ozwXtuaA9F7TngvZc0J4L2nNBey5ozwXtuaA9F7TngvZc0J4L2nNBey5ozwXtuaA9F7TngvZc0J4L2nNBey5ozwXtuaA9F7TngvZc0J4L2nNBey5ozwXtuXyY9n8h+wUYJCchLAAAAABJRU5ErkJggg==', '79123763469', NULL, '', NULL, NULL, NULL);

-- --------------------------------------------------------

--
-- Estrutura para tabela `product_list`
--

CREATE TABLE `product_list` (
  `id` int(30) NOT NULL,
  `name` text NOT NULL,
  `description` text NOT NULL,
  `price` float(12,2) NOT NULL DEFAULT 0.00,
  `image_path` text DEFAULT NULL,
  `status` tinyint(1) NOT NULL DEFAULT 1,
  `delete_flag` tinyint(1) NOT NULL DEFAULT 0,
  `date_created` datetime NOT NULL DEFAULT current_timestamp(),
  `date_updated` datetime NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  `type_of_draw` tinyint(1) NOT NULL DEFAULT 1,
  `qty_numbers` text NOT NULL,
  `min_purchase` text NOT NULL,
  `max_purchase` text NOT NULL,
  `slug` text NOT NULL,
  `pending_numbers` text NOT NULL,
  `paid_numbers` text NOT NULL,
  `ranking_qty` text NOT NULL,
  `enable_ranking` text NOT NULL,
  `image_gallery` text DEFAULT NULL,
  `enable_progress_bar` text NOT NULL,
  `draw_number` text DEFAULT NULL,
  `status_display` text NOT NULL,
  `subtitle` text DEFAULT NULL,
  `date_of_draw` datetime DEFAULT NULL,
  `limit_order_remove` text DEFAULT NULL,
  `discount_qty` text DEFAULT NULL,
  `discount_amount` text DEFAULT NULL,
  `enable_discount` text DEFAULT NULL,
  `enable_cumulative_discount` text DEFAULT NULL,
  `enable_sale` text DEFAULT NULL,
  `sale_qty` text DEFAULT NULL,
  `sale_price` float(12,2) DEFAULT 0.00,
  `ranking_message` text DEFAULT NULL,
  `enable_ranking_show` text DEFAULT NULL,
  `draw_winner` text DEFAULT NULL,
  `private_draw` text NOT NULL,
  `featured_draw` text DEFAULT NULL,
  `cotas_premiadas` text DEFAULT NULL,
  `cotas_premiadas_descricao` text DEFAULT NULL,
  `limit_orders` int(11) DEFAULT 0
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Despejando dados para a tabela `product_list`
--

INSERT INTO `product_list` (`id`, `name`, `description`, `price`, `image_path`, `status`, `delete_flag`, `date_created`, `date_updated`, `type_of_draw`, `qty_numbers`, `min_purchase`, `max_purchase`, `slug`, `pending_numbers`, `paid_numbers`, `ranking_qty`, `enable_ranking`, `image_gallery`, `enable_progress_bar`, `draw_number`, `status_display`, `subtitle`, `date_of_draw`, `limit_order_remove`, `discount_qty`, `discount_amount`, `enable_discount`, `enable_cumulative_discount`, `enable_sale`, `sale_qty`, `sale_price`, `ranking_message`, `enable_ranking_show`, `draw_winner`, `private_draw`, `featured_draw`, `cotas_premiadas`, `cotas_premiadas_descricao`, `limit_orders`) VALUES
(1, 'Rifa Encerrada', 'Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry&#39;s standard dummy text ever since the 1500s, when an unknown printer took a galley of type and scrambled it to make a type specimen book.', 1.00, 'uploads/campanhas/encerrada.png?v=1698081994', 3, 0, '2023-10-23 17:26:34', '2024-01-06 22:01:44', 1, '10000', '1', '', 'rifa-encerrada', '0', '10', '', '0', '[]', '0', '[\"1086\"]', '4', 'REALIZADO PELA LOTERIA FEDERAL', '2023-12-22 23:00:00', '60', '[\"\"]', '[\"0.00\"]', '0', '0', '0', '0', 0.00, 'Quem comprar mais cotas, 1º lugar ganha: R$', '0', '[\"1\"]', '0', '0', '', '', 0),
(28, 'RIFA 10 MILHOES DE BILHETE', 'RIFA 10 MILHOES DE BILHETE', 0.01, 'uploads/campanhas/01.jpg?v=1716904908', 1, 0, '2024-05-28 14:01:48', '2024-05-29 21:46:46', 1, '10000000', '1', '5000', 'rifa-10-milhoes-de-bilhete', '7108', '1203', '', '0', '[]', '0', '', '1', 'MODELO RIFA', NULL, '15', '[\"\"]', '[\"0.00\"]', '0', '0', '0', '0', 0.00, 'Quem comprar mais cotas, 1º lugar ganha: R$', '0', '[\"\"]', '0', '1', '9465819,8964523,6452978,5310056,8805219', '', 0),
(29, 'FAZENDINHA METADE GRUPO', 'FAZENDINHA METADE GRUPO', 25.00, 'uploads/campanhas/0186_https-www-escala-com-br-um-dia-na-fazendinha-p2239-_z1_637944501174728889.jpg?v=1716907221', 1, 0, '2024-05-28 14:40:21', '2024-05-28 15:02:11', 4, '50', '1', '500', 'fazendinha-metade-grupo', '0', '0', '', '0', '[]', '0', '', '1', 'MODELO FAZENDINHA METADE', NULL, '15', '[\"\"]', '[\"0.00\"]', '0', '0', '0', '0', 0.00, 'Quem comprar mais cotas, 1º lugar ganha: R$', '0', '[\"\"]', '0', '0', '', '', 0),
(30, 'FAZENDINHA GRUPO INTEIRO ', 'FAZENDINHA GRUPO INTEIRO ', 50.00, 'uploads/campanhas/0186_https-www-escala-com-br-um-dia-na-fazendinha-p2239-_z1_637944501174728889.jpg?v=1717009594', 1, 0, '2024-05-28 14:42:05', '2024-05-29 19:06:34', 3, '25', '1', '500', 'fazendinha-grupo-inteiro', '0', '0', '', '0', '[]', '0', '', '1', 'MODELO FAZENDINHA INTEIRA', NULL, '15', '[\"\"]', '[\"0.00\"]', '0', '0', '0', '0', 0.00, 'Quem comprar mais cotas, 1º lugar ganha: R$', '0', '[\"\"]', '0', '0', '', '', 0),
(31, 'MODELO RIFA GRÁTIS', 'MODELO RIFA GRÁTIS', 0.00, 'uploads/campanhas/GRATIS.jpg?v=1717009578', 1, 0, '2024-05-28 14:45:40', '2024-05-29 19:06:18', 1, '5000000', '1', '500', 'modelo-rifa-gratis', '0', '0', '', '0', '[]', '0', '', '1', 'MODELO RIFA GRATIS', NULL, '15', '[\"\"]', '[\"0.00\"]', '0', '0', '0', '0', 0.00, 'Quem comprar mais cotas, 1º lugar ganha: R$', '0', '[\"\"]', '0', '0', '11111,22222,44444,55555,66666,77777,88888,99999', '', 0),
(32, 'MODELO RIFA NUMEROS', 'MODELO RIFA NUMEROS', 10.00, 'uploads/campanhas/NUMEROS.jpg?v=1717009565', 1, 0, '2024-05-28 14:48:52', '2024-05-29 21:14:35', 2, '1000', '1', '1000', 'modelo-rifa-numeros', '1', '0', '', '0', '[]', '0', '', '1', 'MODELO RIFA NUMEROS', NULL, '15', '[\"\"]', '[\"0.00\"]', '0', '0', '0', '0', 0.00, 'Quem comprar mais cotas, 1º lugar ganha: R$', '0', '[\"\"]', '0', '0', '11111,22222,33333,44444,55555', '', 0);

-- --------------------------------------------------------

--
-- Estrutura para tabela `referral`
--

CREATE TABLE `referral` (
  `id` int(30) NOT NULL,
  `status` tinyint(1) DEFAULT 0,
  `referral_code` varchar(100) DEFAULT NULL,
  `percentage` float(12,2) NOT NULL DEFAULT 0.00,
  `amount_paid` float(12,2) NOT NULL DEFAULT 0.00,
  `amount_pending` float(12,2) NOT NULL DEFAULT 0.00,
  `customer_id` int(30) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Estrutura para tabela `referral_transactions`
--

CREATE TABLE `referral_transactions` (
  `id` int(30) NOT NULL,
  `total_amount` float(12,2) NOT NULL DEFAULT 0.00,
  `referral_id` int(30) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Despejando dados para a tabela `referral_transactions`
--

INSERT INTO `referral_transactions` (`id`, `total_amount`, `referral_id`) VALUES
(1, 200.00, 6);

-- --------------------------------------------------------

--
-- Estrutura para tabela `system_info`
--

CREATE TABLE `system_info` (
  `id` int(30) NOT NULL,
  `meta_field` text NOT NULL,
  `meta_value` text NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Despejando dados para a tabela `system_info`
--

INSERT INTO `system_info` (`id`, `meta_field`, `meta_value`) VALUES
(1, 'name', 'Thiago Rifas'),
(2, 'short_name', ''),
(3, 'logo', 'uploads/logo.png?v=1716907991'),
(4, 'user_avatar', 'uploads/user_avatar.jpg'),
(5, 'cover', 'uploads/cover.png?v=1675042834'),
(6, 'phone', '92991739596'),
(7, 'mobile', '00000'),
(8, 'email', 'thiagorifas@gmail.com'),
(9, 'address', 'Endereço'),
(10, 'mercadopago', '1'),
(11, 'mercadopago_access_token', 'APP_USR-3074314886997913-041412-e32a85aea6131fca35f202b08b806229-420153672'),
(12, 'gerencianet', '2'),
(13, 'gerencianet_client_id', ''),
(14, 'gerencianet_client_secret', ''),
(15, 'gerencianet_pix_key', ''),
(16, 'gateway', '1'),
(17, 'enable_cpf', '2'),
(18, 'enable_email', '2'),
(19, 'enable_address', '2'),
(20, 'favicon', 'uploads/favicon.png?v=1716907991'),
(21, 'enable_share', '2'),
(22, 'enable_groups', '1'),
(23, 'telegram_group_url', ''),
(24, 'whatsapp_group_url', 'https://whatsapp.com'),
(25, 'enable_footer', '1'),
(26, 'text_footer', ''),
(27, 'enable_password', '2'),
(28, 'paggue', '2'),
(29, 'paggue_client_key', ''),
(30, 'paggue_client_secret', ''),
(31, 'enable_pixel', '2'),
(32, 'facebook_access_token', ''),
(33, 'facebook_pixel_id', ''),
(34, 'enable_hide_numbers', '1'),
(35, 'whatsapp_footer', 'https://api.whatsapp.com/send?phone=5592991739596&text=Quero%20falar%20sobre%20o%20novo%20sistema%20de%20rifa'),
(36, 'instagram_footer', ''),
(37, 'facebook_footer', ''),
(38, 'twitter_footer', ''),
(39, 'youtube_footer', ''),
(40, 'enable_dwapi', '2'),
(41, 'token_dwapi', ''),
(42, 'numero_dwapi', ''),
(43, 'mensagem_novo_pedido_dwapi', ''),
(44, 'mensagem_pedido_pago_dwapi', ''),
(45, 'smtp_host', ''),
(46, 'smtp_port', ''),
(47, 'smtp_user', ''),
(48, 'smtp_pass', ''),
(49, 'question1', 'Como acessar minhas compras?'),
(50, 'answer1', 'Fazendo login no site e abrindo o Menu Principal, você consegue consultar suas últimas compras no menu '),
(51, 'question2', 'Como envio o comprovante?'),
(52, 'answer2', 'Caso você tenha feito o pagamento via Pix QR Code ou copiando o código, não é necessário enviar o comprovante, aguardando até 5 minutos após o pagamento, o sistema irá dar baixa automaticamente, para mais dúvidas entre em contato conosco clicando aqui.'),
(53, 'question3', 'Como é o processo do sorteio?'),
(54, 'answer3', 'O sorteio será realizado com base na extração da Loteria Federal, conforme Condições de Participação constantes no título'),
(55, 'question4', ''),
(56, 'answer4', ''),
(57, 'terms', ''),
(58, 'enable_ga4', '2'),
(59, 'google_ga4_id', ''),
(60, 'license', 'hgh'),
(61, 'enable_two_phone', '2'),
(62, 'enable_gtm', '2'),
(63, 'google_gtm_id', ''),
(64, 'theme', '1'),
(65, 'email_order', ''),
(66, 'email_purchase', ''),
(67, 'pagstar', '2'),
(68, 'pagstar_client_key', '6e0f3bac-858d-4b5e-8a17-03a5ffe610a9'),
(69, 'pagstar_client_secret', '7378603|J9h1GXhOS05eDtLHp5GDAkOXek18Bl0NYs5cCqvg'),
(70, 'pagstar2', 'on');

-- --------------------------------------------------------

--
-- Estrutura para tabela `users`
--

CREATE TABLE `users` (
  `id` int(50) NOT NULL,
  `firstname` varchar(250) NOT NULL,
  `middlename` text DEFAULT NULL,
  `lastname` varchar(250) NOT NULL,
  `email` text DEFAULT NULL,
  `username` text NOT NULL,
  `password` text NOT NULL,
  `avatar` text DEFAULT NULL,
  `last_login` datetime DEFAULT NULL,
  `type` tinyint(1) NOT NULL DEFAULT 0,
  `date_added` datetime NOT NULL DEFAULT current_timestamp(),
  `date_updated` datetime DEFAULT current_timestamp() ON UPDATE current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci COMMENT='2';

--
-- Despejando dados para a tabela `users`
--

INSERT INTO `users` (`id`, `firstname`, `middlename`, `lastname`, `email`, `username`, `password`, `avatar`, `last_login`, `type`, `date_added`, `date_updated`) VALUES
(1, 'Thiago Rifas', '', 'Sites em 1 hora', 'thiagorifas@gmail.com', 'admin', '21232f297a57a5a743894a0e4a801fc3', 'uploads/avatars/1.png?v=1717005873', NULL, 1, '2021-01-20 14:02:37', '2024-05-29 20:04:33');

--
-- Índices para tabelas despejadas
--

--
-- Índices de tabela `cart_list`
--
ALTER TABLE `cart_list`
  ADD PRIMARY KEY (`id`),
  ADD KEY `customer_id` (`customer_id`),
  ADD KEY `product_id` (`product_id`);

--
-- Índices de tabela `customer_list`
--
ALTER TABLE `customer_list`
  ADD PRIMARY KEY (`id`);

--
-- Índices de tabela `logs`
--
ALTER TABLE `logs`
  ADD PRIMARY KEY (`id`);

--
-- Índices de tabela `order_items`
--
ALTER TABLE `order_items`
  ADD KEY `order_id` (`order_id`),
  ADD KEY `product_id` (`product_id`);

--
-- Índices de tabela `order_list`
--
ALTER TABLE `order_list`
  ADD PRIMARY KEY (`id`),
  ADD KEY `customer_id` (`customer_id`),
  ADD KEY `order_list_index` (`product_id`,`order_numbers`(64),`code`);

--
-- Índices de tabela `product_list`
--
ALTER TABLE `product_list`
  ADD PRIMARY KEY (`id`);

--
-- Índices de tabela `referral`
--
ALTER TABLE `referral`
  ADD PRIMARY KEY (`id`),
  ADD KEY `customer_id` (`customer_id`);

--
-- Índices de tabela `referral_transactions`
--
ALTER TABLE `referral_transactions`
  ADD PRIMARY KEY (`id`);

--
-- Índices de tabela `system_info`
--
ALTER TABLE `system_info`
  ADD PRIMARY KEY (`id`);

--
-- Índices de tabela `users`
--
ALTER TABLE `users`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT para tabelas despejadas
--

--
-- AUTO_INCREMENT de tabela `cart_list`
--
ALTER TABLE `cart_list`
  MODIFY `id` int(30) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=330;

--
-- AUTO_INCREMENT de tabela `customer_list`
--
ALTER TABLE `customer_list`
  MODIFY `id` int(30) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=43;

--
-- AUTO_INCREMENT de tabela `logs`
--
ALTER TABLE `logs`
  MODIFY `id` int(30) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=271;

--
-- AUTO_INCREMENT de tabela `order_list`
--
ALTER TABLE `order_list`
  MODIFY `id` int(30) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=355;

--
-- AUTO_INCREMENT de tabela `product_list`
--
ALTER TABLE `product_list`
  MODIFY `id` int(30) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=33;

--
-- AUTO_INCREMENT de tabela `referral`
--
ALTER TABLE `referral`
  MODIFY `id` int(30) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT de tabela `referral_transactions`
--
ALTER TABLE `referral_transactions`
  MODIFY `id` int(30) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT de tabela `system_info`
--
ALTER TABLE `system_info`
  MODIFY `id` int(30) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=71;

--
-- AUTO_INCREMENT de tabela `users`
--
ALTER TABLE `users`
  MODIFY `id` int(50) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- Restrições para tabelas despejadas
--

--
-- Restrições para tabelas `cart_list`
--
ALTER TABLE `cart_list`
  ADD CONSTRAINT `customer_id_fk_cl` FOREIGN KEY (`customer_id`) REFERENCES `customer_list` (`id`) ON DELETE CASCADE ON UPDATE NO ACTION,
  ADD CONSTRAINT `product_id_fk_cl` FOREIGN KEY (`product_id`) REFERENCES `product_list` (`id`) ON DELETE CASCADE ON UPDATE NO ACTION;

--
-- Restrições para tabelas `order_items`
--
ALTER TABLE `order_items`
  ADD CONSTRAINT `order_id_fk_oi` FOREIGN KEY (`order_id`) REFERENCES `order_list` (`id`) ON DELETE CASCADE ON UPDATE NO ACTION,
  ADD CONSTRAINT `product_id_fk_oi` FOREIGN KEY (`product_id`) REFERENCES `product_list` (`id`) ON DELETE CASCADE ON UPDATE NO ACTION;

--
-- Restrições para tabelas `order_list`
--
ALTER TABLE `order_list`
  ADD CONSTRAINT `customer_id_fk_ol` FOREIGN KEY (`customer_id`) REFERENCES `customer_list` (`id`) ON DELETE CASCADE ON UPDATE NO ACTION;

--
-- Restrições para tabelas `referral`
--
ALTER TABLE `referral`
  ADD CONSTRAINT `customer_id_fk_re` FOREIGN KEY (`customer_id`) REFERENCES `customer_list` (`id`) ON DELETE CASCADE ON UPDATE NO ACTION;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
