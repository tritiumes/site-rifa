# Security Policy

## Supported Versions

The following php versions are currently supported:

| Version | Supported          |
| ------- | ------------------ |
| 7.2 | :white_check_mark: |
| 7.3 | :white_check_mark: |
| 7.4 | :white_check_mark: |
| 8.0 | :white_check_mark: |

## Reporting a Vulnerability

If you find a security vulnerability, please write an email to tim@visualappeal.de.
